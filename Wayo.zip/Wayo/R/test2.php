<?php
// 读结果 CSV
$clusters = array_map('str_getcsv', file('/Applications/XAMPP/xamppfiles/htdocs/Wayo/R/user_clusters.csv'));

// 打印看看
foreach ($clusters as $row) {
    echo "UserID: {$row[0]} 在 Cluster: {$row[1]}<br>";
}
?>