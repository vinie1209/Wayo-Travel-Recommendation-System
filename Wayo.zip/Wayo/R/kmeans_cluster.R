args = commandArgs(trailingOnly=TRUE)
datafile = args[1]
k = as.numeric(args[2])

data = read.csv(datafile)

# --------------------
# 🧹 Data clean & preprocess
# --------------------
#时间序列分析（分析每个时段，比较多用户规划去的地方）
#bar chart for ranking



# 去掉缺失值
data = na.omit(data)

# 打印原始数据
cat("=== 原始数据 ===\n")
print(data)

# 转成数值（除了第一列 UserID）
data[ , 2:ncol(data)] = lapply(data[ , 2:ncol(data)], as.numeric)

# 标准化（均值0，方差1）
cluster_data = scale(data[ , -1]) # 不包含 UserID

# 打印标准化后数据
cat("=== 标准化后数据 ===\n")
print(cluster_data)

# 去掉方差=0的列（全是相同值 → 无信息 → scale 后是 NaN）
keep_cols = apply(cluster_data, 2, function(col) !any(is.nan(col)) && var(col, na.rm=TRUE) > 0)
cluster_data = cluster_data[ , keep_cols]

# 检查是否还有 NaN / Inf
if (any(is.nan(cluster_data)) || any(is.na(cluster_data)) || any(is.infinite(cluster_data))) {
  stop("❗ 数据有 NaN / NA / Inf，不能继续聚类")
}

# --------------------
# 🤖 k-means 聚类
# --------------------
set.seed(123)  # 可复现
result = kmeans(cluster_data, centers=k)

# 打印聚类中心
cat("=== 聚类中心 ===\n")
print(result$centers)

# 保存用户簇信息
output = data.frame(UserID = data$UserID, Cluster = result$cluster)
write.csv(output, "user_clusters.csv", row.names=FALSE)

cat("=== 聚类完成！结果已保存到 user_clusters.csv ===\n")
