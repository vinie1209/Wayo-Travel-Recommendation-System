# Install the package if not already installed
install.packages("gtrendsR")
library(gtrendsR)

# Fetch trends — try a simpler, more universal keyword first
tokyo_trend <- gtrends(
  keyword = "Tokyo travel",
  geo = "",              # "" = worldwide
  time = "today 12-m"    # Past 12 months
)

# Check if data was returned
if (!is.null(tokyo_trend$interest_over_time)) {
  print(head(tokyo_trend$interest_over_time))
} else {
  stop("No data returned from Google Trends. Try another keyword or adjust geo/time.")
}

# Plot if data exists
library(ggplot2)
if (!is.null(tokyo_trend$interest_over_time)) {
  ggplot(tokyo_trend$interest_over_time, aes(x = date, y = hits)) +
    geom_line(color = "steelblue") +
    labs(
      title = "Google Trend: Tokyo Travel (Global, Past 12 Months)",
      x = "Date",
      y = "Search Interest"
    ) +
    theme_minimal()
}
