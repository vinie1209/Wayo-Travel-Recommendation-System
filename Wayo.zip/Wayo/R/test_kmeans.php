<?php
// 参数
$dataFile = 'data.csv';
$clusters = 2;

// 如果 Rscript 不在 PATH，需要写绝对路径
$Rscript = '/usr/local/bin/Rscript'; 
$scriptFile = 'kmeans_cluster.R';

// 拼接命令
$command = escapeshellcmd("$Rscript $scriptFile $dataFile $clusters");

// 执行
$output = shell_exec($command);

// 输出到浏览器
echo "<pre>$output</pre>";
?>
