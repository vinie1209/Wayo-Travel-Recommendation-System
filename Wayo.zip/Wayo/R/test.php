<?php
// 连接数据库
error_reporting(E_ALL);
ini_set('display_errors', 1);
include 'db_connection.php';

// 查询用户
$sql = "
SELECT 
    u.UserID,
    -- Budget one-hot
    CASE WHEN PreferredBudgetRange = 'Low' THEN 1 ELSE 0 END AS BudgetLow,
    CASE WHEN PreferredBudgetRange = 'Medium' THEN 1 ELSE 0 END AS BudgetMedium,
    CASE WHEN PreferredBudgetRange = 'High' THEN 1 ELSE 0 END AS BudgetHigh,

    -- Season one-hot
    CASE WHEN PreferredTravelSeason = 'Summer' THEN 1 ELSE 0 END AS Summer,
    CASE WHEN PreferredTravelSeason = 'Winter' THEN 1 ELSE 0 END AS Winter,

    -- Boolean 保留
    LikeCulturalExperiences,
    LikeOutdoorAdventures,
    LikeRelaxingPlaces,

    -- TravelType one-hot: Beach / Nature
    CASE WHEN EXISTS (SELECT 1 FROM UserPreferredTravelTypes WHERE UserID=u.UserID AND TravelType='Beach') THEN 1 ELSE 0 END AS TravelType_Beach,
    CASE WHEN EXISTS (SELECT 1 FROM UserPreferredTravelTypes WHERE UserID=u.UserID AND TravelType='Nature') THEN 1 ELSE 0 END AS TravelType_Nature,

    -- Activity one-hot: Hiking / Food
    CASE WHEN EXISTS (SELECT 1 FROM UserFavoriteActivities WHERE UserID=u.UserID AND Activity='Hiking') THEN 1 ELSE 0 END AS Activity_Hiking,
    CASE WHEN EXISTS (SELECT 1 FROM UserFavoriteActivities WHERE UserID=u.UserID AND Activity='Food') THEN 1 ELSE 0 END AS Activity_Food,

    -- Favorite cities one-hot: Penang / Langkawi
    CASE WHEN EXISTS (SELECT 1 FROM UserFavoriteCities WHERE UserID=u.UserID AND City='Penang') THEN 1 ELSE 0 END AS City_Penang,
    CASE WHEN EXISTS (SELECT 1 FROM UserFavoriteCities WHERE UserID=u.UserID AND City='Langkawi') THEN 1 ELSE 0 END AS City_Langkawi

FROM UserPreferences u
";

// 执行查询
$result = mysqli_query($conn, $sql);

// 打开 CSV 文件写入
$csvFile = '/Applications/XAMPP/xamppfiles/htdocs/Wayo/R/users_for_cluster.csv';
$fp = fopen($csvFile, 'w');


// 写入 CSV 表头
fputcsv($fp, [
    'UserID', 'BudgetLow', 'BudgetMedium', 'BudgetHigh', 
    'Summer', 'Winter', 
    'LikeCulturalExperiences', 'LikeOutdoorAdventures', 'LikeRelaxingPlaces',
    'TravelType_Beach', 'TravelType_Nature',
    'Activity_Hiking', 'Activity_Food',
    'City_Penang', 'City_Langkawi'
]);

// 写入数据
while ($row = mysqli_fetch_assoc($result)) {
    fputcsv($fp, $row);
}

// 关闭文件
fclose($fp);
echo "CSV 导出完成！";
?>
