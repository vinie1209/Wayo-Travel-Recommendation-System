<?php
if ($_GET['action'] == 'places') {
    $lat = $_GET['lat'];
    $lng = $_GET['lng'];
    $type = $_GET['type'];
    $apiKey = 'AIzaSyA45pztm_eOgf1xJpaucfN_9uIpV6FM2GA';

    $url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=$lat,$lng&radius=1000&type=$type&key=$apiKey";

    $data = file_get_contents($url);
    echo $data;
}
?>
