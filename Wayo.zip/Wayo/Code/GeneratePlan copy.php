<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

// 如果未登录，重定向
if (!isset($_SESSION['user_id']) || !isset($_SESSION['email'])) {
    header("Location: Login.php");
    exit;
}

// 引入数据库连接
include 'db_connection.php';

// 接收参数
$city = $_GET['city'] ?? '';
$start = $_GET['start'] ?? '';
$end = $_GET['end'] ?? '';
$adults = intval($_GET['adults'] ?? 0);
$children = intval($_GET['children'] ?? 0);
$total_pax = $adults + $children;

if (!$city || !$start || !$end || $total_pax <= 0) {
    die("Missing required parameters.");
}

// 计算天数
$start_date = new DateTime($start);
$end_date = new DateTime($end);
$days = $start_date->diff($end_date)->days + 1;

// Google API Key
$api_key = "AIzaSyA45pztm_eOgf1xJpaucfN_9uIpV6FM2GA";

// 工具函数：生成固定格式 ID
function generateFixedID($prefix, $number) {
    return sprintf("%s%05d", $prefix, $number);
}
function getNextID($conn, $table, $field, $prefix) {
    $result = $conn->query("SELECT MAX($field) as maxid FROM $table WHERE $field LIKE '$prefix%'");
    $row = $result->fetch_assoc();
    $num = ($row && $row['maxid']) ? intval(substr($row['maxid'], strlen($prefix))) + 1 : 1;
    return generateFixedID($prefix, $num);
}

// Step 1: 获取景点
$city_encoded = urlencode($city);
$url = "https://maps.googleapis.com/maps/api/place/textsearch/json?query=top+attractions+in+$city_encoded&key=$api_key";
$response = file_get_contents($url);
if ($response === FALSE) die("Error calling Google Places API.");
$data = json_decode($response, true);

// Step 2: 提取景点
$places = [];
if (isset($data['results'])) {
    foreach ($data['results'] as $place) {
        if (!empty($place['photos'][0]['photo_reference']) && isset($place['rating']) && $place['rating'] >= 4.0) {
            $places[] = [
                'place_id' => $place['place_id'],
                'name' => $place['name'],
                'rating' => $place['rating'],
                'photo_reference' => $place['photos'][0]['photo_reference'],
                'geometry' => $place['geometry'],
                'recommend_meals' => ''
            ];
        }
    }
}

usort($places, fn($a, $b) => $b['rating'] <=> $a['rating']);

// Step 3: 为每个景点找附近美食
foreach ($places as &$p) {
    if (!empty($p['geometry']['location'])) {
        $lat = $p['geometry']['location']['lat'];
        $lng = $p['geometry']['location']['lng'];
        $r_url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=$lat,$lng&radius=500&type=restaurant&key=$api_key";
        $r_res = file_get_contents($r_url);
        $r_data = json_decode($r_res, true);
        $p['recommend_meals'] = $r_data['results'][0]['name'] ?? '';
    }
}

// Step 4: 每天 4 个景点
$plan = [];
for ($i = 0; $i < $days; $i++) {
    $plan[$i] = array_slice($places, $i * 4, 4);
}

// Step 5: 保存 TripPlan
$TPID = getNextID($conn, 'TripPlan', 'TPID', 'TP');
$stmt = $conn->prepare("INSERT INTO TripPlan (TPID, City, StartDate, EndDate, Adult, Children, UserID) VALUES (?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssiis", $TPID, $city, $start, $end, $adults, $children, $_SESSION['user_id']);
$stmt->execute();

// Step 6: 保存 Histories
$HistoryID = getNextID($conn, 'Histories', 'HistoryID', 'HIS');
$title = "Trip Plan to $city ($start to $end)";
$stmt = $conn->prepare("INSERT INTO Histories (HistoryID, Title, TopicID, UserID) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $HistoryID, $title, $TPID, $_SESSION['user_id']);
$stmt->execute();

// Step 7: 保存 TripPlanDetails，并把 PDID 放回 plan
$day_counter = 0;
foreach ($plan as $d_idx => &$day) {
    $date = (clone $start_date)->modify("+$day_counter days")->format('Y-m-d');
    foreach ($day as $p_idx => &$p) {
        $PDID = getNextID($conn, 'TripPlanDetails', 'PDID', 'PD');
        $time = '09:00:00';
        $place_id = $p['place_id'];
        $recommend_meals = $p['recommend_meals'];

        $stmt = $conn->prepare("INSERT INTO TripPlanDetails (PDID, Date, Time, PlaceID, RecommendMeals, TPID) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $PDID, $date, $time, $place_id, $recommend_meals, $TPID);
        $stmt->execute();

        // 加上 PDID 供前端用
        $p['PDID'] = $PDID;
    }
    $day_counter++;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Your Trip Plan</title>
<link rel="stylesheet" href="/Wayo/CSS/NavigationBar.css" />
<link rel="stylesheet" href="/Wayo/CSS/TripPlan.css" />
<style>
body { font-family: Arial, sans-serif; margin:20px; background:#f9f9f9; }
h1 { color:#333; }
.day-plan { background:#fff; padding:15px; margin-bottom:20px; border-radius:8px; box-shadow:0 0 5px rgba(0,0,0,0.1); }
img { border-radius:5px; margin-bottom:5px; }
</style>
</head>
<body>
    <div class="trip-wrapper">
        <div class="trip-info">
            <h3>Trip Information</h3>
            <div>
                <label>City:</label> 
                <span id="city-text"><?php echo htmlspecialchars($city); ?></span>
                <input type="text" id="city-input" value="<?php echo htmlspecialchars($city); ?>" style="display:none;">
            </div>
            <div>
                <label>Start Date:</label> 
                <span id="start-text"><?php echo htmlspecialchars($start); ?></span>
                <input type="date" id="start-input" value="<?php echo htmlspecialchars($start); ?>" style="display:none;">
            </div>
            <div>
                <label>End Date:</label> 
                <span id="end-text"><?php echo htmlspecialchars($end); ?></span>
                <input type="date" id="end-input" value="<?php echo htmlspecialchars($end); ?>" style="display:none;">
            </div>
            <div>
                <label>Adults:</label> 
                <span id="adults-text"><?php echo $adults; ?></span>
                <input type="number" id="adults-input" value="<?php echo $adults; ?>" style="display:none;">
            </div>
            <div>
                <label>Children:</label> 
                <span id="children-text"><?php echo $children; ?></span>
                <input type="number" id="children-input" value="<?php echo $children; ?>" style="display:none;">
            </div>
            <button id="edit-info-btn">Edit</button>
        </div>
        <div class="trip-plan">
            <div class="day-nav">
                <?php for($i=0;$i<$days;$i++){ echo "<button onclick='showDay($i)' id='day-btn-$i'>Day ".($i+1)."</button>"; } ?>
            </div>
            <div id="plan-container">
                <?php
                    $day_idx = 0;
                    foreach ($plan as $day) {
                        echo "<div class='day-plan' data-day='$day_idx' style='".($day_idx==0?'':'display:none')."'>";
                        echo "<h2>Day ".($day_idx+1)."</h2><ul>";
                        $idx=0;
                        foreach ($day as $p) {
                            $photo_url = "https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photoreference={$p['photo_reference']}&key=$api_key";
                            $odd_even = ($idx % 2 == 0) ? 'odd' : 'even';
                            echo "<li class='place-item $odd_even' data-pdid='{$p['PDID']}'>";
                            echo "<img src='$photo_url' class='place-photo'>";
                            echo "<div class='place-text'>";
                            echo "<span class='place-name'>".htmlspecialchars($p['name'])."</span>";
                            echo "<input type='text' class='place-input' value='".htmlspecialchars($p['name'])."' style='display:none;'>";
                            echo "<button onclick='editPlace(this)'>Edit</button>";
                            echo "</div></li>";
                            $idx++;
                        }
                        echo "</ul></div>";
                        $day_idx++;
                    }
                ?>
            </div>
            <div class="nav-buttons">
                <button onclick="prevDay()">Previous</button>
                <button onclick="nextDay()">Next</button>
                <button onclick="saveDay()">Save</button>
                <button onclick="addPlace()">➕ Add Place</button>
            </div>
        </div>
    </div>

    <script>
        // JS 同原来
        let editing = false;
        document.getElementById('edit-info-btn').addEventListener('click', ()=>{
        editing = !editing;
        ['city','start','end','adults','children'].forEach(id=>{
            document.getElementById(id+'-text').style.display = editing ? 'none' : 'inline';
            document.getElementById(id+'-input').style.display = editing ? 'inline' : 'none';
        });
        document.getElementById('edit-info-btn').innerText = editing ? 'Save' : 'Edit';
        if (!editing) saveTripInfo();
        });
        function saveTripInfo(){
            const data = {
                city: document.getElementById('city-input').value,
                start: document.getElementById('start-input').value,
                end: document.getElementById('end-input').value,
                adults: document.getElementById('adults-input').value,
                children: document.getElementById('children-input').value
            };
            fetch('update_trip.php', {
                method:'POST',
                headers:{'Content-Type':'application/json'},
                body: JSON.stringify(data)
            }).then(res=>res.text()).then(alert);
        }
        let current=0;
        const total=document.querySelectorAll('.day-plan').length;
        function showDay(idx){
            document.querySelectorAll('.day-plan').forEach((el,i)=>{
                el.style.display=(i==idx)?'block':'none';
                document.getElementById('day-btn-'+i).classList.toggle('active',i==idx);
            });
            current=idx;
            updateNavButtons();
        }
        function nextDay(){ if(current<total-1) showDay(current+1);}
        function prevDay(){ if(current>0) showDay(current-1);}
        function updateNavButtons(){
            document.querySelector('.nav-buttons button[onclick="prevDay()"]').style.display=(current==0)?'none':'inline-block';
            document.querySelector('.nav-buttons button[onclick="nextDay()"]').style.display=(current==total-1)?'none':'inline-block';
        }
        showDay(0);
        function editPlace(btn){
            const parent=btn.parentNode;
            const span=parent.querySelector('.place-name');
            const input=parent.querySelector('.place-input');
            const editing=input.style.display=='inline-block';
            if(editing){
                span.innerText=input.value;
                input.style.display='none';
                span.style.display='inline';
                btn.innerText='Edit';
                savePlace(parent.parentNode.dataset.pdid,input.value);
            }else{
                input.style.display='inline-block';
                span.style.display='none';
                btn.innerText='Save';
            }
        }
        function savePlace(pdid,name){
            fetch('update_place.php',{
                method:'POST',
                headers:{'Content-Type':'application/json'},
                body:JSON.stringify({pdid:pdid,name:name})
            }).then(res=>res.text()).then(alert);
        }
    </script>
<a href="Dashboard.php">← Back to Dashboard</a>
<nav class="wayo-bottom-nav">
    <a href="Dashboard.php" class="logo" title="Dashboard"><img src="/Wayo/Image/Logo.png" alt="Logo" class="logo-img"></a>
    <div class="nav-icons">
        <a href="Dashboard.php" title="Trip Planner">📝</a>
        <a href="RouteOpti.php" title="Route">🛣️</a>
        <a href="Rank.php" title="Ranking">📊</a>
        <a href="Profile.php" title="Profile">👤</a>
        <a href="Login.php" title="Logout">🚪</a>
    </div>
</nav>
</body>
</html>
