<?php
// RecommenderLab2.php - PHP interface for R recommendation system

// Set error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include database connection
require_once 'db_connection.php';

// Function to execute R script
function execute_r_script($user_id) {
    $r_script_path = __DIR__ . '/RecommenderLab2.R';
    $command = '/usr/local/bin/Rscript ' . escapeshellarg($r_script_path) . ' ' . escapeshellarg($user_id);
    
    exec($command . ' 2>&1', $output, $return_var);
    
    if ($return_var !== 0) {
        return [
            'success' => false,
            'error' => "R script execution failed",
            'output' => $output
        ];
    }
    
    return [
        'success' => true,
        'output' => $output
    ];
}

// Function to parse R output
function parse_recommendations($output) {
    $recommendations = [];
    $current_type = '';
    
    foreach ($output as $line) {
        $line = trim($line);
        
        if (empty($line)) continue;
        
        if (strpos($line, 'type: ') === 0) {
            $current_type = substr($line, 6);
            $recommendations[$current_type] = [];
            continue;
        }
        
        if (strpos($line, 'id: ') === 0) {
            $id = substr($line, 4);
            $recommendations[$current_type][] = [
                'id' => $id,
                'description' => ''
            ];
        }
        
        if (strpos($line, 'description: ') === 0) {
            $description = substr($line, 13);
            if (!empty($recommendations[$current_type])) {
                $last_index = count($recommendations[$current_type]) - 1;
                $recommendations[$current_type][$last_index]['description'] = $description;
            }
        }
    }
    
    return $recommendations;
}

// Main processing
$recommendations = [];
$error = '';
$user_id = isset($_GET['user_id']) ? trim($_GET['user_id']) : '';

if (!empty($user_id)) {
    $result = execute_r_script($user_id);
    
    if ($result['success']) {
        $recommendations = parse_recommendations($result['output']);
    } else {
        $error = "Error generating recommendations: " . implode("\n", $result['output']);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wayo Travel Recommendations</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            color: #333;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
        }
        h1 {
            color: #2c3e50;
            text-align: center;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input[type="text"] {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        button {
            background-color: #3498db;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #2980b9;
        }
        .error {
            color: #e74c3c;
            padding: 10px;
            background-color: #fadbd8;
            border-radius: 4px;
            margin-bottom: 20px;
        }
        .recommendations {
            margin-top: 30px;
        }
        .recommendation-type {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
        }
        .recommendation-type h3 {
            margin-top: 0;
            color: #2c3e50;
            border-bottom: 1px solid #ddd;
            padding-bottom: 10px;
        }
        .recommendation-item {
            padding: 10px;
            border-bottom: 1px solid #eee;
        }
        .recommendation-item:last-child {
            border-bottom: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Wayo Travel Recommendations</h1>
        
        <form method="get" action="">
            <div class="form-group">
                <label for="user_id">Enter User ID:</label>
                <input type="text" id="user_id" name="user_id" value="<?php echo htmlspecialchars($user_id); ?>" placeholder="e.g., MEM00001" required>
            </div>
            <button type="submit">Get Recommendations</button>
        </form>
        
        <?php if ($error): ?>
            <div class="error">
                <strong>Error:</strong> <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>
        
        <?php if (!empty($recommendations)): ?>
            <div class="recommendations">
                <h2>Recommendations for User: <?php echo htmlspecialchars($user_id); ?></h2>
                
                <?php foreach ($recommendations as $type => $items): ?>
                    <div class="recommendation-type">
                        <h3><?php echo ucfirst(htmlspecialchars($type)); ?> Recommendations</h3>
                        
                        <?php if (empty($items)): ?>
                            <p>No recommendations available for this type.</p>
                        <?php else: ?>
                            <ul>
                                <?php foreach ($items as $item): ?>
                                    <li class="recommendation-item">
                                        <strong>ID:</strong> <?php echo htmlspecialchars($item['id']); ?><br>
                                        <strong>Description:</strong> <?php echo htmlspecialchars($item['description']); ?>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>