#!/usr/local/bin/Rscript

# Wayo Travel Recommendation System - R Script
# Compatible with existing PHP MySQL connection settings

# 1. Load required libraries with error handling
cat("=== Starting Wayo Recommendation System ===\n")
cat("Loading required libraries...\n")
suppressWarnings({
  if (!require("DBI", quietly = TRUE)) {
    stop("DBI package not installed. Please install with: install.packages('DBI')")
  }
  if (!require("RMySQL", quietly = TRUE)) {
    stop("RMySQL package not installed. Please install with: install.packages('RMySQL')")
  }
  if (!require("recommenderlab", quietly = TRUE)) {
    stop("recommenderlab package not installed. Please install with: install.packages('recommenderlab')")
  }
  if (!require("tidyverse", quietly = TRUE)) {
    stop("tidyverse package not installed. Please install with: install.packages('tidyverse')")
  }
})
cat("All required libraries loaded successfully\n")

# 2. Database connection using same credentials as PHP
connect_to_db <- function() {
  cat("Connecting to database...\n")
  tryCatch({
    con <- dbConnect(
        RMySQL::MySQL(),
        dbname = "Wayo",
        host = "localhost",
        user = "root",
        password = "",
        unix.sock = "/Applications/XAMPP/xamppfiles/var/mysql/mysql.sock"
    )
    cat("Successfully connected to MySQL database\n")
    return(con)
  }, error = function(e) {
    cat("Database connection failed:\n")
    cat("Error:", e$message, "\n")
    cat("Please verify:\n")
    cat("1. MySQL server is running\n")
    cat("2. Database 'Wayo' exists\n")
    cat("3. User 'root' has correct permissions\n")
    quit(status = 1)
  })
}

# 3. Main recommendation function
generate_recommendations <- function(user_id = NULL) {
  con <- connect_to_db()
  
  cat("Fetching data from database...\n")
  tryCatch({
    # Fetch required data
    user_histories <- dbGetQuery(con, "SELECT UserID, TopicID FROM Histories")
    routes <- dbGetQuery(con, "SELECT RouteID FROM Routes")
    trip_plans <- dbGetQuery(con, "SELECT TPID, City FROM TripPlan")
    
    cat("Successfully retrieved:\n")
    cat("-", nrow(user_histories), "history records\n")
    cat("-", nrow(routes), "routes\n")
    cat("-", nrow(trip_plans), "trip plans\n")
    
    # Prepare user-item matrix
    cat("Preparing recommendation matrix...\n")
    history_items <- user_histories %>%
      mutate(
        item_type = case_when(
          TopicID %in% routes$RouteID ~ "route",
          TopicID %in% trip_plans$TPID ~ "trip_plan",
          TRUE ~ NA_character_
        )
      ) %>%
      filter(!is.na(item_type)) %>%
      left_join(trip_plans, by = c("TopicID" = "TPID")) %>%
      mutate(
        item_id = ifelse(item_type == "route", 
                        paste0("route_", TopicID),
                        paste0("city_", City))
      ) %>%
      select(UserID, item_id)
    
    user_item_matrix <- history_items %>%
        mutate(rating = 1) %>%
        # First ensure we have unique user-item pairs
        group_by(UserID, item_id) %>%
        summarise(rating = max(rating), .groups = "drop") %>%
        # Then pivot
        pivot_wider(names_from = item_id, values_from = rating, values_fill = list(rating = 0)) %>%
        column_to_rownames("UserID") %>%
        as.matrix() %>%
        as("binaryRatingMatrix")
    
    # Model path
    model_path <- "wayo_recommendation_model.rds"
    
    # Train or load model
    if (file.exists(model_path)) {
      cat("Loading existing recommendation model...\n")
      model <- readRDS(model_path)
    } else {
      cat("Training new recommendation model...\n")
      model <- Recommender(user_item_matrix, method = "UBCF")
      saveRDS(model, model_path)
      cat("Model saved to", model_path, "\n")
    }
    
    # Generate recommendations
    if (!is.null(user_id) && user_id %in% rownames(user_item_matrix)) {
      cat("Generating personalized recommendations for user", user_id, "...\n")
      rec <- predict(model, user_item_matrix[user_id, ], n = 5)
      items <- as(rec, "list")[[1]]
      
      # Format output for PHP
      cat("type: route\n")
      for (item in items[grepl("^route_", items)]) {
        route_id <- sub("^route_", "", item)
        cat("id:", route_id, "\n")
        cat("description: Recommended Route ID", route_id, "\n")
      }
      
      cat("type: destination\n")
      for (item in items[grepl("^city_", items)]) {
        city <- sub("^city_", "", item)
        cat("id:", city, "\n")
        cat("description: Recommended Destination:", city, "\n")
      }
    } else {
      cat("Generating popular recommendations for new user...\n")
      popular <- predict(Recommender(user_item_matrix, method = "POPULAR"), user_item_matrix, n = 5)
      items <- as(popular, "list")[[1]]
      
      cat("type: popular_routes\n")
      for (item in items[grepl("^route_", items)]) {
        route_id <- sub("^route_", "", item)
        cat("id:", route_id, "\n")
        cat("description: Popular Route ID", route_id, "\n")
      }
      
      cat("type: popular_destinations\n")
      for (item in items[grepl("^city_", items)]) {
        city <- sub("^city_", "", item)
        cat("id:", city, "\n")
        cat("description: Popular Destination:", city, "\n")
      }
    }
    
  }, error = function(e) {
    cat("Error during recommendation generation:\n")
    cat(e$message, "\n")
    quit(status = 1)
  }, finally = {
    dbDisconnect(con)
    cat("Database connection closed\n")
  })
}

# 4. Handle command line arguments
args <- commandArgs(trailingOnly = TRUE)
user_id <- if (length(args) > 0) args[1] else NULL

# 5. Generate and output recommendations
cat("\n=== Generating Recommendations ===\n")
generate_recommendations(user_id)
cat("\n=== Recommendation Process Complete ===\n")