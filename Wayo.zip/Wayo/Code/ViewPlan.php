<?php
session_start();
if (!isset($_SESSION['user_id']) || !isset($_GET['tp_id'])) {
    die("Missing parameters.");
}
include 'db_connection.php';

$tp_id = $_GET['tp_id'];
$user_id = $_SESSION['user_id'];

// 验证计划属于当前用户
$sql = $conn->prepare("SELECT * FROM TripPlan WHERE TPID=? AND UserID=?");
$sql->bind_param("ss", $tp_id, $user_id);
$sql->execute();
$result = $sql->get_result();
$plan = $result->fetch_assoc();
if (!$plan) die("❌ 未找到该计划或无权限查看。");

// 获取详情
$sql = $conn->prepare("SELECT * FROM TripPlanDetails WHERE TPID=? ORDER BY Date, Time");
$sql->bind_param("s", $tp_id);
$sql->execute();
$result = $sql->get_result();
$details = [];
while($row = $result->fetch_assoc()) {
    $details[] = $row;
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>View Trip Plan</title>
</head>
<body>
<h1>Trip Plan to <?php echo htmlspecialchars($plan['City']); ?></h1>
<p>From <?php echo $plan['StartDate']; ?> to <?php echo $plan['EndDate']; ?> | Adults: <?php echo $plan['Adult']; ?>, Children: <?php echo $plan['Children']; ?></p>

<?php
$current_date = '';
foreach ($details as $d) {
    if ($d['Date'] != $current_date) {
        if ($current_date != '') echo "</ul>";
        echo "<h3>Date: {$d['Date']}</h3><ul>";
        $current_date = $d['Date'];
    }
    echo "<li>{$d['Time']} - {$d['Place']} | Meal: {$d['RecommendMeals']}</li>";
}
if ($current_date != '') echo "</ul>";
?>
<a href="Dashboard.php">← Back to Dashboard</a>
</body>
</html>
