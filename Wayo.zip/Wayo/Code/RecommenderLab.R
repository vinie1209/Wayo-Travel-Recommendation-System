# install.packages("recommenderlab")
# install.packages("dplyr")
library(recommenderlab)
library(dplyr)

# 1. 载入地点特征数据（可以从数据库导出为CSV）
places <- read.csv("places_features.csv", stringsAsFactors = FALSE)

# 2. 模拟用户搜索记录（真实情况请从数据库读入）
user_logs <- read.csv("user_logs.csv", stringsAsFactors = FALSE)

# 3. 将用户搜索记录转为评分矩阵（binary preference）
user_place_matrix <- table(user_logs$user_id, user_logs$place_id)
user_matrix <- as(user_place_matrix, "binaryRatingMatrix")

# 4. 创建内容式推荐器
content_model <- Recommender(user_matrix, method = "IBCF", param = list(method = "cosine", k = 5))

# 5. 预测推荐地点（推荐每位用户5个地点）
pred <- predict(content_model, user_matrix, n = 5)
recommendations <- as(pred, "list")

# 6. 存储推荐结果
recommend_df <- data.frame(
  user_id = rep(names(recommendations), sapply(recommendations, length)),
  place_id = unlist(recommendations)
)

# 7. 导出为CSV供PHP使用
write.csv(recommend_df, "recommend_results.csv", row.names = FALSE)
