<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : '';
if (!isset($_SESSION['email'])) {
    header("Location: Login.php");
    exit;
}

// Include your database connection
include 'db_connection.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: Login.php");
    exit();
}

// Fetch places from DB ordered by rating DESC
$places = []; // initialize empty

$result = $conn->query("SELECT * FROM Places ORDER BY rating DESC LIMIT 20");

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $places[] = $row;
    }
} else {
    echo "<p>Error fetching places: " . htmlspecialchars($conn->error) . "</p>";
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Place Rankings</title>
<link rel="stylesheet" href="/Wayo/CSS/NavigationBar.css" />
<style>
    body {
        font-family: 'Arial', sans-serif;
        background: #f5f5f5;
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
        margin: 0;
    }
    .container {
        display: flex;
        flex-direction: column;
        gap: 20px;
        width: 90%;
        max-width: 400px;
    }
    .card {
        background: white;
        border-radius: 12px;
        box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        padding: 20px;
        text-align: center;
        cursor: pointer;
        transition: transform 0.2s, box-shadow 0.2s;
        font-size: 18px;
    }
    .card:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 16px rgba(0,0,0,0.3);
    }
    a {
        text-decoration: none;
        color: #333;
        display: block;
        height: 100%;
    }
</style>
</head>
<body>
    <div class="container">
        <div class="card">
            <a href="HighRating.php">1️⃣ High Rating Place</a>
        </div>
        <div class="card">
            <a href="HighComment.php">2️⃣ High 热度（评论数）</a>
        </div>
        <div class="card">
            <a href="HighSearch.php">3️⃣ High Search Place</a>
        </div>
        <div class="card">
            <a href="HighSeason.php">4️⃣ High Popularity by Season</a>
        </div>
    </div>
    <nav class="wayo-bottom-nav">
        <a href="Dashboard.php" class="logo" title="Dashboard">
            <img src="/Wayo/Image/Logo.png" alt="Logo" class="logo-img">
        </a>
        <div class="nav-icons">
            <a href="Dashboard.php" title="Trip Planner">📝</a>
            <a href="RouteOpti.php" title="Route Recommendation">🛣️</a>
            <a href="Rank.php" title="Ranking">📊</a>
            <a href="Profile.php" title="Profile">👤</a>
            <a href="Login.php" title="Logout">🚪</a>
        </div>
    </nav>
</body>
</html>
