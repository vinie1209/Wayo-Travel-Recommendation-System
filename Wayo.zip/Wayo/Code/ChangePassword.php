<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // User is not logged in, redirect to login page
    header("Location: Login.php");
    exit();
}

// Include database connection
include 'db_connection.php';

// Initialize variables
$user_id = $_SESSION['user_id'];
$old_password = $new_password = $confirm_password = '';
$errors = array();
$success_message = '';
$form_submitted = false;

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate and sanitize input
    $old_password = $_POST['old_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    // Check if new password matches confirm password
    if ($new_password != $confirm_password) {
        $errors[] = "New password and confirm password do not match.";
    }

    // Check if old password matches the one in the database
    $sql = "SELECT Password FROM Users WHERE UserID = '$user_id'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $stored_password = $row['Password'];

        // Verify old password (assuming plaintext comparison for simplicity, NOT RECOMMENDED)
        if ($old_password == $stored_password) {
            // Validate new password
            if (empty($errors)) {
                // Update password in the database
                $update_sql = "UPDATE Users SET Password = '$new_password' WHERE UserID = '$user_id'";
                if ($conn->query($update_sql) === TRUE) {
                    // Password updated successfully
                    $success_message = "Password updated successfully!";
                    $form_submitted = true; // Flag to indicate form submission
                } else {
                    $errors[] = "Error updating password: " . $conn->error;
                }
            }
        } else {
            $errors[] = "Old password is incorrect.";
        }
    } else {
        $errors[] = "User not found.";
    }
}

// Close database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Change Password</title>
    <link rel="stylesheet" href="/path/to/your/styles.css"> <!-- Link to your CSS file -->
    <script>
        // Confirm leaving page if form is dirty
        window.onbeforeunload = function(event) {
            if (!document.getElementById('form_submitted').value &&
                (document.getElementById('old_password').value || 
                 document.getElementById('new_password').value || 
                 document.getElementById('confirm_password').value)) {
                if (event.currentTarget.performance.navigation.type !== 1) {
                    return 'Are you sure you want to leave? Any unsaved changes will be lost.';
                }
            }
        };

        window.onload = function() {
            <?php if (!empty($success_message)): ?>
                alert("<?php echo $success_message; ?>");
                window.location.href = "Profile.php";
            <?php endif; ?>
        };

        // Function to disable onbeforeunload message temporarily
        function disableUnloadMessage() {
            window.onbeforeunload = null;
            document.getElementById('form_submitted').value = 'true';
        }
    </script>
</head>
<body>
    <div class="container">
        <h2>Change Password</h2>
        <?php
        // Display errors if any
        if (!empty($errors)) {
            foreach ($errors as $error) {
                echo '<p class="error">' . $error . '</p>';
            }
        }
        ?>
        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" onsubmit="disableUnloadMessage()">
            <input type="hidden" id="form_submitted" name="form_submitted" value="<?php echo $form_submitted ? 'true' : ''; ?>">
            <div class="form-group">
                <label for="old_password">Old Password:</label>
                <input type="password" id="old_password" name="old_password" required>
            </div>
            <div class="form-group">
                <label for="new_password">New Password:</label>
                <input type="password" id="new_password" name="new_password" required>
            </div>
            <div class="form-group">
                <label for="confirm_password">Confirm Password:</label>
                <input type="password" id="confirm_password" name="confirm_password" required>
            </div>
            <button type="submit">Change Password</button>
        </form>
    </div>
</body>
</html>
