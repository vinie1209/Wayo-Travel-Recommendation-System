#!/usr/bin/env Rscript
args = commandArgs(trailingOnly=TRUE)
user_id = args[1]

library(DBI)
library(RMySQL)
library(recommenderlab)

# 连接数据库
con <- dbConnect(RMySQL::MySQL(), dbname="Wayo", host="localhost", user="root", password="")

# Step 1: 读所有历史记录
histories <- dbGetQuery(con, "SELECT UserID, TopicID FROM Histories")

# Step 2: 创建 user-item 矩阵
library(reshape2)
histories$count <- 1
history_matrix <- dcast(histories, UserID ~ TopicID, fun.aggregate=length, value.var='count')
rownames(history_matrix) <- history_matrix$UserID
history_matrix$UserID <- NULL

# Step 3: 转为 binaryRatingMatrix（用次数也行，这里用 0/1）
history_mat <- as(as.matrix(history_matrix), "binaryRatingMatrix")

# Step 4: 创建推荐模型
model <- Recommender(history_mat, method="UBCF")

# Step 5: 为当前用户推荐
if(user_id %in% rownames(history_matrix)){
    preds <- predict(model, history_mat[user_id,], n=10)
    # 转为 list
    rec_items <- as(preds, "list")[[1]]
    if(length(rec_items) == 0){
        rec_items <- character(0)
    }
} else {
    rec_items <- character(0)
}

# Step 6: 输出到 CSV
write.table(data.frame(TopicID=rec_items), file="/Applications/XAMPP/xamppfiles/htdocs/Wayo/Code/recommend.csv", 
            row.names=FALSE, col.names=TRUE, sep=",", quote=FALSE)

dbDisconnect(con)
