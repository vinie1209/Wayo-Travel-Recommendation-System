<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$apiKey = 'AIzaSyA45pztm_eOgf1xJpaucfN_9uIpV6FM2GA'; // optional, geocode 时需要
$rawCity = isset($_POST['city']) ? trim($_POST['city']) : '';
$city = '';
$country = '';
$imageFile = 'season_plot.png';
$error = '';

if ($rawCity !== '') {
    // 用 Google Geocoding API 拿到国家码
    $encoded = urlencode($rawCity);
    $geoUrl = "https://maps.googleapis.com/maps/api/geocode/json?address=$encoded&key=$apiKey";
    $geoJson = file_get_contents($geoUrl);
    $geoData = json_decode($geoJson, true);

    if ($geoData && $geoData['status'] === 'OK') {
        foreach ($geoData['results'][0]['address_components'] as $comp) {
            if (in_array('country', $comp['types'])) {
                $country = $comp['short_name']; // JP, EG etc.
                break;
            }
        }
        $city = $geoData['results'][0]['address_components'][0]['long_name'];
    } else {
        $error = "Could not find city: " . htmlspecialchars($rawCity);
    }

    if ($city !== '' && $country !== '') {
        $cmd = "/Library/Frameworks/Python.framework/Versions/3.10/bin/python3 /Applications/XAMPP/xamppfiles/htdocs/Wayo/Code/season_trend_plot.py "
       . escapeshellarg($city) . " " . escapeshellarg($country);
        exec($cmd . " 2>&1", $output, $return_var);
        echo "<pre>"; print_r($output); echo "</pre>"; // 调试时可打印
        if ($return_var !== 0) {
            $error = "Error running Python script!";
        } elseif (!file_exists($imageFile)) {
            $error = "No image generated!";
        }
    } else {
        $error = "Could not find country for city";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>City Seasonal Popularity</title>
    <style>
        body { font-family: Arial, sans-serif; text-align: center; margin-top: 50px; }
        input[type=text] { width: 300px; padding: 8px; }
        input[type=submit] { padding: 8px 16px; }
        img { margin-top: 20px; max-width: 80%; border: 1px solid #ccc; }
        .error { color: red; margin-top: 10px; }
    </style>
</head>
<body>
    <h2>Search City Seasonal Popularity</h2>
    <form method="post">
        <input type="text" name="city" placeholder="Enter city name" value="<?= htmlspecialchars($rawCity) ?>">
        <input type="submit" value="Search">
    </form>

    <?php if (!empty($error)): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php elseif ($city !== '' && file_exists($imageFile)): ?>
        <h3>Seasonal Popularity for <?= htmlspecialchars($city) ?></h3>
        <img src="<?= $imageFile ?>?t=<?= time() ?>" alt="Season Chart">
    <?php endif; ?>
</body>
</html>
