<?php
// Load recommended places
$csv = array_map('str_getcsv', file('recommend_results.csv'));
array_shift($csv); // Remove header

// Replace with actual user ID from session
$current_user_id = $_SESSION['user_id'] ?? 1;

// Google Maps API key
$api_key = "AIzaSyA45pztm_eOgf1xJpaucfN_9uIpV6FM2GA";

foreach ($csv as $row) {
    if ($row[0] == $current_user_id) {
        $place_id = $row[1];
        $url = "https://maps.googleapis.com/maps/api/place/details/json?place_id=$place_id&key=$api_key";

        $json = file_get_contents($url);
        $data = json_decode($json, true);

        if ($data['status'] == 'OK') {
            $place = $data['result'];
            echo "<h3>" . $place['name'] . "</h3>";
            echo "<p>" . $place['formatted_address'] . "</p>";

            if (isset($place['photos'][0]['photo_reference'])) {
                $photo_ref = $place['photos'][0]['photo_reference'];
                $photo_url = "https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photoreference=$photo_ref&key=$api_key";
                echo "<img src='$photo_url' width='300'><br>";
            }

            echo "<hr>";
        }
    }
}
?>
