<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: Login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

include 'db_connection.php';

// Fetch history records
$sql = "SELECT * FROM Histories WHERE UserID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>User History</title>
    <link rel="stylesheet" href="/Wayo/CSS/NavigationBar.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f5f7fa;
            margin: 0;
            padding: 0 16px 80px;
        }

        h1 {
            text-align: center;
            margin-top: 30px;
            color: #333;
        }

        .history-container {
            display: flex;
            flex-direction: column; /* Stack items vertically */
            gap: 16px;
            margin-top: 30px;
            max-width: 800px;
            margin-left: auto;
            margin-right: auto;
        }

        .history-card {
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.08);
            padding: 20px;
            width: 100%;
            transition: transform 0.2s ease;
        }

        .history-card:hover {
            transform: translateY(-5px);
        }

        .history-title {
            font-size: 18px;
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 8px;
        }

        .history-meta {
            font-size: 14px;
            color: #666;
        }

        .no-history {
            text-align: center;
            font-size: 18px;
            color: #888;
            margin-top: 40px;
        }

        .wayo-bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
        }
    </style>
</head>
<body>

    <h1>Your History</h1>

    <?php if ($result->num_rows > 0): ?>
        <div class="history-container">
            <?php while ($row = $result->fetch_assoc()): ?>
                <div class="history-card">
                    <div class="history-title"><?= htmlspecialchars($row['Title']) ?></div>
                    <div class="history-meta">
                        History ID: <?= htmlspecialchars($row['HistoryID']) ?><br>
                        Topic ID: <?= htmlspecialchars($row['TopicID']) ?><br>
                        Created At: <?= htmlspecialchars($row['CreatedAt']) ?>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    <?php else: ?>
        <div class="no-history">You have no history records yet.</div>
    <?php endif; ?>

    <nav class="wayo-bottom-nav">
        <a href="Dashboard.php" class="logo" title="Dashboard">
            <img src="/Wayo/Image/Logo.png" alt="Logo" class="logo-img">
        </a>
        <div class="nav-icons">
            <a href="Dashboard.php" title="Trip Planner">📝</a>
            <a href="RouteOpti.php" title="Route Recommendation">🛣️</a>
            <a href="Rank.php" title="Ranking">📊</a>
            <a href="Profile.php" title="Profile">👤</a>
            <a href="Login.php" title="Logout">🚪</a>
        </div>
    </nav>

</body>
</html>
