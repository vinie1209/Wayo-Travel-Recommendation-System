#!/usr/bin/env Rscript
library(ggplot2)

# Step 1: 读取 CSV
df <- read.csv("high_search.csv", stringsAsFactors = FALSE)

# Step 2: 画柱状图
ggplot(df, aes(x = reorder(place_name, search_count), y = search_count)) +
  geom_bar(stat = "identity", fill = "steelblue") +
  coord_flip() +
  labs(
    title = "Top High Search Places",
    x = "Place Name",
    y = "Search Count"
  ) +
  theme_minimal()

# Step 3: 保存图片
ggsave("high_search_plot.png", width = 8, height = 6)
