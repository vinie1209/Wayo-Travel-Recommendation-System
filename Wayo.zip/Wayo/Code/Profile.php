<?php
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: Login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

include 'db_connection.php';

$name = $contact_number = $gender = $email = "";

$sql = "SELECT * FROM Users WHERE UserID = '$user_id'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $name = $row['Name'];
    $contact_number = $row['ContactNumber'];
    $gender = $row['Gender'];
    $email = $row['Email'];
    $verification = $row['Verification'];
} else {
    echo "No user found.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Profile - <?php echo $row['Name']; ?></title>
    <link rel="stylesheet" href="/Wayo/CSS/Profile.css">
    <link rel="stylesheet" href="/Wayo/CSS/NavigationBar.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Caveat:wght@400..700&family=Space+Grotesk:wght@300..700&display=swap" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <style>

        .main-container {
    max-width: 500px;
    margin: 100px auto;
    padding: 0 20px;
    display: flex;
    justify-content: center;
    align-items: center;
    text-align: center;
}

.profile-container {
    background: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
    text-align: center;
    width: 100%;
}

.content {
    box-shadow: 1px 1px 4px 1px rgba(0, 0, 0, 0.1);
    background-color: rgb(228, 228, 249);
    padding: 20px;
    border-radius: 8px;
}

.profile-image {
    width: 150px;
    height: 150px;
    border-radius: 50%;
    overflow: hidden;
    margin: 0 auto 15px;
}

.profile-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.profile-details {
    margin-bottom: 20px;
}

.profile-details label {
    font-weight: bold;
    display: block;
    margin-top: 5px;
}

.button-container {
    margin-top: 20px;
    display: flex;
    justify-content: center;
    gap: 10px;
}

.button-container button {
    padding: 10px 15px;
    background-color: #fcb6c1;
    border: none;
    color: white;
    border-radius: 6px;
    cursor: pointer;
    transition: background-color 0.2s;
}

.button-container button:hover {
    background-color: #f88fa1;
}

    </style>
</head>
<body>
    <div class="main-container">
        <div class="content">
            <div class="profile-container">
                    <div class="profile-image">
                        <img id="profileImage" src="<?php echo isset($row['Image']) ? 'data:image/jpeg;base64,'.base64_encode($row['Image']) : '/PawConnect/Image/BlankProfile.png'; ?>" alt="Profile Image">
                    </div>
                    <div class="profile-details">
                        <div class="profile-left">
                            <div>
                                <label>Email:</label>
                                <span id="email"><?php echo $email; ?></span>
                            </div>
                            <div>
                                <label>Name:</label>
                                <span id="name"><?php echo $name; ?></span>
                            </div>
                            
                        </div>
                    <div class="button-container">
                        <button onclick="window.location.href='UserHistory.php'">My History</button>
                        <button onclick="window.location.href='UserPreferences.php'">My Preferences</button>
                    </div>
            </div>
        </div>
        
    </div>
    
    <nav class="wayo-bottom-nav">
        <a href="Dashboard.php" class="logo" title="Dashboard">
            <img src="/Wayo/Image/Logo.png" alt="Logo" class="logo-img">
        </a>
        <div class="nav-icons">
            <a href="Dashboard.php" title="Trip Planner">📝</a>
            <a href="RouteOpti.php" title="Route Recommendation">🛣️</a>
            <a href="Rank.php" title="Ranking">📊</a>
            <a href="Profile.php" title="Profile">👤</a>
            <a href="Login.php" title="Logout">🚪</a>
        </div>
    </nav>
</body>
</html>
