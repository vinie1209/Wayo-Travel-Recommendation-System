<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>简单地图示例</title>
  <style>
    /* 确保地图容器有高度 */
    #map {
      height: 500px;
      width: 100%;
    }
    body, html {
      margin: 0;
      padding: 0;
      height: 100%;
    }
  </style>
</head>
<body>
  <h2>我的 Google 地图</h2>
  <div id="map"></div>

  <script>
    function initMap() {
      var center = {lat: 3.139, lng: 101.686}; // 吉隆坡坐标
      var map = new google.maps.Map(document.getElementById('map'), {
        zoom: 13,
        center: center
      });

      // 添加一个 marker
      var marker = new google.maps.Marker({
        position: center,
        map: map,
        title: '这里是吉隆坡'
      });
    }
  </script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA45pztm_eOgf1xJpaucfN_9uIpV6FM2GA&callback=initMap" async defer></script>
</body>
</html>
