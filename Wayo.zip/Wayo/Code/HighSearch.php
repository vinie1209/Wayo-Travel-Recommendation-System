<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include __DIR__ . '/../Code/db_connection.php';

// If $mysqli is not defined in db_connection.php, define it manually
if (!isset($mysqli) || !$mysqli) {
    $mysqli = new mysqli("localhost", "root", "", "Wayo");
    if ($mysqli->connect_error) {
        die("Connection failed: " . $mysqli->connect_error);
    }
}

$apiKey = 'AIzaSyA45pztm_eOgf1xJpaucfN_9uIpV6FM2GA';
$places = [];
$error = '';

try {
    // Step 1: 从 Locations 表中取 PlaceID 出现次数 (高搜索量)
    $query = "
        SELECT PlaceID, COUNT(*) AS search_count
        FROM Locations
        WHERE PlaceID IS NOT NULL AND PlaceID != ''
        GROUP BY PlaceID
        ORDER BY search_count DESC
        LIMIT 50
    ";
    $result = $mysqli->query($query);

    if (!$result) {
        throw new Exception("Database query failed: " . $mysqli->error);
    }

    while ($row = $result->fetch_assoc()) {
        $placeId = $row['PlaceID'];
        $searchCount = $row['search_count'];

        // Step 1.1: 调用 Google Place Details API 获取名称
        $url = "https://maps.googleapis.com/maps/api/place/details/json?place_id=" . urlencode($placeId) . "&fields=name&key=" . $apiKey;
        $data = json_decode(file_get_contents($url), true);

        $name = isset($data['result']['name']) ? $data['result']['name'] : $placeId;

        $places[] = [
            'place_name' => $name,
            'search_count' => $searchCount
        ];
    }

    // Step 2: 写 CSV 给 R 用
    $csvFile = __DIR__.'/high_search.csv';
    $fp = fopen($csvFile, 'w');
    fputcsv($fp, ['place_name','search_count']);
    foreach ($places as $p) {
        fputcsv($fp, [$p['place_name'], $p['search_count']]);
    }
    fclose($fp);

    // Step 3: 调用 R 绘制柱状图
    $rscript = '/usr/local/bin/Rscript';
    $rfile = __DIR__.'/plot_high_search.R';
    exec("$rscript " . escapeshellarg($rfile), $output, $return_var);
    if ($return_var !== 0) {
        $error = "Error running R script!";
    }

} catch(Exception $e) {
    $error = $e->getMessage();
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>High Search Places</title>
<style>
body { font-family: Arial, sans-serif; background:#f9f9f9; text-align:center; margin:0; padding:20px;}
h2 { margin-top:20px;}
.error {color:red; margin-top:10px;}
</style>
</head>
<body>
    <h2>High Search Places</h2>
    <?php if ($error): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php else: ?>
        <img src="high_search_plot.png?t=<?=time()?>" alt="High Search Bar Chart">
    <?php endif; ?>
</body>
</html>
