<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

// 如果未登录，重定向
if (!isset($_SESSION['user_id']) || !isset($_SESSION['email'])) {
    header("Location: Login.php");
    exit;
}

// 引入数据库连接
include 'db_connection.php';

// 接收参数
$city = $_GET['city'] ?? '';
$start = $_GET['start'] ?? '';
$end = $_GET['end'] ?? '';
$adults = intval($_GET['adults'] ?? 0);
$children = intval($_GET['children'] ?? 0);
$total_pax = $adults + $children;

if (!$city || !$start || !$end || $total_pax <= 0) {
    die("Missing required parameters.");
}

// 计算天数
$start_date = new DateTime($start);
$end_date = new DateTime($end);
$days = $start_date->diff($end_date)->days + 1;

// Google API Key
$api_key = "AIzaSyA45pztm_eOgf1xJpaucfN_9uIpV6FM2GA";

// 工具函数：生成固定格式 ID
function generateFixedID($prefix, $number) {
    return sprintf("%s%05d", $prefix, $number);
}
function getNextID($conn, $table, $field, $prefix) {
    $result = $conn->query("SELECT MAX($field) as maxid FROM $table WHERE $field LIKE '$prefix%'");
    $row = $result->fetch_assoc();
    $num = ($row && $row['maxid']) ? intval(substr($row['maxid'], strlen($prefix))) + 1 : 1;
    return generateFixedID($prefix, $num);
}

// Step 1: 获取景点
$city_encoded = urlencode($city);
$url = "https://maps.googleapis.com/maps/api/place/textsearch/json?query=top+attractions+in+$city_encoded&key=$api_key";
$response = file_get_contents($url);
if ($response === FALSE) die("Error calling Google Places API.");
$data = json_decode($response, true);

// Step 2: 提取景点并保留 rating（仅用于排序）
$places = [];
if (isset($data['results'])) {
    foreach ($data['results'] as $place) {
        if (!empty($place['photos'][0]['photo_reference']) && isset($place['rating']) && $place['rating'] >= 4.0) {
            $places[] = [
                'place_id' => $place['place_id'],
                'name' => $place['name'],
                'description' => $place['formatted_address'] ?? implode(', ', $place['types']),
                'rating' => $place['rating'],
                'photo_reference' => $place['photos'][0]['photo_reference'],
                'photo_url' => "https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photoreference=" . $place['photos'][0]['photo_reference'] . "&key=$api_key",
                'geometry' => $place['geometry'],
                'recommend_meals' => ''
            ];
        }
    }
}

usort($places, fn($a, $b) => $b['rating'] <=> $a['rating']);

// Step 3: 为每个景点找附近美食
foreach ($places as &$p) {
    if (!empty($p['geometry']['location'])) {
        $lat = $p['geometry']['location']['lat'];
        $lng = $p['geometry']['location']['lng'];
        $r_url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=$lat,$lng&radius=500&type=restaurant&key=$api_key";
        $r_res = file_get_contents($r_url);
        $r_data = json_decode($r_res, true);
        $p['recommend_meals'] = $r_data['results'][0]['name'] ?? '';
    }
}

// Step 4: 每天 4 个景点
$plan = [];
for ($i = 0; $i < $days; $i++) {
    $plan[$i] = array_slice($places, $i * 4, 4);
}

// Step 5: 保存 TripPlan
$TPID = getNextID($conn, 'TripPlan', 'TPID', 'TP');
$stmt = $conn->prepare("INSERT INTO TripPlan (TPID, City, StartDate, EndDate, Adult, Children, UserID) VALUES (?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssiis", $TPID, $city, $start, $end, $adults, $children, $_SESSION['user_id']);
$stmt->execute();

// Step 6: 保存 Histories
$HistoryID = getNextID($conn, 'Histories', 'HistoryID', 'HIS');
$title = "Trip Plan to $city ($start to $end)";
$stmt = $conn->prepare("INSERT INTO Histories (HistoryID, Title, TopicID, UserID) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $HistoryID, $title, $TPID, $_SESSION['user_id']);
$stmt->execute();

// Step 7: 保存 TripPlanDetails
$day_counter = 0;
foreach ($plan as $day) {
    $date = (clone $start_date)->modify("+$day_counter days")->format('Y-m-d');
    foreach ($day as $p) {
        $PDID = getNextID($conn, 'TripPlanDetails', 'PDID', 'PD');
        $time = '09:00:00';
        $place_id = $p['place_id'];
        $recommend_meals = $p['recommend_meals'];

        $stmt = $conn->prepare("INSERT INTO TripPlanDetails (PDID, Date, Time, PlaceID, RecommendMeals, TPID) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $PDID, $date, $time, $place_id, $recommend_meals, $TPID);
        $stmt->execute();
    }
    $day_counter++;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Your Trip Plan</title>
<link rel="stylesheet" href="/Wayo/CSS/NavigationBar.css" />
<link rel="stylesheet" href="/Wayo/CSS/TripPlan.css" />
<link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
<style>
    /* TripPlan.css */
    input,
        button,
        select,
        textarea,
        label {
            font-family: 'Poppins', sans-serif;
        }

    body {
        font-family: 'Poppins', sans-serif;
        margin: 20px;
        background: linear-gradient(to bottom, #cfe8f9, #fbeacc);
        color: #333;
        font-family: 'Poppins', sans-serif;
    }

    h1,
    h2 {
        text-align: center;
        color: #444;
    }

    .day-plan {
        background: white;
        padding: 25px;
        margin: 0 auto 25px;
        border-radius: 14px;
        width: 90%;
        max-width: 90%;
        box-shadow: 0 6px 16px rgba(0, 0, 0, 0.12);
    }

    .day-plan ul {
        list-style: none;
        padding: 0;
        margin: 0;
    }

    .day-plan li {
        text-align: center;
        margin-bottom: 15px;
        position: relative;
    }

    .day-plan li:not(:last-child)::after {
        content: '';
        display: block;
        width: 2px;
        height: 40px;
        background: repeating-linear-gradient(to bottom,
                pink,
                pink 4px,
                transparent 4px,
                transparent 8px);
        margin: 10px auto;
    }

    .place-photo {
        width: 100%;
        max-width: 250px;
        height: 180px;
        /* 固定高度 */
        object-fit: cover;
        /* 保持比例裁切 */
        border-radius: 10px;
        margin-bottom: 8px;
    }


    a {
        text-decoration: none;
        color: #3b82f6;
        /* 蓝色 */
        font-weight: 500;
    }

    a:hover {
        text-decoration: underline;
    }

    .nav-buttons {
        text-align: center;
        margin-top: 20px;
    }

    .nav-buttons button {
        background: #fcb6c1;
        /* 浅粉色按钮 */
        border: none;
        color: #fff;
        font-weight: bold;
        padding: 8px 16px;
        margin: 5px;
        border-radius: 8px;
        cursor: pointer;
        transition: background 0.3s;
    }

    .nav-buttons button:hover {
        background: #f88fa1;
    }

    .place-item {
        display: flex;
        align-items: center;
        justify-content: center;
        margin-bottom: 20px;
        flex-wrap: wrap;
    }

    .place-item.odd {
        flex-direction: row;
        /* 图片左 文字右 */
    }

    .place-item.even {
        flex-direction: row-reverse;
        /* 图片右 文字左 */
    }

    .place-text {
        max-width: 60%;
        margin: 0 10px;
    }

    .trip-plan {
        padding: 10px;
        position: relative;
        width: 70%;
        /* margin: auto; */
    }

    .trip-wrapper {
        display: flex;
        flex-direction: column;   /* stack vertically */
        align-items: center;      /* center horizontally */
        justify-content: center;  /* center vertically inside parent if you want */
        margin: 0 auto;           /* center container itself if limited width */
    }

    .trip-info {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        background: rgba(255, 255, 255, 0.85);
        padding: 10px 15px;
        border-radius: 10px;
        margin-bottom: 15px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        gap: 8px;
        width: 64%;
    }

    .trip-info input[type="text"],
    .trip-info input[type="date"],
    .trip-info input[type="number"] {
        padding: 6px 10px;
        border: 1px solid #ccc;
        border-radius: 6px;
        font-size: 0.9em;
        flex: 1 1 auto;
        min-width: 100px;
        background: #fff;
    }

    .trip-info .trip-title {
        font-weight: bold;
        margin-right: 8px;
        flex: 0 0 auto;
    }

    .trip-info button {
        background: #fcb6c1;
        border: none;
        color: #fff;
        padding: 6px 12px;
        border-radius: 6px;
        cursor: pointer;
        font-size: 0.9em;
    }

    .trip-info button:hover {
        background: #f88fa1;
    }


    .day-nav {
        display: flex;
        justify-content: center;
        margin-bottom: 10px;
    }

    .day-nav button {
        margin: 0 5px;
        background: #fcb6c1;
        color: #fff;
        border: none;
        padding: 5px 10px;
        border-radius: 8px;
        cursor: pointer;
    }

    .day-nav button.active {
        background: #f88fa1;
    }

    .place-description {
        font-size: 0.9em;
        color: #666;
        margin: 2px 0;
    }

    .place-links a {
        font-size: 0.85em;
        margin-right: 8px;
        color: #007BFF;
        text-decoration: none;
    }

    .place-links a:hover {
        text-decoration: underline;
    }
</style>
</head>
<body>
    <div class="trip-wrapper">
        <div class="trip-info">
            <span class="trip-title">Destination:</span>
            <input type="text" id="city-input" value="<?php echo htmlspecialchars($city); ?>" placeholder="City">
            <button id="edit-info-btn">Save</button>
        </div>
        <div class="trip-info">
            <span class="trip-title">Departure Time</span>
            <input type="date" id="start-input" value="<?php echo htmlspecialchars($start); ?>">
            <span class="start-end">----</span>
            <span class="trip-title">Return Time</span>
            <input type="date" id="end-input" value="<?php echo htmlspecialchars($end); ?>">
        </div>
        <div class="trip-info">
            <span class="trip-title">Pax</span>
            <span class="trip-title">Adult</span>
            <input type="number" id="adults-input" value="<?php echo $adults; ?>" min="0" placeholder="Adults">
            <span class="trip-title">Children</span>
            <input type="number" id="children-input" value="<?php echo $children; ?>" min="0" placeholder="Children">
        </div>
        <div class="trip-plan">
            <div class="day-nav">
                <?php
                for($i=0;$i<$days;$i++){
                echo "<button onclick='showDay($i)' id='day-btn-$i'>Day ".($i+1)."</button>";
                }
                ?>
            </div>
            <div id="plan-container">
                <?php
                    $day_idx = 0;
                    foreach ($plan as $day) {
                        echo "<div class='day-plan' data-day='$day_idx' style='".($day_idx==0?'':'display:none')."'>";
                        echo "<h2>Day ".($day_idx+1)."</h2><ul>";
                        $idx=0;
                        foreach ($day as $p) {
                            if (!$p['photo_reference']) continue;
                            $odd_even = ($idx % 2 == 0) ? 'odd' : 'even';
                            echo "<li class='place-item $odd_even' data-pdid='{$p['place_id']}'>";
                            echo "<img src='".htmlspecialchars($p['photo_url'])."' class='place-photo'>";
                            echo "<div class='place-text'>";
                            echo "<span class='place-name'>".htmlspecialchars($p['name'])."</span>";
                            echo "<input type='text' class='place-input' value='".htmlspecialchars($p['name'])."' style='display:none;'>";
                            echo "<p class='place-description'>".htmlspecialchars($p['description'])."</p>";

                            $lat = $p['geometry']['location']['lat'];
                            $lng = $p['geometry']['location']['lng'];
                            $maps_link = "https://www.google.com/maps/search/?api=1&query=$lat,$lng";
                            $food_search_link = "https://www.google.com/maps/search/restaurants/@$lat,$lng,15z";

                            echo "<div class='place-links'>";
                            echo "<a href='".htmlspecialchars($maps_link)."' target='_blank'>📍 Navigate</a>";
                            echo " | ";
                            echo "<a href='".htmlspecialchars($food_search_link)."' target='_blank'>🍽 Nearby Food</a>";
                            echo "</div>";
                            echo "</div></li>";
                            $idx++;
                        }
                        echo "</ul></div>";
                        $day_idx++;
                    }
                ?>
            </div>
            <div class="nav-buttons">
                <button onclick="prevDay()">Previous</button>
                <button onclick="nextDay()">Next</button>
            </div>
        </div>
    </div>

    

    <script>
        let editing = false;
        document.getElementById('edit-info-btn').addEventListener('click', ()=>{
        editing = !editing;
        ['city','start','end','adults','children'].forEach(id=>{
            document.getElementById(id+'-text').style.display = editing ? 'none' : 'inline';
            document.getElementById(id+'-input').style.display = editing ? 'inline' : 'none';
        });
        document.getElementById('edit-info-btn').innerText = editing ? 'Save' : 'Edit';
        if (!editing) {
            // 保存：发送 AJAX 更新数据库
            saveTripInfo();
        }
        });
        function saveTripInfo(){
        const data = {
            city: document.getElementById('city-input').value,
            start: document.getElementById('start-input').value,
            end: document.getElementById('end-input').value,
            adults: document.getElementById('adults-input').value,
            children: document.getElementById('children-input').value
        };
        fetch('UpdateTripPlan.php', {
            method:'POST',
            headers:{'Content-Type':'application/json'},
            body: JSON.stringify(data)
        }).then(res=>res.text()).then(alert);
        }
        let current = 0;
        const total = document.querySelectorAll('.day-plan').length;
        function showDay(idx){
        document.querySelectorAll('.day-plan').forEach((el,i)=>{
            el.style.display = (i==idx)?'block':'none';
            document.getElementById('day-btn-'+i).classList.toggle('active', i==idx);
        });
        current=idx;
        updateNavButtons();
        }
        function nextDay(){ if (current<total-1) showDay(current+1);}
        function prevDay(){ if (current>0) showDay(current-1);}
        function updateNavButtons(){
        document.querySelector('.nav-buttons button[onclick="prevDay()"]').style.display = (current==0)?'none':'inline-block';
        document.querySelector('.nav-buttons button[onclick="nextDay()"]').style.display = (current==total-1)?'none':'inline-block';
        }
        showDay(0);
        function editPlace(btn){
            const parent = btn.parentNode;
            const span = parent.querySelector('.place-name');
            const input = parent.querySelector('.place-input');
            const editing = input.style.display=='inline-block';
            if(editing){
                // save
                span.innerText = input.value;
                input.style.display='none';
                span.style.display='inline';
                btn.innerText='Edit';
                savePlace(parent.parentNode.dataset.pdid, input.value);
            }else{
                input.style.display='inline-block';
                span.style.display='none';
                btn.innerText='Save';
            }
            }
            function savePlace(pdid, name){
            fetch('UpdatePlace.php',{
                method:'POST',
                headers:{'Content-Type':'application/json'},
                body:JSON.stringify({pdid:pdid,name:name})
            }).then(res=>res.text()).then(alert);
            }
    </script>
<a href="Dashboard.php">← Back to Dashboard</a>
<nav class="wayo-bottom-nav">
    <a href="Dashboard.php" class="logo" title="Dashboard"><img src="/Wayo/Image/Logo.png" alt="Logo" class="logo-img"></a>
    <div class="nav-icons">
        <a href="Dashboard.php" title="Trip Planner">📝</a>
        <a href="RouteOpti.php" title="Route">🛣️</a>
        <a href="Rank.php" title="Ranking">📊</a>
        <a href="Profile.php" title="Profile">👤</a>
        <a href="Login.php" title="Logout">🚪</a>
    </div>
</nav>
</body>
</html>
