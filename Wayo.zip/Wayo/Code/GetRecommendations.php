<?php
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'Not logged in']);
    exit;
}

$loggedInUserID = $_SESSION['user_id'];
$clusterCSVPath = '/Applications/XAMPP/xamppfiles/htdocs/Wayo/R/user_clusters.csv';
$apiKey = 'AIzaSyA45pztm_eOgf1xJpaucfN_9uIpV6FM2GA';

// Load cluster map
$handle = fopen($clusterCSVPath, 'r');
if (!$handle) {
    echo json_encode(['error' => 'Unable to open user_clusters.csv']);
    exit;
}
fgetcsv($handle);
$clusterMap = [];
while (($data = fgetcsv($handle)) !== false) {
    $clusterMap[$data[0]] = $data[1];
}
fclose($handle);

if (!isset($clusterMap[$loggedInUserID])) {
    echo json_encode(['error' => 'User cluster not found']);
    exit;
}
$userCluster = $clusterMap[$loggedInUserID];
$matchedUsers = array_keys(array_filter($clusterMap, fn($c) => $c === $userCluster));

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Wayo";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    echo json_encode(['error' => 'DB connection failed']);
    exit;
}

$placeIDs = [];

foreach ($matchedUsers as $userID) {
    $stmt = $conn->prepare("SELECT TopicID FROM Histories WHERE UserID = ?");
    $stmt->bind_param("s", $userID);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $topicID = $row['TopicID'];

        if (strpos($topicID, 'TP') === 0) {
            $tpStmt = $conn->prepare("SELECT TPID FROM TripPlan WHERE UserID = ? AND TPID = ?");
            $tpStmt->bind_param("ss", $userID, $topicID);
            $tpStmt->execute();
            $tpResult = $tpStmt->get_result();
            if ($tpResult->num_rows > 0) {
                $detailStmt = $conn->prepare("SELECT PlaceID FROM TripPlanDetails WHERE TPID = ?");
                $detailStmt->bind_param("s", $topicID);
                $detailStmt->execute();
                $detailResult = $detailStmt->get_result();
                while ($dRow = $detailResult->fetch_assoc()) {
                    $placeIDs[] = $dRow['PlaceID'];
                }
                $detailStmt->close();
            }
            $tpStmt->close();
        } elseif (strpos($topicID, 'ROU') === 0) {
            $routeStmt = $conn->prepare("SELECT RouteID FROM Routes WHERE UserID = ? AND RouteID = ?");
            $routeStmt->bind_param("ss", $userID, $topicID);
            $routeStmt->execute();
            $routeResult = $routeStmt->get_result();
            if ($routeResult->num_rows > 0) {
                $locStmt = $conn->prepare("SELECT PlaceID FROM Locations WHERE RouteID = ?");
                $locStmt->bind_param("s", $topicID);
                $locStmt->execute();
                $locResult = $locStmt->get_result();
                while ($lRow = $locResult->fetch_assoc()) {
                    $placeIDs[] = $lRow['PlaceID'];
                }
                $locStmt->close();
            }
            $routeStmt->close();
        }
    }

    $stmt->close();
}
$conn->close();

// Remove duplicates & limit to 10
$uniquePlaceIDs = array_slice(array_values(array_unique($placeIDs)), 0, 10);

// Get place details using Google Places API
$recommendations = [];
foreach ($uniquePlaceIDs as $placeID) {
    $apiURL = "https://maps.googleapis.com/maps/api/place/details/json?place_id=$placeID&key=$apiKey";
    $response = file_get_contents($apiURL);
    $data = json_decode($response, true);

    if (isset($data['result'])) {
        $place = $data['result'];
        $recommendations[] = [
            'place_id' => $placeID,
            'name' => $place['name'] ?? 'Unknown',
            'photo_reference' => $place['photos'][0]['photo_reference'] ?? null
        ];
    }
}

echo json_encode($recommendations);
?>
