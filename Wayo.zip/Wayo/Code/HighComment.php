<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
// session_start();

// if (!isset($_SESSION['user_id']) || !isset($_SESSION['email'])) {
//     header("Location: /Wayo/Code/Login.php");
//     exit;
// }

$apiKey = 'AIzaSyA45pztm_eOgf1xJpaucfN_9uIpV6FM2GA';
$mode = isset($_POST['mode']) && $_POST['mode'] === 'list' ? 'list' : 'chart';
$lat = isset($_POST['lat']) ? $_POST['lat'] : null;
$lng = isset($_POST['lng']) ? $_POST['lng'] : null;
$places = [];
$error = '';

if ($lat && $lng) {
    try {
        // Step 1: Google Maps API 搜索附近景点
        $type = 'tourist_attraction';
        $radius = 30000; // 半径30公里
        $url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=$lat,$lng&radius=$radius&type=$type&key=$apiKey";

        $data = json_decode(file_get_contents($url), true);
        if (!isset($data['results'])) throw new Exception('No data from Google API');

        foreach ($data['results'] as $place) {
            $places[] = [
                'name' => $place['name'],
                'comments' => $place['user_ratings_total'] ?? 0,
                'rating' => $place['rating'] ?? 0,
                'place_id' => $place['place_id'] ?? ''
            ];
        }
        // Step 2: 排序取前10
        usort($places, function($a, $b) {
            return $b['comments'] - $a['comments'];
        });
        $places = array_slice($places, 0, 50);

        // Step 3: 写 CSV 给 R 用
        $csvFile = __DIR__.'/high_comment.csv';
        $fp = fopen($csvFile, 'w');
        fputcsv($fp, ['name','comments','rating','place_id']);
        foreach ($places as $p) {
            fputcsv($fp, [$p['name'], $p['comments'], $p['rating'], $p['place_id']]);
        }
        fclose($fp);

        // Step 4: 如果是 chart 模式，调用 R
        if ($mode === 'chart') {
            $rscript = '/usr/local/bin/Rscript';
            $rfile = __DIR__.'/plot_high_comment.R';
            exec("$rscript " . escapeshellarg($rfile), $output, $return_var);
            if ($return_var !== 0) {
                $error = "Error running R script!";
            }
        }

    } catch(Exception $e) {
        $error = $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Best Popular Places Nearby</title>
<style>
body { font-family: Arial, sans-serif; background:#f9f9f9; text-align:center; margin:0; padding:20px;}
h2 { margin-top:20px;}
.top-bar { text-align:right; margin-bottom:10px;}
button { padding:6px 12px; margin:5px;}
img { margin-top:10px; }
.list { text-align:left; display:inline-block; margin-top:20px;}
.list-item { background:#fff; padding:10px; margin-bottom:5px; border-radius:6px; box-shadow:0 2px 4px rgba(0,0,0,0.2);}
.error {color:red; margin-top:10px;}
</style>
</head>
<body>
    <h2>Best Popular Places Nearby</h2>

    <?php if (!$lat || !$lng): ?>
        <p>Please allow location access to see popular places near you.</p>
        <button onclick="getLocation()">Allow Location</button>
        <form id="locForm" method="post" style="display:none;">
            <input type="hidden" name="lat" id="lat">
            <input type="hidden" name="lng" id="lng">
            <input type="hidden" name="mode" value="<?= htmlspecialchars($mode) ?>">
        </form>
        <script>
        function getLocation() {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(
                    function(position) {
                        document.getElementById('lat').value = position.coords.latitude;
                        document.getElementById('lng').value = position.coords.longitude;
                        document.getElementById('locForm').submit();
                    },
                    function(error) {
                        alert("Location access denied or unavailable.");
                    }
                );
            } else {
                alert("Geolocation not supported by your browser.");
            }
        }
        </script>
    <?php elseif ($error): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php else: ?>
        <div class="top-bar">
            <form method="post">
                <input type="hidden" name="lat" value="<?= htmlspecialchars($lat) ?>">
                <input type="hidden" name="lng" value="<?= htmlspecialchars($lng) ?>">
                <input type="hidden" name="mode" value="<?= $mode === 'chart' ? 'list' : 'chart' ?>">
                <button type="submit">Switch to <?= $mode === 'chart' ? 'List' : 'Chart' ?></button>
            </form>
        </div>
        <?php if ($mode === 'chart'): ?>
            <img src="high_comment_plot.png?t=<?=time()?>" alt="High Comment Chart">
        <?php else: ?>
            <div class="list">
                <?php foreach($places as $p): ?>
                    <div class="list-item">
                        <?= htmlspecialchars($p['name']) ?> – <?= htmlspecialchars($p['comments']) ?> comments, Rating: <?= htmlspecialchars($p['rating']) ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</body>
</html>
