<?php if (isset($_GET['success']) && $_GET['success'] == 1): ?>
    <div class="success-message">Preferences updated successfully!</div>
<?php endif; ?>

<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: Login.php");
    exit();
}
$user_id = $_SESSION['user_id'];

// Include database connection
include 'db_connection.php';

// Retrieve user preferences (one-to-one)
$sql_pref = "SELECT * FROM UserPreferences WHERE UserID = ?";
$stmt = $conn->prepare($sql_pref);
$stmt->bind_param("s", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$pref = $result->fetch_assoc();

// Retrieve multiple preferred travel types
$sql_travel = "SELECT TravelType FROM UserPreferredTravelTypes WHERE UserID = ?";
$stmt = $conn->prepare($sql_travel);
$stmt->bind_param("s", $user_id);
$stmt->execute();
$res_travel = $stmt->get_result();
$travel_types = [];
while ($row = $res_travel->fetch_assoc()) {
    $travel_types[] = $row['TravelType'];
}

// Retrieve favorite activities
$sql_act = "SELECT Activity FROM UserFavoriteActivities WHERE UserID = ?";
$stmt = $conn->prepare($sql_act);
$stmt->bind_param("s", $user_id);
$stmt->execute();
$res_act = $stmt->get_result();
$activities = [];
while ($row = $res_act->fetch_assoc()) {
    $activities[] = $row['Activity'];
}

// Retrieve favorite cities
$sql_city = "SELECT City FROM UserFavoriteCities WHERE UserID = ?";
$stmt = $conn->prepare($sql_city);
$stmt->bind_param("s", $user_id);
$stmt->execute();
$res_city = $stmt->get_result();
$cities = [];
while ($row = $res_city->fetch_assoc()) {
    $cities[] = $row['City'];
}

$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>My Preferences</title>
<link rel="stylesheet" href="/Wayo/CSS/NavigationBar.css">
<style>
    body {
        font-family: Poppins, sans-serif;
        margin: 0; padding: 0;
        background: #f9f9f9;
    }
    .container {
        max-width: 800px;
        margin: 40px auto;
        background: white;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 2px 6px rgba(0,0,0,0.1);
    }
    h2 { margin-top: 0; }
    label { display: block; margin: 10px 0 5px; }
    input[type="text"], select {
        width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;
    }
    .checkbox-group {
        margin: 10px 0;
    }
    .checkbox-group label {
        display: inline-block;
        margin-right: 15px;
    }
    button {
        margin-top: 15px;
        padding: 10px 20px;
        background: #007bff; color: white;
        border: none; border-radius: 4px;
        cursor: pointer;
    }
</style>
</head>
<body>

<div class="container">
<h2>My Preferences</h2>
<form method="POST" action="UpdatePreferences.php">
    <label>Preferred Budget Range</label>
    <select name="PreferredBudgetRange">
        <option value="Low" <?= ($pref && $pref['PreferredBudgetRange']=='Low')?'selected':'' ?>>Low</option>
        <option value="Medium" <?= ($pref && $pref['PreferredBudgetRange']=='Medium')?'selected':'' ?>>Medium</option>
        <option value="High" <?= ($pref && $pref['PreferredBudgetRange']=='High')?'selected':'' ?>>High</option>
    </select>

    <label>Preferred Travel Season</label>
    <select name="PreferredTravelSeason">
        <option value="Spring" <?= ($pref && $pref['PreferredTravelSeason']=='Spring')?'selected':'' ?>>Spring</option>
        <option value="Summer" <?= ($pref && $pref['PreferredTravelSeason']=='Summer')?'selected':'' ?>>Summer</option>
        <option value="Autumn" <?= ($pref && $pref['PreferredTravelSeason']=='Autumn')?'selected':'' ?>>Autumn</option>
        <option value="Winter" <?= ($pref && $pref['PreferredTravelSeason']=='Winter')?'selected':'' ?>>Winter</option>
    </select>

    <label>Preferences</label>
    <div class="checkbox-group">
        <label><input type="checkbox" name="LikeCulturalExperiences" <?= ($pref && $pref['LikeCulturalExperiences'])?'checked':'' ?>> Cultural Experiences</label>
        <label><input type="checkbox" name="LikeOutdoorAdventures" <?= ($pref && $pref['LikeOutdoorAdventures'])?'checked':'' ?>> Outdoor Adventures</label>
        <label><input type="checkbox" name="LikeRelaxingPlaces" <?= ($pref && $pref['LikeRelaxingPlaces'])?'checked':'' ?>> Relaxing Places</label>
    </div>

    <label>Preferred Travel Types (comma separated)</label>
    <input type="text" name="TravelTypes" value="<?= htmlspecialchars(implode(',', $travel_types)) ?>">

    <label>Favorite Activities (comma separated)</label>
    <input type="text" name="Activities" value="<?= htmlspecialchars(implode(',', $activities)) ?>">

    <label>Favorite Cities (comma separated)</label>
    <input type="text" name="Cities" value="<?= htmlspecialchars(implode(',', $cities)) ?>">

    <button type="submit">Save Preferences</button>
</form>
</div>

    <nav class="wayo-bottom-nav">
        <a href="Dashboard.php" class="logo" title="Dashboard">
            <img src="/Wayo/Image/Logo.png" alt="Logo" class="logo-img">
        </a>
        <div class="nav-icons">
            <a href="Dashboard.php" title="Trip Planner">📝</a>
            <a href="RouteOpti.php" title="Route Recommendation">🛣️</a>
            <a href="Rank.php" title="Ranking">📊</a>
            <a href="Profile.php" title="Profile">👤</a>
            <a href="Login.php" title="Logout">🚪</a>
        </div>
  </nav>
</body>
</html>
