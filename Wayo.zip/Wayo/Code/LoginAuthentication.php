<?php
session_start();
include 'db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $providedEmail = trim($_POST["email"]); // Trim input
    $password = $_POST["password"];
    $role = $_POST["role"]; // Retrieve role from form data
    

    $loginQuery = "SELECT * FROM Users WHERE Email = '$providedEmail'";
    $result = $conn->query($loginQuery);

    if (!$result) {
        die("Error: " . $conn->error);
    }

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();

        $storedPassword = trim($row['Password']);
        $storedRole = $row['Role'];
        $status = $row['Status'];

        if ($password === $storedPassword && strtolower($role) === strtolower($storedRole)) { // Compare roles ignoring case
            // Password is correct and role matches
            $_SESSION['user_id'] = $row['UserID']; // Store the user ID in session
            $_SESSION['email'] = $providedEmail;
            $_SESSION['success_message'] = 'Login successful. Welcome!';

            if ($status == 'Inactive') {
                header("Location: InactiveAccount.php");
            } else {
                if (strtolower($role) === 'member') { // Compare roles ignoring case
                    if ($row['PasswordReset']){
                        header("Location: ResetPassword.php");
                    } else {
                        header("Location: Dashboard.php");
                    }
                } elseif (strtolower($role) === 'admin') { // Compare roles ignoring case
                    header("Location: AdminDashboard.php");
                } else {
                    $_SESSION['error_message'] = 'Invalid role.';
                    header("Location: Login.php"); // Redirect to login page
                }
                exit();
            }
        } else {
            $_SESSION['error_message'] = 'Invalid email, password, or role.';
            if (isset($_SERVER['HTTP_REFERER'])) {
                $previous_page = basename(parse_url($_SERVER['HTTP_REFERER'], PHP_URL_PATH));
            
                if ($previous_page === 'Login.php') {
                    header("Location: Login.php");
                } elseif ($previous_page === 'AdminLogin.php') {
                    header("Location: AdminLogin.php");
                } else {
                    // Default redirection if the previous page is not recognized
                    header("Location: Login.php");
                }
            } else {
                // Default redirection if HTTP_REFERER is not set
                header("Location: Login.php");
            }
            exit();
        }
    } else {
        $_SESSION['error_message'] = 'Invalid email, password, or role.';
        if (isset($_SERVER['HTTP_REFERER'])) {
            $previous_page = basename(parse_url($_SERVER['HTTP_REFERER'], PHP_URL_PATH));
        
            if ($previous_page === 'Login.php') {
                header("Location: Login.php");
            } elseif ($previous_page === 'AdminLogin.php') {
                header("Location: AdminLogin.php");
            } else {
                // Default redirection if the previous page is not recognized
                header("Location: Login.php");
            }
        } else {
            // Default redirection if HTTP_REFERER is not set
            header("Location: Login.php");
        }
        exit();
    }
} else {
    $_SESSION['error_message'] = 'Invalid request.';
    if (isset($_SERVER['HTTP_REFERER'])) {
        $previous_page = basename(parse_url($_SERVER['HTTP_REFERER'], PHP_URL_PATH));
        
        if ($previous_page === 'Login.php') {
            header("Location: Login.php");
        } elseif ($previous_page === 'AdminLogin.php') {
            header("Location: AdminLogin.php");
        } else {
            // Default redirection if the previous page is not recognized
            header("Location: Login.php");
        }
    } else {
        // Default redirection if HTTP_REFERER is not set
        header("Location: Login.php");
    }
    exit();
}
?>
