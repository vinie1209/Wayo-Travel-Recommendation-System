#!/usr/bin/env Rscript
library(ggplot2)
df <- read.csv("high_comment.csv", stringsAsFactors=FALSE)

p <- ggplot(df, aes(x=reorder(name, comments), y=comments, fill=name)) +
     geom_col() +
     coord_flip() +
     labs(
         title="Top Popular Places",      
         x=NULL,                          
         y="Mentions Count"
     ) +
     theme_minimal() +
     theme(
         legend.position="none",
         axis.title.x=element_text(size=12, face="bold"),
         plot.title=element_text(size=14, face="bold")
     )

# 保存图像
ggsave("high_comment_plot.png", plot=p, width=6, height=4)
