<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : '';
if (!isset($_SESSION['email'])) {
    header("Location: Login.php");
    exit;
}

// Include your database connection
include 'db_connection.php';

// 返回附近地点
if (isset($_GET['action']) && $_GET['action'] == 'places') {
    $lat = $_GET['lat'];
    $lng = $_GET['lng'];
    $type = $_GET['type'];
    $apiKey = 'AIzaSyA45pztm_eOgf1xJpaucfN_9uIpV6FM2GA';
    $url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=$lat,$lng&radius=1000&type=$type&key=$apiKey";
    $data = file_get_contents($url);
    echo $data;
    exit;
}

// 保存路线
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['saveRoute'])) {
    $totalDistance = $_POST['totalDistance'];
    $totalDuration = $_POST['totalDuration'];

    // 获取地点数组（前端传来的 json 字符串）
    $locationsJson = $_POST['locations'];
    $locations = json_decode($locationsJson, true);

    if (!$locations || count($locations) == 0) {
        echo "无地点数据";
        exit;
    }

    // 生成新 RouteID
    $result = $conn->query("SELECT RouteID FROM Routes ORDER BY RouteID DESC LIMIT 1");
    if ($result && $row = $result->fetch_assoc()) {
        $lastNum = intval(substr($row['RouteID'], 3));
        $newNum = $lastNum + 1;
        $newRouteId = 'ROU' . str_pad($newNum, 5, '0', STR_PAD_LEFT);
    } else {
        $newRouteId = 'ROU00001';
    }

    // 插入到 Routes
    $stmt = $conn->prepare("INSERT INTO Routes (RouteID, TotalDistance, TotalDuration, UserID) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $newRouteId, $totalDistance, $totalDuration, $user_id);
    if (!$stmt->execute()) {
        echo "保存路线失败: " . htmlspecialchars($stmt->error);
        exit;
    }

    // 查询最后一个 LocationID
    $result = $conn->query("SELECT LocationID FROM Locations ORDER BY LocationID DESC LIMIT 1");
    $lastLocNum = 0;
    if ($result && $row = $result->fetch_assoc()) {
        $lastLocNum = intval(substr($row['LocationID'], 3));
    }

    // 插入每个地点
    $insertStmt = $conn->prepare("INSERT INTO Locations (LocationID, PlaceID, Sequence, RouteID) VALUES (?, ?, ?, ?)");
    foreach ($locations as $index => $placeId) {
        $lastLocNum++;
        $newLocId = 'LOC' . str_pad($lastLocNum, 5, '0', STR_PAD_LEFT);
        $sequence = $index + 1; // 从1开始
        $insertStmt->bind_param("ssis", $newLocId, $placeId, $sequence, $newRouteId);
        if (!$insertStmt->execute()) {
            echo "保存地点失败: " . htmlspecialchars($insertStmt->error);
            exit;
        }
    }

    echo "路线保存成功！";
    exit;
}

// 自动保存到 histories
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['saveHistory'])) {
    $routeId = $_POST['routeId'];
    $title = $_POST['title'];

    // 生成新的 HistoryID
    $result = $conn->query("SELECT HistoryID FROM Histories ORDER BY HistoryID DESC LIMIT 1");
    if ($result && $row = $result->fetch_assoc()) {
        $lastNum = intval(substr($row['HistoryID'], 3));
        $newNum = $lastNum + 1;
        $newHistoryId = 'HIS' . str_pad($newNum, 5, '0', STR_PAD_LEFT);
    } else {
        $newHistoryId = 'HIS00001';
    }

    $stmt = $conn->prepare("INSERT INTO Histories (HistoryID, Title, RouteID, UserID) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $newHistoryId, $title, $routeId, $user_id);
    if ($stmt->execute()) {
        echo "历史记录已保存！";
    } else {
        echo "保存历史记录失败: " . htmlspecialchars($stmt->error);
    }
    exit;
}

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>地图功能演示</title>
    <link rel="stylesheet" href="/Wayo/CSS/RouteOpti.css">
    <link rel="stylesheet" href="/Wayo/CSS/NavigationBar.css" />
    <style>
        html,
        body {
            height: 100%;
            margin: 0;
            padding: 0;
        }


        .wayo-bottom-nav .logo img {
            width: 60px;
            /* 小 logo，比如 40px，根据需要调整 */
            height: auto;
            /* 保持比例 */
            display: block;
        }

        .start-point,
        .waypoint-row,
        .Nearby,
        .RouteOpti {
            display: flex;
            align-items: center;
            width: 100%;
            border: 1px solid #ccc;
            border-radius: 6px;
            overflow: hidden;
            background: white;
            justify-content: center;
        }

        .start-point input.waypoint,
        .waypoint-row input.waypoint {
            flex: 1;
            /* 占满剩余空间 */
            border: none;
            outline: none;
            font-size: 14px;
            background: transparent;
        }

        .start-point button.location-btn,
        .waypoint-row button.add-btn {
            width: 32px;
            /* 固定宽度 */
            height: 32px;
            /* 固定高度 */
            border: none;
            color: white;
            cursor: pointer;
            font-size: 16px;
            border-radius: 6px;
            /* 圆形 */
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background-color 0.3s;
            background-color: #ccc;
        }

        .start-point button.location-btn:hover,
        .waypoint-row.add-btn:hover {
            background-color: #e1e2e4ff;
        }


        /* 保留你原有的其它样式 */
        .container {
            display: flex;
            height: calc(100% - 50px);
        }

        .map-container {
            flex: 0 0 60%;
            height: 100%;
            box-shadow: inset 0 0 10px rgba(0, 0, 0, 0.1);
        }

        #map {
            width: 100%;
            height: 100%;
        }

        .control-panel {
            flex: 0 0 40%;
            display: flex;
            flex-direction: column;
            padding: 15px;
            box-sizing: border-box;
            background: #f9fafb;
            overflow-y: auto;
        }

        .buttons,
        .search-box,
        #route-info {
            background: white;
            border-radius: 12px;
            padding: 15px;
            margin-bottom: 15px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            transition: box-shadow 0.3s;
        }

        .buttons:hover,
        .search-box:hover,
        #route-info:hover {
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }

        .buttons button,
        .search-box button {
            width: 100%;
            margin: 8px;
            padding: 10px;
            font-size: 16px;
            cursor: pointer;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 6px;
            transition: background-color 0.3s;
        }

        .buttons button:hover,
        .search-box button:hover {
            background-color: #0056b3;
        }

        .search-box input {
            border: 1px solid #ccc;
            border-radius: 6px;
            padding: 1%;
        }

        #route-info {
            max-height: 200px;
            overflow-y: auto;
            font-size: 14px;
            color: #333;
        }

        .Nearby .icon {
            font-size: 300%;
            /* 符号偏大 */
            line-height: 1;
        }

        .Nearby .label {
            font-size: 12px;
            /* 文字小一些 */
            margin-top: 4px;
        }

        .Nearby-filter {
            margin-bottom: 10px;
        }

        .Nearby-filter label {
            display: block;
            margin-bottom: 5px;
        }

        input[type="range"] {
            width: 150px;
            vertical-align: middle;
        }

        #ratingLabel,
        #kmLabel {
            margin-left: 10px;
            font-weight: bold;
        }
        #map { width: 100%; height: 600px; }
        .buttons, .search-box {
            position: absolute; top: 10px; z-index: 5;
            background: rgba(255, 255, 255, 0.9);
            padding: 10px; border-radius: 8px;
        }
        .buttons { left: 10px; }
        .search-box { right: 10px; width: 300px; }
        input { margin-bottom: 5px; width: 100%; padding: 5px; }
        button { margin: 2px 0; width: 100%; }
        #route-info {
            position: absolute; right: 10px; top: 250px; z-index: 5;
            background: white; padding: 10px; border-radius: 8px;
            max-height: 300px; overflow-y: auto; width: 300px;
        }

        
    </style>
</head>
<body>
    <div id="map"></div>

    <div class="buttons">
        <button onclick="getLocation()">📍 定位</button>
        <button onclick="findNearby('tourist_attraction')">🏞 附近景点</button>
        <button onclick="findNearby('restaurant')">🍜 附近餐厅</button>
    </div>

    <div class="search-box">
        <div id="waypoints">
            <div style="display: flex;">
                <input type="text" class="waypoint" id="start-point" placeholder="起点">
                <button onclick="detectCurrentLocation()" title="使用当前位置">📍</button>
            </div>
        </div>
        <button onclick="addWaypoint()">➕ 添加地点（最多5个）</button>
        <button onclick="calculateOptimizedRoute()">🚗 最优路线</button>
        <button onclick="saveRoute()">💾 保存路线</button>
    </div>

    <div id="route-info"></div>

    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA45pztm_eOgf1xJpaucfN_9uIpV6FM2GA&libraries=places"></script>
    <script>
    let map, directionsService, directionsRenderer;

    function initMap() {
        map = new google.maps.Map(document.getElementById("map"), { center: {lat:3.139, lng:101.686}, zoom: 13 });
        directionsService = new google.maps.DirectionsService();
        directionsRenderer = new google.maps.DirectionsRenderer();
        directionsRenderer.setMap(map);
    }

    function initAutocompleteForInputs() {
        let inputs = document.querySelectorAll('.waypoint');
        window.placeIds = [];  // 初始化

        inputs.forEach((input, idx) => {
            let autocomplete = new google.maps.places.Autocomplete(input);
            autocomplete.addListener('place_changed', function() {
                let place = autocomplete.getPlace();
                if (place && place.place_id) {
                    window.placeIds[idx] = place.place_id;
                    console.log(`placeIds[${idx}] = `, place.place_id);
                } else {
                    alert("请选择提示列表中的地点，而不是手动输入！");
                }
            });
        });
    }

    function detectCurrentLocation() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                pos => {
                    let latlng = pos.coords.latitude + "," + pos.coords.longitude;
                    // 用 Geocoder 转换为地址
                    let geocoder = new google.maps.Geocoder();
                    geocoder.geocode({ location: { lat: pos.coords.latitude, lng: pos.coords.longitude } }, (results, status) => {
                        if (status === "OK" && results[0]) {
                            document.getElementById('start-point').value = results[0].formatted_address;
                        } else {
                            alert("获取地址失败: " + status);
                        }
                    });
                },
                () => alert("无法获取当前位置")
            );
        } else {
            alert("浏览器不支持定位");
        }
    }

    function addWaypoint() {
        if (document.querySelectorAll('.waypoint').length < 6) {
            let input = document.createElement('input');
            input.type = 'text';
            input.className = 'waypoint';
            input.placeholder = '目的地/途径点';
            document.getElementById('waypoints').appendChild(input);

            let idx = document.querySelectorAll('.waypoint').length - 1;
            let autocomplete = new google.maps.places.Autocomplete(input);
            autocomplete.addListener('place_changed', function() {
                let place = autocomplete.getPlace();
                if (place && place.place_id) {
                    window.placeIds[idx] = place.place_id;
                    console.log(`placeIds[${idx}] = `, place.place_id);
                } else {
                    alert("请选择提示列表中的地点，而不是手动输入！");
                }
            });
        } else {
            alert("最多添加5个！");
        }
    }

    // 全局变量：保存起点和终点 marker
    // 全局变量：保存 endMarker
    let endMarker = null;

    function calculateOptimizedRoute() {
        console.log("准备计算路线，当前 placeIds:", window.placeIds);

        if (window.placeIds.includes(undefined) || window.placeIds.includes(null)) {
            alert("请确保每个地点都从下拉提示中选择，而不是自己打字！");
            return;
        }
        let inputs = document.querySelectorAll('.waypoint');
        if (inputs.length < 2) { 
            alert("请输入起点和至少一个目的地"); 
            return; 
        }

        let origin = inputs[0].value;
        let destinations = Array.from(inputs).slice(1).map(input => ({ location: input.value, stopover: true }));

        directionsService.route({
            origin: origin,
            destination: origin,
            waypoints: destinations,
            optimizeWaypoints: true,
            travelMode: 'DRIVING'
        }, (result, status) => {
            if (status === 'OK') {
                directionsRenderer.setDirections(result);

                let route = result.routes[0];
                let legs = route.legs;
                let totalDistance = 0, totalDuration = 0;
                legs.forEach(leg => {
                    totalDistance += leg.distance.value;
                    totalDuration += leg.duration.value;
                });
                totalDistance = (totalDistance/1000).toFixed(1) + " km";
                totalDuration = Math.round(totalDuration/60) + " mins";

                let newDestination = legs[legs.length - 1].end_address;

                // 添加🏁 marker
                let lastLegEndLocation = legs[legs.length - 1].end_location;
                if (endMarker) endMarker.setMap(null);
                endMarker = new google.maps.Marker({
                    position: lastLegEndLocation,
                    map: map,
                    label: { text: "🏁", color: "black", fontSize: "16px" },
                    title: "终点"
                });

                document.getElementById('route-info').innerHTML =
                    `<b>总距离:</b> ${totalDistance} <br> <b>总时长:</b> ${totalDuration} <br><b>终点:</b> ${newDestination}`;

                // 根据优化后的顺序重排 placeIds
                let optimizedOrder = route.waypoint_order;
                let reorderedPlaceIds = [];
                reorderedPlaceIds.push(window.placeIds[0]); // 起点
                optimizedOrder.forEach(i => {
                    reorderedPlaceIds.push(window.placeIds[i+1]); // +1 因为 placeIds[0] 是起点
                });
                reorderedPlaceIds.push(window.placeIds[0]); // 回到起点作为终点

                window.routeData = {
                    totalDistance,
                    totalDuration,
                    placeIds: reorderedPlaceIds
                };

                // 假设 title 可以简单用日期 + 用户习惯
                let title = "最优路线 " + new Date().toLocaleString();

                // routeId 可以用系统刚生成的，也可以用固定值，如果还没生成，就先用临时占位
                fetch(location.pathname, {
                    method: 'POST',
                    body: new URLSearchParams({
                        saveHistory: 1,
                        routeId: "TEMP_ROUTE",   // 这里要用真正的 RouteID，如果有的话
                        title: title
                    })
                })
                .then(res => res.text())
                .then(msg => console.log(msg))
                .catch(err => console.error("保存历史失败:", err));


                // 清除之前的 marker
                if (window.markers) {
                    window.markers.forEach(m => m.setMap(null));
                }
                window.markers = [];
                let infoWindow = new google.maps.InfoWindow();
                let service = new google.maps.places.PlacesService(map);

                reorderedPlaceIds.forEach((placeId, idx) => {
                    service.getDetails({ placeId: placeId, fields: ['name', 'rating', 'photos', 'formatted_address'] }, (place, status) => {
                        if (status === google.maps.places.PlacesServiceStatus.OK) {
                            let loc = null;
                            if (idx === 0) {
                                loc = legs[0].start_location;
                            } else if (idx === reorderedPlaceIds.length - 1) {
                                loc = legs[legs.length - 1].end_location;
                            } else {
                                loc = legs[idx - 1].end_location;
                            }

                            let marker = new google.maps.Marker({
                                position: loc,
                                map: map,
                                label: { text: String(idx+1), color: "white", fontSize: "12px" }, // label 改成数字
                                title: place.name
                            });

                            marker.addListener('click', () => {
                                let photoUrl = place.photos && place.photos.length > 0 ? place.photos[0].getUrl({maxWidth: 300}) : '';
                                let content = `<div style="max-width:250px;">
                                    <strong>${place.name}</strong><br>
                                    ${place.rating ? `⭐ ${place.rating}<br>` : ''}
                                    ${photoUrl ? `<img src="${photoUrl}" style="width:100%;border-radius:8px;margin-top:5px;">` : ''}
                                    <small>${place.formatted_address}</small>
                                </div>`;
                                infoWindow.setContent(content);
                                infoWindow.open(map, marker);
                            });

                            window.markers.push(marker);
                        } else {
                            console.error("getDetails failed:", status);
                        }
                    });
                });

            } else {
                alert("路线规划失败: " + status);
            }
        });
    }

    function saveRoute() {
        if (!window.routeData || !window.routeData.placeIds || window.routeData.placeIds.length == 0) {
            alert("请先选择所有地点并计算路线");
            return;
        }
        let formData = new FormData();
        formData.append('saveRoute', 1);
        formData.append('totalDistance', routeData.totalDistance);
        formData.append('totalDuration', routeData.totalDuration);
        formData.append('locations', JSON.stringify(routeData.placeIds));
        fetch(location.pathname, { method: 'POST', body: formData })
            .then(res => res.text()).then(msg => alert(msg)).catch(err => alert("保存失败:" + err));
    }

    window.onload = () => {
        initMap();
        initAutocompleteForInputs();
    }
    </script>

    <nav class="wayo-bottom-nav">
        <a href="Dashboard.php" class="logo" title="Dashboard">Logo</a>
        <div class="nav-icons">
            <a href="Dashboard.php" title="Home Page">📝</a>
            <a href="RouteOpti.php" title="Route Recommendation">🛣️</a>
            <a href="Rank.php" title="Ranking">📊</a>
            <a href="Profile.php" title="Profile">👤</a>
            <a href="Login.php" title="Logout">🚪</a>
        </div>
    </nav>
</body>
</html>
