<?php
session_start();
$role = 'member';

// Allow from any origin
header("Access-Control-Allow-Origin: *"); // Use '*' to allow all origins or specify your frontend URL
header("Access-Control-Allow-Methods: POST, GET, OPTIONS"); // Allow specified methods
header("Access-Control-Allow-Headers: Content-Type"); // Allow specified headers

// Handle OPTIONS request for preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204); // No content
    exit;
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Read the raw input
    $data = json_decode(file_get_contents("php://input"), true);
    $email = $data['email'] ?? '';
    $password = $data['password'] ?? '';

    // Here, you should add your logic to authenticate the user with $email and $password
    // For example:
    if ($email === 'test@example.com' && $password === 'password') {
        $_SESSION['user'] = $email; // Set user session
        echo json_encode(['message' => 'Login successful']);
    } else {
        $_SESSION['error_message'] = 'Invalid credentials';
        echo json_encode(['message' => 'Invalid credentials']);
    }
    exit; // Terminate the script
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wayo Login</title>
    <link rel="stylesheet" href="/Wayo/CSS/Login.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Caveat:wght@400..700&family=Space+Grotesk:wght@300..700&display=swap" rel="stylesheet">
</head>
<body>
    <?php
    if (isset($_SESSION['error_message'])) {
        echo '<div class="error"><span class="closebtn" onclick="this.parentElement.style.display=\'none\';">&times;</span>' 
            . htmlspecialchars($_SESSION['error_message']) .
            '</div>';
        unset($_SESSION['error_message']);
    }
    ?>

    <div class="container">
        <div class="logo">
            <img src="/Wayo/Image/Logo.png" alt="logo">
        </div>
        <!-- <h1>Wayo</h1> -->
        <form action="LoginAuthentication.php" method="post">
            <h2>Login</h2>
            <input type="hidden" name="role" value="<?php echo $role; ?>"> <!-- Add hidden input for role -->
            
            <input type="text" id="email" name="email" placeholder="Enter Email" required>
            
            <input type="password" id="password" name="password" placeholder="Enter Password" required>

            <button type="submit" name="submit">Login</button>
        </form>
        <p>Have an account? <a href="RegisterAccount.php">Register an account</a></p>
        <p>Forget password? <a href="ForgetPassword.php">Change password</a></p>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.min.js"></script>
    <script>
    window.onload = function() {
        setTimeout(function() {
            var errorAlert = document.querySelector(".error");
            if (errorAlert) {
                errorAlert.style.opacity = '0';
                setTimeout(function() {
                    errorAlert.style.display = 'none';
                }, 500); 
            }
        }, 1500); 
    };
</script>
</body>
</html>