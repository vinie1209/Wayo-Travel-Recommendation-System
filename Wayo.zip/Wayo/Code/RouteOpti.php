<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : '';
if (!isset($_SESSION['email'])) {
    header("Location: Login.php");
    exit;
}

// Include your database connection
include 'db_connection.php';

// 返回附近地点
if (isset($_GET['action']) && $_GET['action'] == 'places') {
    $lat = $_GET['lat'];
    $lng = $_GET['lng'];
    $type = $_GET['type'];
    $apiKey = 'AIzaSyA45pztm_eOgf1xJpaucfN_9uIpV6FM2GA';
    $url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=$lat,$lng&radius=1000&type=$type&key=$apiKey";
    $data = file_get_contents($url);
    echo $data;
    exit;
}

// 保存路线
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['saveRoute'])) {
    $totalDistance = $_POST['totalDistance'];
    $totalDuration = $_POST['totalDuration'];

    // 获取地点数组（前端传来的 json 字符串）
    $locationsJson = $_POST['locations'];
    $locations = json_decode($locationsJson, true);

    if (!$locations || count($locations) == 0) {
        echo "无地点数据";
        exit;
    }

    // 生成新 RouteID
    $result = $conn->query("SELECT RouteID FROM Routes ORDER BY RouteID DESC LIMIT 1");
    if ($result && $row = $result->fetch_assoc()) {
        $lastNum = intval(substr($row['RouteID'], 3));
        $newNum = $lastNum + 1;
        $newRouteId = 'ROU' . str_pad($newNum, 5, '0', STR_PAD_LEFT);
    } else {
        $newRouteId = 'ROU00001';
    }

    // 插入到 Routes
    $stmt = $conn->prepare("INSERT INTO Routes (RouteID, TotalDistance, TotalDuration, UserID) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $newRouteId, $totalDistance, $totalDuration, $user_id);
    if (!$stmt->execute()) {
        echo "保存路线失败: " . htmlspecialchars($stmt->error);
        exit;
    }

    // 查询最后一个 LocationID
    $result = $conn->query("SELECT LocationID FROM Locations ORDER BY LocationID DESC LIMIT 1");
    $lastLocNum = 0;
    if ($result && $row = $result->fetch_assoc()) {
        $lastLocNum = intval(substr($row['LocationID'], 3));
    }

    // 插入每个地点
    $insertStmt = $conn->prepare("INSERT INTO Locations (LocationID, PlaceID, Sequence, RouteID) VALUES (?, ?, ?, ?)");
    foreach ($locations as $index => $placeId) {
        $lastLocNum++;
        $newLocId = 'LOC' . str_pad($lastLocNum, 5, '0', STR_PAD_LEFT);
        $sequence = $index + 1; // 从1开始
        $insertStmt->bind_param("ssis", $newLocId, $placeId, $sequence, $newRouteId);
        if (!$insertStmt->execute()) {
            echo "保存地点失败: " . htmlspecialchars($insertStmt->error);
            exit;
        }
    }

    echo "路线保存成功！";
    exit;
}

// 自动保存到 histories
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['saveHistory'])) {
    $topicId = $_POST['routeId'];
    $title = $_POST['title'];

    // 生成新的 HistoryID
    $result = $conn->query("SELECT HistoryID FROM Histories ORDER BY HistoryID DESC LIMIT 1");
    if ($result && $row = $result->fetch_assoc()) {
        $lastNum = intval(substr($row['HistoryID'], 3));
        $newNum = $lastNum + 1;
        $newHistoryId = 'HIS' . str_pad($newNum, 5, '0', STR_PAD_LEFT);
    } else {
        $newHistoryId = 'HIS00001';
    }

    $stmt = $conn->prepare("INSERT INTO Histories (HistoryID, Title, TopicID, UserID) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $newHistoryId, $title, $topicId, $user_id);
    if ($stmt->execute()) {
        echo "历史记录已保存！";
    } else {
        echo "保存历史记录失败: " . htmlspecialchars($stmt->error);
    }
    exit;
}

// 自动保存最佳路线：Routes (Save=false), Locations, Histories
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['bestRoute'])) {
    $totalDistance = $_POST['totalDistance'];
    $totalDuration = $_POST['totalDuration'];
    $locationsJson = $_POST['locations'];
    $locations = json_decode($locationsJson, true);
    $title = $_POST['title'];

    if (!$locations || count($locations) == 0) {
        echo "无地点数据";
        exit;
    }

    // 新 RouteID
    $result = $conn->query("SELECT RouteID FROM Routes ORDER BY RouteID DESC LIMIT 1");
    $newRouteId = 'ROU00001';
    if ($result && $row = $result->fetch_assoc()) {
        $lastNum = intval(substr($row['RouteID'], 3));
        $newNum = $lastNum + 1;
        $newRouteId = 'ROU' . str_pad($newNum, 5, '0', STR_PAD_LEFT);
    }

    // 插 Routes（Save=false）
    $stmt = $conn->prepare("INSERT INTO Routes (RouteID, TotalDistance, TotalDuration, Save, UserID) VALUES (?, ?, ?, false, ?)");
    $stmt->bind_param("ssss", $newRouteId, $totalDistance, $totalDuration, $user_id);
    if (!$stmt->execute()) {
        echo "保存路线失败: " . htmlspecialchars($stmt->error);
        exit;
    }

    // 插 Locations
    $result = $conn->query("SELECT LocationID FROM Locations ORDER BY LocationID DESC LIMIT 1");
    $lastLocNum = 0;
    if ($result && $row = $result->fetch_assoc()) {
        $lastLocNum = intval(substr($row['LocationID'], 3));
    }

    $insertStmt = $conn->prepare("INSERT INTO Locations (LocationID, PlaceID, Sequence, RouteID) VALUES (?, ?, ?, ?)");
    foreach ($locations as $index => $placeId) {
        $lastLocNum++;
        $newLocId = 'LOC' . str_pad($lastLocNum, 5, '0', STR_PAD_LEFT);
        $sequence = $index + 1;
        $insertStmt->bind_param("ssis", $newLocId, $placeId, $sequence, $newRouteId);
        if (!$insertStmt->execute()) {
            echo "保存地点失败: " . htmlspecialchars($insertStmt->error);
            exit;
        }
    }

    // 插 Histories
    $result = $conn->query("SELECT HistoryID FROM Histories ORDER BY HistoryID DESC LIMIT 1");
    $newHistoryId = 'HIS00001';
    if ($result && $row = $result->fetch_assoc()) {
        $lastNum = intval(substr($row['HistoryID'], 3));
        $newNum = $lastNum + 1;
        $newHistoryId = 'HIS' . str_pad($newNum, 5, '0', STR_PAD_LEFT);
    }

    $stmt2 = $conn->prepare("INSERT INTO Histories (HistoryID, Title, TopicID, UserID) VALUES (?, ?, ?, ?)");
    $stmt2->bind_param("ssss", $newHistoryId, $title, $newRouteId, $user_id);
    if (!$stmt2->execute()) {
        echo "保存历史记录失败: " . htmlspecialchars($stmt2->error);
        exit;
    }

    // 返回新 RouteID
    echo $newRouteId;
    exit;
}

// 用户点击“保存路线”时只更新 Save=true
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['markSave'])) {
    $routeId = $_POST['routeId'];
    $stmt = $conn->prepare("UPDATE Routes SET Save=true WHERE RouteID=? AND UserID=?");
    $stmt->bind_param("ss", $routeId, $user_id);
    if ($stmt->execute()) {
        echo "路线已保存！";
    } else {
        echo "保存失败: " . htmlspecialchars($stmt->error);
    }
    exit;
}


?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>地图功能演示</title>
    <link rel="stylesheet" href="/Wayo/CSS/RouteOpti.css">
    <link rel="stylesheet" href="/Wayo/CSS/NavigationBar.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/nouislider@15.7.0/dist/nouislider.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/nouislider@15.7.0/dist/nouislider.min.js"></script>
    <style>

        input,
        button,
        select,
        textarea,
        label {
            font-family: 'Poppins', sans-serif;
        }

        html,
        body {
            height: 100%;
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
        }


        .wayo-bottom-nav .logo img {
            width: 60px;
            height: auto;
            display: block;
        }

        
        .start-point,
        .waypoint-row,
        .RouteOpti {
            display: flex;
            /* align-items: center; */
            width: 100%;
            border: 0.5px solid #ccc;
            border-radius: 6px;
            overflow: hidden;
            background: white;
            /* justify-content: center; */
        }

        .RouteOpti {
            justify-content: flex-end;
            border: none;
        }

        .RouteOpti button {
            border: none;
            padding: 8px 12px;
            cursor: pointer;
            font-size: 0.9em;
            background: transparent;
            flex-shrink: 0;
        }

        /* 70%, 15%, 15% layout */
        .RouteOpti .bestroute-btn {
            flex: 0 0 70%;
        }

        .bestroute-btn {
            position: relative;
            overflow: hidden;
            width: 100%;
            max-width: 200px;
            padding: 12px 20px;
            font-size: 1em;
            font-family: 'Poppins', sans-serif;
            color: white;
            background: linear-gradient(to right, #7ec850, #4caf50); /* green ground */
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background 0.3s;
            }

            .bestroute-btn::before {
            content: "🌳🏢🌳🏠";
            position: absolute;
            top: 50%;
            left: 10px;
            transform: translateY(-50%);
            font-size: 1.2em;
            opacity: 0.3;
            }

            .bestroute-btn .car {
            display: inline-block;
            transition: transform 1s ease-out;
            }

            .car {
                margin-right: 6px;  
            }

            @keyframes driveLeft {
            0% {
                transform: translateX(0);
            }
            100% {
                transform: translateX(-100px);
            }
            }

        .RouteOpti .save-btn,
        .RouteOpti .share-btn {
            flex: 0 0 10%;
        }

        .start-point input.waypoint,
        .waypoint-row input.waypoint {
            flex: 1;
            /* 占满剩余空间 */
            border: none;
            outline: none;
            font-size: 14px;
            background: transparent;
        }

        .start-point button.location-btn,
        .waypoint-row button.add-btn {
            width: 32px;
            /* 固定宽度 */
            height: 32px;
            /* 固定高度 */
            border: none;
            color: white;
            cursor: pointer;
            font-size: 16px;
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background-color 0.3s;
            background-color: #ccc;
        }

        .start-point button.location-btn:hover,
        .waypoint-row.add-btn:hover {
            background-color: #02aed4ff;
        }


        /* 保留你原有的其它样式 */
        .container {
            display: flex;
            height: calc(100% - 50px);
        }

        .map-container {
            flex: 0 0 60%;
            height: 100%;
            box-shadow: inset 0 0 10px rgba(0, 0, 0, 0.1);
        }

        #map {
            width: 100%;
            height: 100%;
        }

        .control-panel {
            flex: 0 0 40%;
            display: flex;
            flex-direction: column;
            padding: 15px;
            box-sizing: border-box;
            background: #6896AD;
            overflow-y: auto;
        }

        .buttons,
        .search-box,
        #route-info {
            background: #fde8d2ff;
            border-radius: 12px;
            padding: 15px;
            margin-bottom: 15px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            transition: box-shadow 0.3s;
        }

        .buttons:hover,
        .search-box:hover,
        #route-info:hover {
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }

        .buttons button,
        .search-box button {
            width: 100%;
            margin: 8px;
            padding: 10px;
            font-size: 16px;
            cursor: pointer;
            background-color: #63C5DA;
            color: white;
            border: none;
            border-radius: 6px;
            transition: background-color 0.3s;
        }

        .buttons button:hover,
        .search-box button:hover {
            background-color: #02aed4ff;
        }

        .search-box input {
            border: 1px solid #ccc;
            border-radius: 6px;
            padding: 1%;
        }

        #route-info {
            min-height: 800px;        /* always keep space reserved */
            max-height: 200px;
            overflow-y: auto;
            font-size: 14px;
            color: #333;
            display: none;
        }

        #route-info.has-content {
            display: block;          /* show when content is present */
        }

        input[type="range"] {
            width: 150px;
            vertical-align: middle;
        }

        #ratingLabel,
        #kmLabel {
            margin-left: 10px;
            font-weight: bold;
        }

        .NearbySearch,
        .BestRoute {
            background: white;
            border-radius: 12px;
            padding: 15px;
            margin-bottom: 15px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        /* Keep filter stacked naturally */
        .Nearby-filter {
            margin-bottom: 10px;
        }

        /* Make last three buttons flex row inside the box */
        .Nearby {
            display: flex;
            justify-content: space-around;  /* or space-between / center */
            gap: 8px;  /* optional, add spacing between buttons */
            border: none;
        }

        /* Style each button inside Nearby */
        .Nearby button {
            border: none;
            cursor: pointer;
            text-align: center;
            flex: 1;          
            padding-left: 5px;
            padding-right: 5px;
            padding-top: 10px;     
            padding-bottom: 10px;       
        }

        .Nearby .icon {
            font-size: 200%;   /* adjust size */
            line-height: 1;
        }

        .Nearby .label {
            font-size: 12px;
            margin-top: 4px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="map-container">
            <div id="map"></div>
        </div>
        <div class="control-panel">

            <div class="search-box">
                <div class="BestRoute">
                    <label style="font-weight: bold; display: inline-block; margin-bottom: 8px;">Best Route Search</label>
                    <div id="waypoints">
                        <div class="start-point">
                            <input type="text" class="waypoint" id="start-point" placeholder="Start Point">
                            <button onclick="detectCurrentLocation()" class="location-btn" title="使用当前位置">📍</button>
                        </div>

                        <!-- 新增：默认一个 waypoint 输入框带 + 按钮 -->
                        <div class="waypoint-row">
                            <input type="text" class="waypoint" placeholder="Destination/Way Point">
                            <button type="button" class="add-btn" onclick="addWaypoint()">＋</button>
                        </div>
                    </div>

                    <div class="RouteOpti">
                        <button class="bestroute-btn" onclick="calculateOptimizedRoute(); animateCar(this)"><span class="car">🚗</span>GO</button>
                        <button class="save-btn" title="Save" onclick="saveRoute()">⭐</button>
                        <button class="share-btn" title="Share" onclick="saveRoute()">🔗</button>
                    </div>
                </div>
                
                <div class="NearbySearch">
                    <label style="font-weight: bold; display: inline-block; margin-bottom: 8px;">Nearby Search</label>
                    <div class="Nearby-filter">
                        <label>Rating Range: </label>
                            <input type="range" id="minRating" min="1" max="5" step="1" value="1" oninput="updateRatingLabel()">
                            <input type="range" id="maxRating" min="1" max="5" step="1" value="5" oninput="updateRatingLabel()">
                            <span id="ratingLabel">1 - 5</span>
                        

                        <label>Km Range: </label>
                            <input type="range" id="radiusKm" min="10" max="100" step="10" value="30" oninput="updateKmLabel()">
                            <span id="kmLabel">30 km</span>
                        
                    </div>
                    <div class="Nearby">
                        <button onclick="findNearby('tourist_attraction')">
                            <div class="icon">🏞</div>
                            <div class="label">Viewpoint</div>
                        </button>
                        <button onclick="findNearby('restaurant')">
                            <div class="icon">🍜</div>
                            <div class="label">Restaurant</div>
                        </button>
                        <button onclick="findNearby('shopping_mall')">
                            <div class="icon">🛍️</div>
                            <div class="label">Mall</div>
                        </button>
                    </div>
                </div>
                
            </div>

            <div id="route-info"></div>
        </div>
    </div>

    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA45pztm_eOgf1xJpaucfN_9uIpV6FM2GA&libraries=places"></script>
    <script>
    let map, directionsService, directionsRenderer;
    let nearbyMarkers = []; // 保存“附近”地点的 marker


    function initMap() {
        map = new google.maps.Map(document.getElementById("map"), { center: {lat:3.139, lng:101.686}, zoom: 13 });
        directionsService = new google.maps.DirectionsService();
        directionsRenderer = new google.maps.DirectionsRenderer();
        directionsRenderer.setMap(map);
    }

    function initAutocompleteForInputs() {
        let inputs = document.querySelectorAll('.waypoint');
        window.placeIds = [];  // 初始化

        inputs.forEach((input, idx) => {
            let autocomplete = new google.maps.places.Autocomplete(input);
            autocomplete.addListener('place_changed', function() {
                let place = autocomplete.getPlace();
                if (place && place.place_id) {
                    window.placeIds[idx] = place.place_id;
                    console.log(`placeIds[${idx}] = `, place.place_id);
                } else {
                    alert("请选择提示列表中的地点，而不是手动输入！");
                }
            });
        });
    }

    function detectCurrentLocation() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                pos => {
                    let latlng = pos.coords.latitude + "," + pos.coords.longitude;
                    // 用 Geocoder 转换为地址
                    let geocoder = new google.maps.Geocoder();
                    geocoder.geocode({ location: { lat: pos.coords.latitude, lng: pos.coords.longitude } }, (results, status) => {
                        if (status === "OK" && results[0]) {
                            document.getElementById('start-point').value = results[0].formatted_address;
                        } else {
                            alert("获取地址失败: " + status);
                        }
                    });
                },
                () => alert("无法获取当前位置")
            );
        } else {
            alert("浏览器不支持定位");
        }
    }

    function addWaypoint(btn) {
        // 限制总共最多6个地点（起点+5个）
        if (document.querySelectorAll('.waypoint').length < 6) {
            let div = document.createElement('div');
            div.className = 'waypoint-row';

            let input = document.createElement('input');
            input.type = 'text';
            input.className = 'waypoint';
            input.placeholder = 'Destination/Way Point';

            let removeBtn = document.createElement('button');
            removeBtn.type = 'button';
            removeBtn.className = 'add-btn';
            removeBtn.textContent = '-';
            removeBtn.onclick = () => {
                div.remove();
                // 可选：同步更新 window.placeIds
                initAutocompleteForInputs();
            };

            div.appendChild(input);
            div.appendChild(removeBtn);
            document.getElementById('waypoints').appendChild(div);

            // 初始化自动补全
            initAutocompleteForInputs();
        } else {
            alert("最多添加5个！");
        }
    }

    // 全局变量：保存起点和终点 marker
    // 全局变量：保存 endMarker
    let endMarker = null;

    function calculateOptimizedRoute() {
        console.log("准备计算路线，当前 placeIds:", window.placeIds);

        if (window.placeIds.includes(undefined) || window.placeIds.includes(null)) {
            alert("请确保每个地点都从下拉提示中选择，而不是自己打字！");
            return;
        }
        let inputs = document.querySelectorAll('.waypoint');
        if (inputs.length < 2) { 
            alert("请输入起点和至少一个目的地"); 
            return; 
        }

        let origin = inputs[0].value;
        let destinations = Array.from(inputs).slice(1).map(input => ({ location: input.value, stopover: true }));

        directionsService.route({
            origin: origin,
            destination: origin,
            waypoints: destinations,
            optimizeWaypoints: true,
            travelMode: 'DRIVING'
        }, (result, status) => {
            if (status === 'OK') {
                directionsRenderer.setDirections(result);

                let route = result.routes[0];
                let legs = route.legs;
                let totalDistance = 0, totalDuration = 0;
                legs.forEach(leg => {
                    totalDistance += leg.distance.value;
                    totalDuration += leg.duration.value;
                });
                totalDistance = (totalDistance/1000).toFixed(1) + " km";
                totalDuration = Math.round(totalDuration/60) + " mins";

                let newDestination = legs[legs.length - 1].end_address;

                // 添加🏁 marker
                let lastLegEndLocation = legs[legs.length - 1].end_location;
                if (endMarker) endMarker.setMap(null);
                endMarker = new google.maps.Marker({
                    position: lastLegEndLocation,
                    map: map,
                    label: { text: "🏁", color: "black", fontSize: "16px" },
                    title: "终点"
                });

                let routeInfoHtml = `<strong><label style="font-weight: bold; display: inline-block; margin-bottom: 8px;">Best Route</label><br><b>总距离:</b> ${totalDistance} <br> <b>总时长:</b> ${totalDuration} <br><br>`;

                legs.forEach((leg, idx) => {
                let startName = leg.start_address.split(',')[0].trim();
                let endName = leg.end_address.split(',')[0].trim();
                let distance = leg.distance.text;
                let duration = leg.duration.text;

                let navigationLink = `https://www.google.com/maps/dir/?api=1&origin=${encodeURIComponent(leg.start_address)}&destination=${encodeURIComponent(leg.end_address)}&travelmode=driving`;

                routeInfoHtml += `
                    <div class="leg-info">
                        <strong>${startName}</strong>  ---〉<strong>${endName}</strong><br>
                        Distance: ${distance}<br>
                        Estimation Time: ${duration}<br>
                        <a href="${navigationLink}" target="_blank">Navigate on Google</a>
                    </div><br>
                `;
            });

                let routeInfo = document.getElementById('route-info');
                routeInfo.innerHTML = routeInfoHtml;
                routeInfo.classList.add('has-content'); 
                routeInfo.scrollIntoView({ behavior: 'smooth', block: 'start' });


                // 根据优化后的顺序重排 placeIds
                let optimizedOrder = route.waypoint_order;
                let reorderedPlaceIds = [];
                reorderedPlaceIds.push(window.placeIds[0]); // 起点
                optimizedOrder.forEach(i => {
                    reorderedPlaceIds.push(window.placeIds[i+1]); // +1 因为 placeIds[0] 是起点
                });
                reorderedPlaceIds.push(window.placeIds[0]); // 回到起点作为终点

                window.routeData = {
                    totalDistance,
                    totalDuration,
                    placeIds: reorderedPlaceIds
                };

                // routeId 可以用系统刚生成的，也可以用固定值，如果还没生成，就先用临时占位
                let title = "Best Route " + new Date().toLocaleString();
                let formData = new FormData();
                formData.append('bestRoute', 1);
                formData.append('totalDistance', totalDistance);
                formData.append('totalDuration', totalDuration);
                formData.append('locations', JSON.stringify(reorderedPlaceIds));
                formData.append('title', title);

                fetch(location.pathname, { method: 'POST', body: formData })
                    .then(res => res.text())
                    .then(routeId => {
                        console.log("已保存最佳路线，RouteID:", routeId);
                        window.savedRouteId = routeId; // 存起来
                    })
                    .catch(err => console.error("保存最佳路线失败:", err));


                // 清除之前的 marker
                if (window.markers) {
                    window.markers.forEach(m => m.setMap(null));
                }
                window.markers = [];
                let infoWindow = new google.maps.InfoWindow();
                let service = new google.maps.places.PlacesService(map);

                reorderedPlaceIds.forEach((placeId, idx) => {
                    service.getDetails({ placeId: placeId, fields: ['name', 'rating', 'photos', 'formatted_address'] }, (place, status) => {
                        if (status === google.maps.places.PlacesServiceStatus.OK) {
                            let loc = null;
                            if (idx === 0) {
                                loc = legs[0].start_location;
                            } else if (idx === reorderedPlaceIds.length - 1) {
                                loc = legs[legs.length - 1].end_location;
                            } else {
                                loc = legs[idx - 1].end_location;
                            }

                            let marker = new google.maps.Marker({
                                position: loc,
                                map: map,
                                label: { text: String(idx+1), color: "white", fontSize: "12px" }, // label 改成数字
                                title: place.name
                            });

                            marker.addListener('click', () => {
                                let photoUrl = place.photos && place.photos.length > 0 ? place.photos[0].getUrl({maxWidth: 300}) : '';
                                let content = `<div style="max-width:250px;">
                                    <strong>${place.name}</strong><br>
                                    ${place.rating ? `⭐ ${place.rating}<br>` : ''}
                                    ${photoUrl ? `<img src="${photoUrl}" style="width:100%;border-radius:8px;margin-top:5px;">` : ''}
                                    <small>${place.formatted_address}</small>
                                </div>`;
                                infoWindow.setContent(content);
                                infoWindow.open(map, marker);
                            });

                            window.markers.push(marker);
                        } else {
                            console.error("getDetails failed:", status);
                        }
                    });
                });

            } else {
                alert("路线规划失败: " + status);
                document.getElementById('route-info').innerHTML = '';
                document.getElementById('route-info').classList.remove('has-content');
            }
        });
    }

    function saveRoute() {
        if (!window.savedRouteId) {
            alert("请先生成路线");
            return;
        }
        let formData = new FormData();
        formData.append('markSave', 1);
        formData.append('routeId', window.savedRouteId);
        fetch(location.pathname, { method: 'POST', body: formData })
            .then(res => res.text())
            .then(msg => alert(msg))
            .catch(err => alert("保存失败: " + err));
    }

    window.onload = () => {
        initMap();
        initAutocompleteForInputs();
    }

    function findNearby(type) {
        // 获取用户输入
        let minRating = parseInt(document.getElementById('minRating').value) || 1;
        let maxRating = parseInt(document.getElementById('maxRating').value) || 5;
        let radiusKm = parseInt(document.getElementById('radiusKm').value) || 30;
        let radiusMeters = radiusKm * 1000;

        // 获取当前地图中心坐标
        let center = map.getCenter();
        let lat = center.lat();
        let lng = center.lng();

        fetch(`RouteOpti.php?action=places&lat=${lat}&lng=${lng}&type=${type}&radius=${radiusMeters}`)
            .then(res => res.json())
            .then(data => {
                if (data.status !== 'OK' || !data.results) {
                    alert('未找到结果');
                    return;
                }

                // 根据评分过滤
                let filtered = data.results.filter(place =>
                    place.rating >= minRating && place.rating <= maxRating
                );

                // 清除旧 marker
                if (window.nearbyMarkers) {
                    window.nearbyMarkers.forEach(m => m.setMap(null));
                }
                window.nearbyMarkers = [];

                filtered.forEach(place => {
                    let loc = place.geometry.location;
                    let marker = new google.maps.Marker({
                        position: loc,
                        map: map,
                        title: place.name
                    });

                    let infoWindow = new google.maps.InfoWindow({
                        content: `<div style="max-width:200px">
                            <strong>${place.name}</strong><br>
                            ⭐ ${place.rating || '无评分'}<br>
                            <small>${place.vicinity || ''}</small>
                        </div>`
                    });
                    marker.addListener('click', () => infoWindow.open(map, marker));

                    window.nearbyMarkers.push(marker);
                });

                if (filtered.length === 0) {
                    alert('符合条件的地点未找到');
                }
            })
            .catch(err => {
                console.error(err);
                alert('请求出错');
            });
    }

    function updateRatingLabel() {
        let minRating = parseInt(document.getElementById('minRating').value);
        let maxRating = parseInt(document.getElementById('maxRating').value);

        // 保证 min <= max
        if (minRating > maxRating) {
            // 如果拉过头，让另一个滑块跟随
            if (event.target.id === 'minRating') {
                document.getElementById('maxRating').value = minRating;
                maxRating = minRating;
            } else {
                document.getElementById('minRating').value = maxRating;
                minRating = maxRating;
            }
        }

        document.getElementById('ratingLabel').innerText = `${minRating} - ${maxRating}`;
    }

    function animateCar(btn) {
        let car = btn.querySelector('.car');
        if (!car) {
            // Wrap the text in a span for animation
            btn.innerHTML = '<span class="car">🚗</span>GO ';
            car = btn.querySelector('.car');
        }
        car.style.animation = 'driveLeft 1s forwards';
        // Reset after animation to allow clicking again
        setTimeout(() => {
            car.style.animation = '';
        }, 1000);
    }
    </script>

    <nav class="wayo-bottom-nav">
        <a href="Dashboard.php" class="logo" title="Dashboard">
            <img src="/Wayo/Image/Logo.png" alt="Logo" class="logo-img">
        </a>
        <div class="nav-icons">
            <a href="Dashboard.php" title="Trip Planner">📝</a>
            <a href="RouteOpti.php" title="Route Recommendation">🛣️</a>
            <a href="Rank.php" title="Ranking">📊</a>
            <a href="Profile.php" title="Profile">👤</a>
            <a href="Login.php" title="Logout">🚪</a>
        </div>
    </nav>
</body>
</html>
