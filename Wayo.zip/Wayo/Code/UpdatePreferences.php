<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: Login.php");
    exit();
}
$user_id = $_SESSION['user_id'];

// Include database connection
include 'db_connection.php';

// 接收表单数据
$budget = $_POST['PreferredBudgetRange'];
$season = $_POST['PreferredTravelSeason'];
$like_culture = isset($_POST['LikeCulturalExperiences']) ? 1 : 0;
$like_outdoor = isset($_POST['LikeOutdoorAdventures']) ? 1 : 0;
$like_relax = isset($_POST['LikeRelaxingPlaces']) ? 1 : 0;

$travel_types = array_map('trim', explode(',', $_POST['TravelTypes']));
$activities = array_map('trim', explode(',', $_POST['Activities']));
$cities = array_map('trim', explode(',', $_POST['Cities']));

// === 更新 UserPreferences 表 ===
// 如果用户已经有记录：update；否则 insert
$sql_check = "SELECT PreferenceID FROM UserPreferences WHERE UserID = ?";
$stmt = $conn->prepare($sql_check);
$stmt->bind_param("s", $user_id);
$stmt->execute();
$res = $stmt->get_result();
if ($res->num_rows > 0) {
    // Update
    $sql_update = "UPDATE UserPreferences 
                   SET PreferredBudgetRange=?, PreferredTravelSeason=?, 
                       LikeCulturalExperiences=?, LikeOutdoorAdventures=?, LikeRelaxingPlaces=?
                   WHERE UserID=?";
    $stmt_update = $conn->prepare($sql_update);
    $stmt_update->bind_param("ssiiis", $budget, $season, $like_culture, $like_outdoor, $like_relax, $user_id);
    $stmt_update->execute();
} else {
    // Insert
    $preference_id = 'PREF' . str_pad(rand(0, 99999), 5, '0', STR_PAD_LEFT);
    $sql_insert = "INSERT INTO UserPreferences 
            (PreferenceID, PreferredBudgetRange, PreferredTravelSeason, LikeCulturalExperiences, LikeOutdoorAdventures, LikeRelaxingPlaces, UserID)
            VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt_insert = $conn->prepare($sql_insert);
    $stmt_insert->bind_param("sssiiis", $preference_id, $budget, $season, $like_culture, $like_outdoor, $like_relax, $user_id);
    $stmt_insert->execute();
}

// === 更新多选表：先删除再插入 ===

// // UserPreferredTravelTypes
// $conn->prepare("DELETE FROM UserPreferredTravelTypes WHERE UserID=?")->bind_param("s", $user_id)->execute();
// if (!empty($travel_types)) {
//     $stmt_tt = $conn->prepare("INSERT INTO UserPreferredTravelTypes (TravelType, UserID) VALUES (?, ?)");
//     foreach ($travel_types as $type) {
//         if ($type !== '') {
//             $stmt_tt->bind_param("ss", $type, $user_id);
//             $stmt_tt->execute();
//         }
//     }
// }

// // UserFavoriteActivities
// $conn->prepare("DELETE FROM UserFavoriteActivities WHERE UserID=?")->bind_param("s", $user_id)->execute();
// if (!empty($activities)) {
//     $stmt_act = $conn->prepare("INSERT INTO UserFavoriteActivities (Activity, UserID) VALUES (?, ?)");
//     foreach ($activities as $act) {
//         if ($act !== '') {
//             $stmt_act->bind_param("ss", $act, $user_id);
//             $stmt_act->execute();
//         }
//     }
// }

// // UserFavoriteCities
// $conn->prepare("DELETE FROM UserFavoriteCities WHERE UserID=?")->bind_param("s", $user_id)->execute();
// if (!empty($cities)) {
//     $stmt_city = $conn->prepare("INSERT INTO UserFavoriteCities (City, UserID) VALUES (?, ?)");
//     foreach ($cities as $city) {
//         if ($city !== '') {
//             $stmt_city->bind_param("ss", $city, $user_id);
//             $stmt_city->execute();
//         }
//     }
// }

// ✅ 完成后跳回偏好页面或提示成功
header("Location: UserPreferences.php?success=1");
exit();
?>
