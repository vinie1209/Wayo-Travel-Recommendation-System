<?php
include 'db_connection.php';

// Function to generate a random password
function generateRandomPassword($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*';
    $password = '';
    for ($i = 0; $i < $length; $i++) {
        $password .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $password;
}

// Check if it's an AJAX request to verify the email
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email'])) {
    $email = $_POST['email'];

    $sql = "SELECT * FROM Users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    $response = array();

    if ($result->num_rows > 0) {
        // Email exists, generate a random password
        $randomPassword = generateRandomPassword();

        // Update the password in the database
        $updateSql = "UPDATE Users SET Password = ?, PasswordReset = 1 WHERE email = ?";
        $updateStmt = $conn->prepare($updateSql);
        $updateStmt->bind_param("ss", $randomPassword, $email);
        $updateStmt->execute();
        $updateStmt->close();

        // Prepare response for AJAX call
        $response['exists'] = true;
        $response['randomPassword'] = $randomPassword;
    } else {
        // Email does not exist
        $response['exists'] = false;
    }

    echo json_encode($response);

    $stmt->close();
    $conn->close();
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/Wayo/CSS/Login.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Caveat:wght@400..700&family=Space+Grotesk:wght@300..700&display=swap" rel="stylesheet">
    <title>Forget Password</title>
    <script>
        function checkEmail(event) {
            event.preventDefault(); // Prevent the default form submission

            // Get the email input value
            var email = document.getElementById('email').value;

            // Create a new AJAX request
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    var response = JSON.parse(xhr.responseText);

                    if (response.exists) {
                        // If email exists, show success message
                        displaySuccessMessage();
                        
                        var resetMessage = "Use this password to login and complete the reset process: " + response.randomPassword;
                        var formsubmitForm = document.getElementById('formsubmitForm');
                        formsubmitForm.querySelector('input[name="message"]').value = resetMessage;
                        setTimeout(function() {
                            formsubmitForm.setAttribute('action', 'https://formsubmit.co/' + email); // Set the action dynamically
                            formsubmitForm.submit();
                        }, 3000); // Wait 3 seconds before submitting the form

                        // Optionally display the random password to the user
                        alert("Please refer to your email to complete the password reset.");
                    } else {
                        // If email does not exist, show an error message
                        alert("Account does not exist.");
                    }
                }
            };

            xhr.send("email=" + encodeURIComponent(email));
        }

        function displaySuccessMessage() {
            var messageDiv = document.getElementById('successMessage');
            messageDiv.style.display = 'block'; // Show the success message
        }
    </script>
</head>
<body>
<div class="container">
        <div class="logo">
            <img src="/Wayo/Image/Logo.png" alt="logo">
        </div>
        <form id="passwordResetForm" onsubmit="checkEmail(event)">
            <h2>Reset Password</h2>
            <!-- Add an input field for the email -->
            <label for="email"><strong>Receive a password reset code through your registered email address.</strong></label>
            <input type="email" id="email" name="email" required placeholder="Email">

            <!-- Submit button -->
            <button type="submit">Send Code</button>

        </form>
    </div>
    

        
    <!-- Success message -->
    <div id="successMessage" style="display:none; color: green;">
        Check your email to complete the password reset. Redirecting to login page...
    </div>
    <!-- Hidden form for submitting to FormSubmit.co -->
    <form id="formsubmitForm" action="https://formsubmit.co/your-email@example.com" method="POST">
        <input type="hidden" name="_next" value="http://localhost/Wayo/Code/Login.php">
        <input type="hidden" name="subject" value="Reset Password">
        <input type="hidden" name="message" value="">
    </form>
</body>
</html>
