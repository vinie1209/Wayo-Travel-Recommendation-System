<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // User is not logged in, redirect to login page
    header("Location: Login.php");
    exit();
}

// Include database connection
include 'db_connection.php';

// Initialize variables
$user_id = $_SESSION['user_id'];
$new_password = $confirm_password = '';
$errors = array();
$success_message = '';
$form_submitted = false;

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    // Check if new password matches confirm password
    if ($new_password != $confirm_password) {
        $errors[] = "New password and confirm password do not match.";
    }

    if (empty($errors)) {
        $update_sql = "UPDATE Users SET Password = '$new_password', PasswordReset=0 WHERE UserID = '$user_id'";
        if ($conn->query($update_sql) === TRUE) {
            // Password updated successfully
            $success_message = "Password updated successfully!";
            $form_submitted = true; // Flag to indicate form submission
        } else {
            $errors[] = "Error updating password: " . $conn->error;
        }
    }
}

// Close database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reset Password</title>
    <link rel="stylesheet" href="/Wayo/CSS/ResetPassword.css">
    <script>
        // Confirm leaving page if form is dirty
        window.onbeforeunload = function(event) {
            if (!document.getElementById('form_submitted').value &&
                ( document.getElementById('new_password').value || 
                 document.getElementById('confirm_password').value)) {
                if (event.currentTarget.performance.navigation.type !== 1) {
                    return 'Are you sure you want to leave? Any unsaved changes will be lost.';
                }
            }
        };

        // After reload, redirect to MemberProfile.php if password change successful
        window.onload = function() {
            <?php if (!empty($success_message)): ?>
                alert("<?php echo $success_message; ?>");
                window.location.href = "MemberProfile.php";
            <?php endif; ?>
        };

        // Function to disable onbeforeunload message temporarily
        function disableUnloadMessage() {
            window.onbeforeunload = null;
            document.getElementById('form_submitted').value = 'true';
        }
    </script>
</head>
<body>
    <div class="container">
        <h2>Change Password</h2>
        <?php
        // Display errors if any
        if (!empty($errors)) {
            foreach ($errors as $error) {
                echo '<p class="error">' . $error . '</p>';
            }
        }
        ?>
        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" onsubmit="disableUnloadMessage()">
            <input type="hidden" id="form_submitted" name="form_submitted" value="<?php echo $form_submitted ? 'true' : ''; ?>">
            <div class="form-group">
                <label for="new_password">New Password:</label>
                <input type="password" id="new_password" name="new_password" required>
            </div>
            <div class="form-group">
                <label for="confirm_password">Confirm Password:</label>
                <input type="password" id="confirm_password" name="confirm_password" required>
            </div>
            <button type="submit">Change Password</button>
        </form>
    </div>
</body>
</html>
