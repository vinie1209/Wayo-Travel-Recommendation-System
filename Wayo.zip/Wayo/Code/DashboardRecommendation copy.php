<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

// Check login
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'Not logged in']);
    exit;
}

$loggedInUserID = $_SESSION['user_id'];
$clusterCSVPath = '/Applications/XAMPP/xamppfiles/htdocs/Wayo/R/user_clusters.csv';

// Google Places API Key
$apiKey = 'AIzaSyA45pztm_eOgf1xJpaucfN_9uIpV6FM2GA';

// Step 1: Load user_clusters.csv
$handle = fopen($clusterCSVPath, 'r');
if (!$handle) {
    echo json_encode(['error' => 'Unable to open user_clusters.csv']);
    exit;
}

$headers = fgetcsv($handle); // Skip header
$clusterMap = [];

while (($data = fgetcsv($handle)) !== false) {
    $clusterMap[$data[0]] = $data[1]; // $data[0] = UserID, $data[1] = Cluster
}
fclose($handle);

// Step 2: Get logged-in user's cluster
if (!isset($clusterMap[$loggedInUserID])) {
    echo json_encode(['error' => 'User cluster not found']);
    exit;
}

$userCluster = $clusterMap[$loggedInUserID];

// Step 3: Get all UserIDs in the same cluster
$matchedUsers = array_keys(array_filter($clusterMap, function($cluster) use ($userCluster) {
    return $cluster == $userCluster;
}));

// Step 4: Get Histories with TopicID starting with TP or ROU
$placeIDs = [];

$servername = "localhost";
$username = "root"; // default for XAMPP
$password = "";     // default for XAMPP
$dbname = "Wayo";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

foreach ($matchedUsers as $userID) {
    $stmt = $conn->prepare("SELECT TopicID FROM Histories WHERE UserID = ?");
    $stmt->bind_param("s", $userID);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $topicID = $row['TopicID'];

        if (strpos($topicID, 'TP') === 0) {
            $tpStmt = $conn->prepare("SELECT TPID FROM TripPlan WHERE UserID = ? AND TPID = ?");
            $tpStmt->bind_param("ss", $userID, $topicID);
            $tpStmt->execute();
            $tpResult = $tpStmt->get_result();

            if ($tpResult->num_rows > 0) {
                $detailStmt = $conn->prepare("SELECT PlaceID FROM TripPlanDetails WHERE TPID = ?");
                $detailStmt->bind_param("s", $topicID);
                $detailStmt->execute();
                $detailResult = $detailStmt->get_result();

                while ($dRow = $detailResult->fetch_assoc()) {
                    $placeIDs[] = $dRow['PlaceID'];
                }
                $detailStmt->close();
            }
            $tpStmt->close();

        } elseif (strpos($topicID, 'ROU') === 0) {
            $routeStmt = $conn->prepare("SELECT RouteID FROM Routes WHERE UserID = ? AND RouteID = ?");
            $routeStmt->bind_param("ss", $userID, $topicID);
            $routeStmt->execute();
            $routeResult = $routeStmt->get_result();

            if ($routeResult->num_rows > 0) {
                $locStmt = $conn->prepare("SELECT PlaceID FROM Locations WHERE RouteID = ?");
                $locStmt->bind_param("s", $topicID);
                $locStmt->execute();
                $locResult = $locStmt->get_result();

                while ($lRow = $locResult->fetch_assoc()) {
                    $placeIDs[] = $lRow['PlaceID'];
                }
                $locStmt->close();
            }
            $routeStmt->close();
        }
    }

    $stmt->close();
}

$conn->close();

// Remove duplicates
$uniquePlaceIDs = array_values(array_unique($placeIDs));

// Step 5: Fetch place names using Google Places API and display table
echo "<h2>📍 Recommended Locations (Same Cluster Users)</h2>";

if (empty($uniquePlaceIDs)) {
    echo "<p>No places found from similar users.</p>";
    exit;
}

echo "<table border='1' cellpadding='10' style='border-collapse: collapse;'>
        <tr style='background-color: #f2f2f2;'>
            <th>Place Name</th>
            <th>Place ID</th>
            <th>Google Maps Link</th>
        </tr>";

$recommendLimit = 10;
$count = 0;

foreach ($uniquePlaceIDs as $placeID) {
    if ($count >= $recommendLimit) break;
    $count++;

    $placeName = "Unknown";

    $apiURL = "https://maps.googleapis.com/maps/api/place/details/json?place_id=$placeID&key=$apiKey";
    $response = file_get_contents($apiURL);
    $data = json_decode($response, true);

    if (isset($data['result']['name'])) {
        $placeName = htmlspecialchars($data['result']['name']);
    }

    $mapsURL = "https://www.google.com/maps/place/?q=place_id:$placeID";

    echo "<tr>
            <td>$placeName</td>
            <td>$placeID</td>
            <td><a href='$mapsURL' target='_blank'>Open in Maps</a></td>
          </tr>";
}

echo "</table>";
?>
