<?php
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // User is not logged in, redirect to login page
    header("Location: Login.php");
    exit();
}

// User is logged in, you can use $_SESSION['user_id']
$user_id = $_SESSION['user_id'];

// Include database connection
include 'db_connection.php';

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <title>History</title>
    <link rel="stylesheet" href="/Wayo/CSS/Profile.css">
    <link rel="stylesheet" href="/Wayo/CSS/NavigationBar.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Caveat:wght@400..700&family=Space+Grotesk:wght@300..700&display=swap" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
</head>
<body>  
    <nav class="wayo-bottom-nav">
        <a href="Dashboard.php" class="logo" title="Dashboard">
            <img src="/Wayo/Image/Logo.png" alt="Logo" class="logo-img">
        </a>
        <div class="nav-icons">
            <a href="Dashboard.php" title="Trip Planner">📝</a>
            <a href="RouteOpti.php" title="Route Recommendation">🛣️</a>
            <a href="Rank.php" title="Ranking">📊</a>
            <a href="Profile.php" title="Profile">👤</a>
            <a href="Login.php" title="Logout">🚪</a>
        </div>
    </nav>
</body>
</html>
