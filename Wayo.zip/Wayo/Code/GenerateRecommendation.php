<?php
session_start();
include 'db_connection.php';

$user_id = $_SESSION['user_id'] ?? '';
if (!$user_id) exit;

// Export historical user-place score data (replace table name accordingly)
$result = mysqli_query($conn, "
    SELECT UserID, PlaceID, Score 
    FROM UserPlaceScores
");

$fp = fopen(__DIR__.'/user_item.csv', 'w');
fputcsv($fp, ['UserID','PlaceID','Score']);
while($row = mysqli_fetch_assoc($result)) {
    fputcsv($fp, [$row['UserID'], $row['PlaceID'], $row['Score']]);
}
fclose($fp);

// Call R script
$rscript = '/usr/local/bin/Rscript'; // adjust if Rscript is elsewhere
$rfile = __DIR__.'/DashboardRecommender.R';
exec("$rscript " . escapeshellarg($rfile) . ' ' . escapeshellarg($user_id), $output, $return_var);
?>
