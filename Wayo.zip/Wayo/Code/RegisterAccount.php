<?php
include 'db_connection.php';

// Function to generate a random password
function generateRandomPassword($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*';
    $password = '';
    for ($i = 0; $i < $length; $i++) {
        $password .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $password;
}

function generateUserID($conn) {
    $query = "SELECT UserID FROM Users ORDER BY UserID DESC LIMIT 1";
    $result = $conn->query($query);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $latestUserID = $row['UserID'];
        $latestNumber = (int) substr($latestUserID, 3);
        $newNumber = $latestNumber + 1;
        return 'MEM' . str_pad($newNumber, 5, '0', STR_PAD_LEFT);
    } else {
        return 'MEM00001';
    }
}

// Check if it's an AJAX request to verify the email
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email']) && isset($_POST['name']) && isset($_POST['contact_number']) && isset($_POST['gender'])) {
    $email = $_POST['email'];
    $name = $_POST['name'];
    $contact_number = $_POST['contact_number'];
    $gender = $_POST['gender'];

    ob_start();

    $sql = "SELECT * FROM Users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        error_log("Failed to prepare statement: " . $conn->error);
        die(json_encode(["error" => "Failed to prepare statement: " . $conn->error]));
    }
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    $response = array();

    if ($result->num_rows > 0) {
        // Prepare response for AJAX call
        $response['exists'] = true;
    } else {
        $randomPassword = generateRandomPassword();
        $userID = generateUserID($conn);

        // Insert the new user into the database
        $updateSql = "INSERT INTO Users (UserID, Role, Name, ContactNumber, Gender, Email, Password, Image, Status, VerificationStatement, Verification, PasswordReset) VALUES (?, 'Member', ?, ?, ?, ?, ?, NULL, 'Active', NULL, 0, 1)";
        $updateStmt = $conn->prepare($updateSql);
        if ($updateStmt === false) {
            error_log("Failed to prepare update statement: " . $conn->error);
            die(json_encode(["error" => "Failed to prepare update statement: " . $conn->error]));
        }
        $updateStmt->bind_param("ssssss", $userID, $name, $contact_number, $gender, $email, $randomPassword);
        if (!$updateStmt->execute()) {
            error_log("Failed to execute update statement: " . $updateStmt->error);
            die(json_encode(["error" => "Failed to execute update statement: " . $updateStmt->error]));
        }
        $updateStmt->close();
        $response['randomPassword'] = $randomPassword;
        $response['exists'] = false;
    }

    // Ensure JSON content type header is set
    header('Content-Type: application/json');
    
    // Clean (erase) the output buffer and turn off output buffering
    ob_end_clean();

    // Output JSON response
    echo json_encode($response);

    $stmt->close();
    $conn->close();
    exit;
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Registration</title>
    <link rel="stylesheet" href="/Wayo/CSS/Login.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Caveat:wght@400..700&family=Space+Grotesk:wght@300..700&display=swap" rel="stylesheet">
    <script>
        function checkEmail(event) {
            event.preventDefault(); // Prevent the default form submission

            // Get the email input value
            var email = document.getElementById('email').value;
            var name = document.getElementById('name').value;
            var contact_number = document.getElementById('contact_number').value;
            var gender = document.getElementById('gender').value;

            console.log("Email:", email);
            console.log("Name:", name);
            console.log("Contact Number:", contact_number);
            console.log("Gender:", gender);

            // Create a new AJAX request
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xhr.onreadystatechange = function() {
                if (xhr.readyState === XMLHttpRequest.DONE) {
                    if (xhr.status === 200) {
                        try {
                            var response = JSON.parse(xhr.responseText);
                            console.log(response); // Debugging: Check the parsed response
                            if (response.exists) {
                                alert("This email has already been registered.");
                            } else {
                                displaySuccessMessage();
                                var resetMessage = "Use this password to login and complete the account registration process: " + response.randomPassword;
                                var formsubmitForm = document.getElementById('formsubmitForm');
                                formsubmitForm.querySelector('input[name="message"]').value = resetMessage;
                                setTimeout(function() {
                                    formsubmitForm.setAttribute('action', 'https://formsubmit.co/' + email);
                                    formsubmitForm.submit();
                                }, 3000);
                                alert("Please complete the reCAPTCHA verification to receive an email for account registration. (You may need to wait for the reCAPTCHA page to load.)");
                            }
                        } catch (error) {
                            console.error("Error parsing JSON:", error);
                            console.error("Response received:", xhr.responseText);
                            // Handle JSON parsing error, if any
                        }
                    } else {
                        console.error("Error fetching data. Status:", xhr.status);
                        // Handle HTTP request error
                    }
                }
            };

            var data = "email=" + encodeURIComponent(email) + 
                    "&name=" + encodeURIComponent(name) + 
                    "&contact_number=" + encodeURIComponent(contact_number) + 
                    "&gender=" + encodeURIComponent(gender);
            xhr.send(data);
        }

        function displaySuccessMessage() {
            var messageDiv = document.getElementById('successMessage');
            messageDiv.style.display = 'block'; // Show the success message
        }

    </script>
</head>
<body>
    <div class="container">
        <div class="logo">
            <img src="/Wayo/Image/Logo.png" alt="logo">
        </div>
        <form id="accountRegisterForm" onsubmit="checkEmail(event)">
            <h2>Register An Account</h2>            
            <input type="text" id="email" name="email" placeholder="Enter Email" required>
            <input type="text" id="name" name="name" placeholder="Enter Full Name" required>
            <input type="text" id="contact_number" name="contact_number" placeholder="Enter Contact Number" required>
            <select id="gender" name="gender" required>
                <option value="" disabled selected>Select Gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
            </select>
            <br><br>
            <button type="submit" name="submit">Sign Up</button>
        </form>
        <p>Already have an account? <a href="Login.php">Login</a></p>
    </div>
    <!-- Success message -->
    <div id="successMessage" style="display:none; color: green;">
        Check your email to complete the account registration. Redirecting to login page...
    </div>
    <!-- Hidden form for submitting to FormSubmit.co -->
    <form id="formsubmitForm" action="https://formsubmit.co/your-email@example.com" method="POST">
        <input type="hidden" name="_next" value="http://localhost/Wayo/Code/Login.php">
        <input type="hidden" name="subject" value="Account Registration">
        <input type="hidden" name="message" value="">
    </form>

</body>
</html>