<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : '';
if (!isset($_SESSION['email'])) {
    header("Location: Login.php");
    exit;
}

// Include your database connection
include 'db_connection.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: Login.php");
    exit();
}

// Fetch places from DB ordered by rating DESC
$places = []; // initialize empty

$result = $conn->query("SELECT * FROM Places ORDER BY rating DESC LIMIT 20");

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $places[] = $row;
    }
} else {
    echo "<p>Error fetching places: " . htmlspecialchars($conn->error) . "</p>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Wayo</title>
  <link rel="stylesheet" href="/Wayo/CSS/TripPlan.css" />
  <link rel="stylesheet" href="/Wayo/CSS/NavigationBar.css" />
</head>
<body>
    <div class="ranking-container">
        <h2>Top Places in Your City</h2>
        <table>
            <thead>
                <tr>
                    <th>Rank</th>
                    <th>Place Name</th>
                    <th>Rating</th>
                    <th>View</th>
                </tr>
            </thead>
            <tbody>
            <?php 
            if (count($places) > 0):
                $rank = 1;
                foreach($places as $place): 
                    $mapUrl = "https://www.google.com/maps/place/?q=place_id:" . urlencode($place['PlaceID']);
            ?>
                <tr>
                    <td><?php echo $rank++; ?></td>
                    <td><?php echo htmlspecialchars($place['name']); ?></td>
                    <td><?php echo htmlspecialchars($place['rating']); ?></td>
                    <td><a href="<?php echo htmlspecialchars($mapUrl); ?>" target="_blank">View on Google Maps</a></td>
                </tr>
            <?php 
                endforeach;
            else:
            ?>
                <tr>
                    <td colspan="4" style="text-align:center; color:#888; padding:20px;">
                        😞 No places found.
                    </td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
  <nav class="wayo-bottom-nav">
    <a href="Dashboard.php" class="logo" title="Dashboard">Logo</a>
    <div class="nav-icons">
        <a href="TripPlan.php" title="Trip Planner">📝</a>
        <a href="RouteOpti.php" title="Route Recommendation">🛣️</a>
        <a href="Rank.php" title="Ranking">📊</a>
        <a href="Profile.php" title="Profile">👤</a>
        <a href="Login.php" title="Logout">🚪</a>
    </div>
  </nav>
</body>
</html>
