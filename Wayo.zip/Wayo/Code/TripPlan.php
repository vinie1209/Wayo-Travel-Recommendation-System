<?php
session_start();
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : '';
if (!isset($_SESSION['email'])) {
    // Redirect to the login page if the user is not logged in
    header("Location: Login.php");
    exit;
}

// Include your database connection
include 'db_connection.php'; // Adjust this based on your actual connection script

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // User is not logged in, redirect to login page
    header("Location: Login.php");
    exit();
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Wayo</title>
  <link rel="stylesheet" href="/Wayo/CSS/TripPlan.css" />
  <link rel="stylesheet" href="/Wayo/CSS/NavigationBar.css" />
</head>
<body>
  <nav class="wayo-bottom-nav">
    <a href="Dashboard.php" class="logo" title="Dashboard">Logo</a>
    <div class="nav-icons">
        <a href="TripPlan.php" title="Trip Planner">📝</a>
        <a href="RouteOpti.php" title="Route Recommendation">🛣️</a>
        <a href="Rank.php" title="Ranking">📊</a>
        <a href="Profile.php" title="Profile">👤</a>
        <a href="Login.php" title="Logout">🚪</a>
    </div>
    </nav>
</body>
</html>