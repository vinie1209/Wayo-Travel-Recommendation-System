<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);
require __DIR__ . '/../vendor/autoload.php'; // 注意是 vendor/autoload.php

use OpenAI\Factory;

// ⚠️ 把这里替换成你自己的真实 key
$client = (new Factory())
    ->withApiKey('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')
    ->make();

$response = $client->chat()->create([
    'model' => 'gpt-4o',
    'messages' => [
        ['role' => 'user', 'content' => 'Say hello from PHP!'],
    ],
]);

echo "<pre>";
print_r($response->toArray());
echo "</pre>";
