<?php
include 'db_connection.php';
$q = isset($_GET['q']) ? $_GET['q'] : '';

$sql = "SELECT DISTINCT City FROM Popular_Destination 
        WHERE City LIKE ? LIMIT 10";
$stmt = $conn->prepare($sql);
$like = "%$q%";
$stmt->bind_param("s", $like);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    echo "<div>" . htmlspecialchars($row['City']) . "</div>";
}
?>
