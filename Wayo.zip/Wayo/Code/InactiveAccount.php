<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Account Banned</title>
    <link rel="stylesheet" href="/path/to/your/css/styles.css">
    <!-- Add any necessary styles or meta tags -->
</head>
<body>
    <div class="container">
        <h1>Account Banned</h1>
        <p>Your account has been banned due to violation of terms.</p>
        <p>Please register a new account if you wish to continue using our services.</p>
        <a href="RegisterAccount.php" class="btn btn-primary">Register New Account</a>
        <p>Please contact our administrator if you wish to request unbanning your account.</p>
        <a href="https://api.whatsapp.com/send?phone=60126316655">Whatsapp</a>
        <p>OR Email pawconnectadmin@example.com</p>
    </div>
</body>
</html>
