<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // User is not logged in, redirect to login page
    header("Location: Login.php");
    exit();
}

// User is logged in, you can use $_SESSION['user_id']
$user_id = $_SESSION['user_id'];

// Include database connection
include 'db_connection.php';

// Process form data
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $contact_number = $_POST['contact_number'];
    $gender = $_POST['gender'];
    
    // Prepare SQL update statement
    $sql = "UPDATE Users SET Name = ?, ContactNumber = ?, Gender = ? WHERE UserID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $name, $contact_number, $gender, $user_id);

    // Execute the update
    if ($stmt->execute()) {
        // Check if an image was uploaded
        if (!empty($_FILES['profile_image']['tmp_name'])) {
            $image = file_get_contents($_FILES['profile_image']['tmp_name']);
            $sql = "UPDATE Users SET Image = ? WHERE UserID = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("bs", $image, $user_id);
            $stmt->send_long_data(0, $image);
            $stmt->execute();
        }

        // Update successful, redirect to profile page
        header("Location: Profile.php");
        exit();
    } else {
        echo "Error updating profile: " . $conn->error;
    }

    $stmt->close();
}

$conn->close();
?>
