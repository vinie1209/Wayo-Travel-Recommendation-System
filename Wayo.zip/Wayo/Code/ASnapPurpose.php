args = commandArgs(trailingOnly=TRUE)
datafile = args[1]
k = as.numeric(args[2])

data = read.csv(datafile)

# --------------------
# 🧹 Data cleaning & preprocessing
# --------------------
# Time series analysis (analyzing each time slot to compare places planned by many users)
# Bar chart for ranking (commented hint)

# Remove missing values
data = na.omit(data)

# Print raw data
cat("=== Raw Data ===\n")
print(data)

# Convert to numeric (except the first column UserID)
data[ , 2:ncol(data)] = lapply(data[ , 2:ncol(data)], as.numeric)

# Standardization (mean 0, variance 1)
cluster_data = scale(data[ , -1])  # Exclude UserID

# Print standardized data
cat("=== Standardized Data ===\n")
print(cluster_data)

# Remove columns with zero variance (i.e., all values the same → no info → NaN after scaling)
keep_cols = apply(cluster_data, 2, function(col) !any(is.nan(col)) && var(col, na.rm=TRUE) > 0)
cluster_data = cluster_data[ , keep_cols]

# Check for any NaN / NA / Inf values
if (any(is.nan(cluster_data)) || any(is.na(cluster_data)) || any(is.infinite(cluster_data))) {
  stop("❗ Data contains NaN / NA / Inf, cannot proceed with clustering")
}

# --------------------
# 🤖 K-means Clustering
# --------------------
set.seed(123)  # For reproducibility
result = kmeans(cluster_data, centers=k)

# Print cluster centers
cat("=== Cluster Centers ===\n")
print(result$centers)

# Save user cluster info
output = data.frame(UserID = data$UserID, Cluster = result$cluster)
write.csv(output, "user_clusters.csv", row.names=FALSE)

cat("=== Clustering completed! Results saved to user_clusters.csv ===\n")
