#!/usr/bin/env Rscript
library(ggplot2)
df <- read.csv("high_comment.csv", stringsAsFactors=FALSE)

# Create a rating group for color
df$rating_group <- cut(
  df$rating,
  breaks=c(1,2,3,4,5),
  labels=c("1-2","2-3","3-4","4-5"),
  include.lowest=TRUE,
  right=TRUE
)

p <- ggplot(df, aes(x=reorder(name, comments), y=comments, fill=rating_group)) +
     geom_col() +
     coord_flip() +
     labs(
         title="Top Popular Places",
         x=NULL,
         y="Mentions Count",
         fill="Rating"    # legend title
     ) +
     scale_fill_manual(values=c("1-2"="#FF9999", "2-3"="#FFCC66", "3-4"="#66CC99", "4-5"="#3399FF")) +
     theme_minimal() +
     theme(
         legend.position="right",
         axis.title.x=element_text(size=12, face="bold"),
         plot.title=element_text(size=14, face="bold")
     )

# Smaller chart
ggsave("high_comment_plot.png", plot = p, width=12, height=8)
