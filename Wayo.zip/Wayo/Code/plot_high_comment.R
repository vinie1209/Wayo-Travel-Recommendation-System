#!/usr/bin/env Rscript
library(ggplot2)
library(DBI)
library(RMySQL)

# Step 1: Read data (including place_id column)
df <- read.csv("high_comment.csv", stringsAsFactors=FALSE)

# Step 2: Create a rating group for color
df$rating_group <- cut(
  df$rating,
  breaks=c(1,2,3,4,5),
  labels=c("1-2","2-3","3-4","4-5"),
  include.lowest=TRUE,
  right=TRUE
)

# Step 3: Generate plot (do NOT use place_id here)
p <- ggplot(df, aes(x=reorder(name, comments), y=comments, fill=rating_group)) +
     geom_col() +
     coord_flip() +
     labs(
         title="Top Popular Places",
         x=NULL,
         y="Mentions Count",
         fill="Rating"    # legend title
     ) +
     scale_fill_manual(values=c("1-2"="#FF9999", "2-3"="#FFCC66", "3-4"="#66CC99", "4-5"="#3399FF")) +
     theme_minimal() +
     theme(
         legend.position="right",
         axis.title.x=element_text(size=12, face="bold"),
         plot.title=element_text(size=14, face="bold")
     )

# Step 4: Save chart as PNG
ggsave("high_comment_plot.png", plot = p, width=12, height=8)

# Step 5: Define DB connection function
connect_to_db <- function() {
  cat("Connecting to database...\n")
  tryCatch({
    con <- dbConnect(
        RMySQL::MySQL(),
        dbname = "Wayo",
        host = "localhost",
        user = "root",
        password = "",
        unix.sock = "/Applications/XAMPP/xamppfiles/var/mysql/mysql.sock"
    )
    cat("Successfully connected to MySQL database\n")
    return(con)
  }, error = function(e) {
    cat("Database connection failed:\n")
    cat("Error:", e$message, "\n")
    cat("Please verify:\n")
    cat("1. MySQL server is running\n")
    cat("2. Database 'Wayo' exists\n")
    cat("3. User 'root' has correct permissions\n")
    quit(status = 1)
  })
}

# Step 6: Insert data into database
con <- connect_to_db()

# Make sure 'place_id' column exists in the CSV and database
if (!"place_id" %in% colnames(df)) {
  df$place_id <- NA  # fallback if not present
}

# Optional: delete old entries if refreshing
# dbExecute(con, "DELETE FROM PopularPlaces")

# Only for DB: include place_id, not in the plot
insert_data <- df[, c("name", "comments", "rating", "rating_group", "place_id")]
dbWriteTable(con, name = "PopularPlaces", value = insert_data, append = TRUE, row.names = FALSE)

# Step 7: Disconnect
dbDisconnect(con)
