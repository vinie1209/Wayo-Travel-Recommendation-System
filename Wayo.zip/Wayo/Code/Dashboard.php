<?php
session_start();
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : '';
if (!isset($_SESSION['email'])) {
    // Redirect to the login page if the user is not logged in
    header("Location: Login.php");
    exit;
}

// Include your database connection
include 'db_connection.php'; // Adjust this based on your actual connection script

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // User is not logged in, redirect to login page
    header("Location: Login.php");
    exit();
}

// Popular Destination
$popular_query = "SELECT Name, Image FROM Popular_Destination";
$popular_result = mysqli_query($conn, $popular_query);

// Recommendation by current user
$recommend_query = "SELECT Name, Image FROM Recommendation WHERE UserID='$user_id'";
$recommend_result = mysqli_query($conn, $recommend_query);

// 默认图片路径
$default_img = '/Wayo/Assets/default.jpg';

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Wayo</title>
  <link rel="stylesheet" href="/Wayo/CSS/Dashboard.css" />
  <link rel="stylesheet" href="/Wayo/CSS/NavigationBar.css" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
</head>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA45pztm_eOgf1xJpaucfN_9uIpV6FM2GA&libraries=places"></script>
<body>
  <div class="content">
    <div class="trip-plan">
        <img src="/Wayo/Image/DashboardBackground.png" alt="Trip Banner" class="trip-banner">
        <div class="search-bar-date">
            <div class="trip-info">
                <span class="trip-title">Destination:</span>
                <input type="text" id="cityInput" placeholder="City, Region, Lanmark" onkeyup="searchCity()">
            </div>
            <div class="trip-info">
                <span class="trip-title">Departure Time</span>
                <input type="date" id="startDate" />
                <span class="start-end">----</span>
                <span class="trip-title">Return Time</span>
                <input type="date" id="endDate" />
                
            </div>
            <div class="trip-info">
                <span class="trip-title">Pax</span>
                <span class="trip-title">Adult</span>
                <input type="number" id="adult" min="1" value="1" />
                <span class="trip-title">Children</span>
                <input type="number" id="children" min="0" value="0" />
                <button onclick="submitPlanRequest()">✨ Generate Trip Plan</button>
            </div>
            <p id="durationInfo">Duration: 1 day, 0 nights</p>

        </div>
    </div>
    <script>
      function initAutocomplete() {
          const cityInput = document.getElementById('cityInput');
          new google.maps.places.Autocomplete(cityInput, {
              types: ['(cities)']
          });
      }

      document.addEventListener('DOMContentLoaded', () => {
          initAutocomplete();
          // Default date logic
          const startInput = document.getElementById('startDate');
          const endInput = document.getElementById('endDate');
          const today = new Date();
          const tomorrow = new Date(today);
          tomorrow.setDate(today.getDate() + 1);

          startInput.valueAsDate = today;
          endInput.valueAsDate = tomorrow;

          calculateDuration();

          startInput.addEventListener('change', calculateDuration);
          endInput.addEventListener('change', calculateDuration);
      });

      function generatePlan() {
          const city = document.getElementById('cityInput').value;
          const start = document.getElementById('startDate').value;
          const end = document.getElementById('endDate').value;
          const pax = document.getElementById('pax').value;

          if (city && start && end && pax) {
              // Redirect and pass data to PHP
              window.location.href = `GeneratePlan.php?city=${encodeURIComponent(city)}&start=${start}&end=${end}&pax=${pax}`;
          } else {
              alert("Please fill in all fields!");
          }
      }

      function calculateDuration() {
          const start = new Date(document.getElementById('startDate').value);
          const end = new Date(document.getElementById('endDate').value);

          if (!isNaN(start) && !isNaN(end) && end >= start) {
              const diffTime = end - start;
              const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24)) + 1; // inclusive
              const nights = diffDays - 1;

              document.getElementById('durationInfo').textContent = `Duration: ${diffDays} day(s), ${nights} night(s)`;

              if (diffDays > 5) {
                  alert("Trip duration cannot exceed 5 days.");
                  // 自动调整 endDate，让总天数不超过 5 天
                  const maxEndDate = new Date(start);
                  maxEndDate.setDate(start.getDate() + 4); // 5天总长
                  document.getElementById('endDate').valueAsDate = maxEndDate;
                  calculateDuration(); // 再次更新显示
              }
          } else {
              document.getElementById('durationInfo').textContent = "Invalid dates selected.";
          }
      }
      function submitPlanRequest() {
          const city = document.getElementById('cityInput').value.trim();
          const startDate = document.getElementById('startDate').value;
          const endDate = document.getElementById('endDate').value;
          const adults = parseInt(document.getElementById('adult').value, 10) || 0;
          const children = parseInt(document.getElementById('children').value, 10) || 0;
          const totalPax = adults + children;

          if (!city) {
              alert('Please enter a destination.');
              return;
          }

          if (!startDate || !endDate) {
              alert('Please select start and end dates.');
              return;
          }

          const start = new Date(startDate);
          const end = new Date(endDate);
          const diffDays = Math.round((end - start) / (1000 * 60 * 60 * 24)) + 1;

          if (diffDays > 5) {
              alert('Trip duration cannot exceed 5 days.');
              return;
          }

          if (totalPax <= 0) {
              alert('Please enter at least 1 adult or child.');
              return;
          }

          // Redirect to GeneratePlan.php with parameters
          const url = `GeneratePlan.php?city=${encodeURIComponent(city)}&start=${encodeURIComponent(startDate)}&end=${encodeURIComponent(endDate)}&adults=${adults}&children=${children}`;
          window.location.href = url;
      }
    </script>



    <div class="section">
      <h2>Popular Destinations</h2>
      <div class="slider">
        <button class="scroll-btn left" onclick="scrollLeft('popular')">‹</button>
        <div class="scroll-container" id="popular">
          <?php
          while($row = mysqli_fetch_assoc($popular_result)) {
              $img = $default_img;
              if (!is_null($row['Image'])) {
                  // 显示 blob 图片
                  $base64 = base64_encode($row['Image']);
                  $img = 'data:image/jpeg;base64,'.$base64;
              }
              echo '<div class="card">
                      <img src="'.$img.'" alt="'.htmlspecialchars($row['Name']).'" />
                    </div>';
          }
          ?>
        </div>
        <button class="scroll-btn right" onclick="scrollRight('popular')">›</button>
      </div>
    </div>

    <div class="section">
      <h2>Recommended for You</h2>
      <div class="slider">
        <button class="scroll-btn left" onclick="scrollLeft('recommended')">‹</button>
        <div class="scroll-container" id="recommended">
          <!-- <?php
          while($row = mysqli_fetch_assoc($recommend_result)) {
              $img = $default_img;
              if (!is_null($row['Image'])) {
                  $base64 = base64_encode($row['Image']);
                  $img = 'data:image/jpeg;base64,'.$base64;
              }
              echo '<div class="card">
                      <img src="'.$img.'" alt="'.htmlspecialchars($row['Name']).'" />
                    </div>';
          }
          ?> -->
        <div class="scroll-container" id="recommended"></div>
        <script>
        document.addEventListener('DOMContentLoaded', function () {
            fetch('GetRecommendations.php')
                .then(response => response.json())
                .then(data => {
                    const container = document.getElementById('recommended');
                    const defaultImg = '/Wayo/Assets/default.jpg';

                    if (data.length === 0 || data.error) {
                        container.innerHTML = "<p>No recommendations available.</p>";
                        return;
                    }

                    data.forEach(place => {
                        let imageURL = defaultImg;
                        if (place.photo_reference) {
                            imageURL = `https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photoreference=${place.photo_reference}&key=AIzaSyA45pztm_eOgf1xJpaucfN_9uIpV6FM2GA`;
                        }

                        const card = document.createElement('div');
                        card.className = 'card';
                        card.innerHTML = `<img src="${imageURL}" alt="${place.name}" title="${place.name}" />`;
                        container.appendChild(card);
                    });
                })
                .catch(err => {
                    console.error('Recommendation fetch error:', err);
                    document.getElementById('recommended').innerHTML = "<p>Unable to load recommendations.</p>";
                });
        });
        </script>
        </div>
        <button class="scroll-btn right" onclick="scrollRight('recommended')">›</button>
      </div>
    </div>
  </div>

  <nav class="wayo-bottom-nav">
        <a href="Dashboard.php" class="logo" title="Dashboard">
            <img src="/Wayo/Image/Logo.png" alt="Logo" class="logo-img">
        </a>
        <div class="nav-icons">
            <a href="Dashboard.php" title="Trip Planner">📝</a>
            <a href="RouteOpti.php" title="Route Recommendation">🛣️</a>
            <a href="Rank.php" title="Ranking">📊</a>
            <a href="Profile.php" title="Profile">👤</a>
            <a href="Login.php" title="Logout">🚪</a>
        </div>
  </nav>

  <script>
    function scrollLeft(id) {
        const container = document.getElementById(id);
        console.log('Before scrollLeft:', container.scrollLeft);
        container.scrollLeft -= 300;
        console.log('After scrollLeft:', container.scrollLeft);
    }

    function scrollRight(id) {
        const container = document.getElementById(id);
        console.log('Before scrollLeft:', container.scrollLeft);
        container.scrollLeft += 300;
        console.log('After scrollLeft:', container.scrollLeft);
    }

    function scrollLeft(id) {
        const container = document.getElementById(id);
        container.scrollLeft -= container.offsetWidth * 0.8;
    }

    function scrollRight(id) {
        const container = document.getElementById(id);
        container.scrollLeft += container.offsetWidth * 0.8;
    }

    </script>

</body>
</html>
