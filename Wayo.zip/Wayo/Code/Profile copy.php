<?php
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // User is not logged in, redirect to login page
    header("Location: Login.php");
    exit();
}

// User is logged in, you can use $_SESSION['user_id']
$user_id = $_SESSION['user_id'];

// Include database connection
include 'db_connection.php';

// Initialize variables
$name = $contact_number = $gender = $email = "";

// Query to get user's current information
$sql = "SELECT * FROM Users WHERE UserID = '$user_id'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $name = $row['Name'];
    $contact_number = $row['ContactNumber'];
    $gender = $row['Gender'];
    $email = $row['Email'];
    $verification = $row['Verification'];
} else {
    echo "No user found.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Profile - <?php echo $row['Name']; ?></title>
    <link rel="stylesheet" href="/Wayo/CSS/Profile.css">
    <link rel="stylesheet" href="/Wayo/CSS/NavigationBar.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Caveat:wght@400..700&family=Space+Grotesk:wght@300..700&display=swap" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <style>
        .application-info p {
            text-align: right;
            color: rgba(128, 128, 128, 0.775);
            font-size: 15px;
        }

        .application-card h3 {
            margin: 0;
            font-size: 16px;
        }
    </style>
</head>
<body>
    <div class="main-container">
        <div class="content">
            <div class="profile-container">
                <form method="POST" action="UpdateProfile.php" id="profileForm" enctype="multipart/form-data">
                    <div class="profile-image">
                        <img id="profileImage" src="<?php echo isset($row['Image']) ? 'data:image/jpeg;base64,'.base64_encode($row['Image']) : '/PawConnect/Image/BlankProfile.png'; ?>" alt="Profile Image">
                        <div class="button-container">
                            <button type="button" id="editProfileBtn" onclick="toggleEditSave()">Edit Profile</button>
                            <button type="button" id="changeProfileImageBtn" style="display: none;" onclick="document.getElementById('profileImageInput').click()">Change Profile Image</button>
                            <input type="file" id="profileImageInput" name="profile_image" accept="image/*" style="display: none;" onchange="previewImage(event)">
                        </div>
                    </div>
                    <div class="profile-details">
                        <div class="profile-left">
                            <!-- <div>
                                <label>User ID:</label>
                                <span id="userId"><?php echo $user_id; ?></span>
                            </div> -->
                            <div>
                                <label>Email:</label>
                                <span id="email"><?php echo $email; ?></span>
                            </div>
                            <div>
                                <label>Name:</label>
                                <input type="text" id="nameInput" name="name" value="<?php echo $name; ?>" readonly>
                            </div>
                            
                        </div>
                        <div class="profile-right">
                            <!-- <div>
                                <label>Contact Number:</label>
                                <input type="text" id="contactInput" name="contact_number" value="<?php echo $row['ContactNumber']; ?>" readonly>
                            </div> -->
                            <!-- <div>
                                <label>Gender:</label>
                                <input type="text" id="gender" name="gender" value="<?php echo $row['Gender']; ?>" readonly>
                                <select id="genderInput" name="gender" readonly>
                                    <option value="Male" <?php echo ($gender == 'Male') ? 'selected' : ''; ?>>Male</option>
                                    <option value="Female" <?php echo ($gender == 'Female') ? 'selected' : ''; ?>>Female</option>
                                    <option value="Other" <?php echo ($gender == 'Other') ? 'selected' : ''; ?>>Other</option>
                                </select>
                            </div> -->
                            <!-- <div>
                                <label>Password:</label>
                                <input type="password" value="********" readonly class="password-input">
                                <a href="ChangePassword.php" id="changePasswordLink" style="display: none;">Change Password</a>
                            </div> -->
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <aside class="sidebar">
        <button onclick="window.location.href='UserHistory.php'">History</button>
        <button onclick="window.location.href='UserPreferences.php'">Preferences</button>
        <!-- <button onclick="window.location.href='UserSave.php'">Saved Place</button> -->
        </aside>
    </div>

    <script>
        function toggleEditSave() {
            var inputs = document.querySelectorAll('.profile-details input:not([type="password"]), .profile-details select');
            var editProfileBtn = document.getElementById('editProfileBtn');
            var changeProfileImageBtn = document.getElementById('changeProfileImageBtn');
            var changePasswordLink = document.getElementById('changePasswordLink');
            var form = document.getElementById('profileForm');

            if (editProfileBtn.textContent === 'Edit Profile') {
                // Enable editing
                inputs.forEach(input => {
                    input.readOnly = false;
                    // input.disabled = false;
                });
                editProfileBtn.textContent = 'Save Profile';
                changeProfileImageBtn.style.display = 'inline-block';
                changePasswordLink.style.display = 'inline-block'; // Show change password link
                window.onbeforeunload = function(event) {
                    return "Are you sure you want to leave? Any unsaved changes will be lost.";
                };
            } else {
                // Disable editing and submit the form
                inputs.forEach(input => {
                    input.readOnly = true;
                    // input.disabled = true;
                });
                form.submit();
                editProfileBtn.textContent = 'Edit Profile';
                changeProfileImageBtn.style.display = 'none';
                changePasswordLink.style.display = 'none'; // Hide change password link
                window.onbeforeunload = null; // Disable confirmation when saving
            }
        }

        function previewImage(event) {
            var reader = new FileReader();
            reader.onload = function(){
                var output = document.getElementById('profileImage');
                output.src = reader.result;
            };
            reader.readAsDataURL(event.target.files[0]);
        }
    </script>

    <script>
        // Function to show confirmation dialog when leaving the page
        window.onbeforeunload = function(event) {
            if (document.getElementById('editProfileBtn').textContent === 'Save Profile') {
                return "Are you sure you want to leave? Any unsaved changes will be lost.";
            }
        };

        // Function to disable the confirmation when the form is submitted
        function disableConfirmation() {
            window.onbeforeunload = null;
        }

        // Event listener for form submission
        document.getElementById('profileForm').addEventListener('submit', disableConfirmation);
    </script>

    <script>
        function loadContent(sectionId) {
            const xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function() {
                if (xhr.readyState === XMLHttpRequest.DONE) {
                    if (xhr.status === 200) {
                        document.getElementById('contentContainer').innerHTML = xhr.responseText;
                    } else {
                        console.error('Failed to load content');
                    }
                }
            };
            xhr.open('GET', sectionId + '.php', true);
            xhr.send();
        }

        document.querySelectorAll('.sidebar1 a').forEach(item => {
            item.addEventListener('click', event => {
                event.preventDefault(); // Prevent the default action of the link
                const sectionId = event.target.getAttribute('href').substring(1); // Get the section ID
                loadContent(sectionId); // Load the content
            });
        });
    </script>
    
    <nav class="wayo-bottom-nav">
        <a href="Dashboard.php" class="logo" title="Dashboard">
            <img src="/Wayo/Image/Logo.png" alt="Logo" class="logo-img">
        </a>
        <div class="nav-icons">
            <a href="Dashboard.php" title="Trip Planner">📝</a>
            <a href="RouteOpti.php" title="Route Recommendation">🛣️</a>
            <a href="Rank.php" title="Ranking">📊</a>
            <a href="Profile.php" title="Profile">👤</a>
            <a href="Login.php" title="Logout">🚪</a>
        </div>
    </nav>
</body>
</html>
