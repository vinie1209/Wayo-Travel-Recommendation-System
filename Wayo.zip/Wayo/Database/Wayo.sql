-- Create database
CREATE DATABASE Wayo;
GO

-- Use database
USE Wayo;
GO

CREATE TABLE Users (
    UserID varchar(8) PRIMARY KEY NOT NULL,
    Role varchar(20) NOT NULL,
    Name varchar(50) NOT NULL,
    ContactNumber varchar(15) NOT NULL,
    Gender varchar(10) NOT NULL,
    Email varchar(50) NOT NULL,
    Password varchar(50) NOT NULL,
    Image longblob DEFAULT NULL,
    Status varchar(20) NOT NULL,
    VerificationStatement longblob DEFAULT NULL,
    Verification boolean DEFAULT 0,
    PasswordReset boolean NOT NULL DEFAULT 0
);

CREATE TABLE Popular_Destination (
    DesID varchar(8) PRIMARY KEY NOT NULL,
    Name VARCHAR(50) NOT NULL,
    Type varchar(255) NOT NULL,
    Image longblob DEFAULT NULL,
    Description varchar(255) NOT NULL,
    City varchar(50) NOT NULL,
    Country varchar(50) NOT NULL
);

CREATE TABLE Recommendation (
    RecommendationID varchar(8) PRIMARY KEY NOT NULL,
    Name VARCHAR(50) NOT NULL,
    Type varchar(255) NOT NULL,
    Image longblob DEFAULT NULL,
    Description varchar(255) NOT NULL,
    City varchar(50) NOT NULL,
    Country varchar(50) NOT NULL,
    UserID varchar(8) NOT NULL,
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

CREATE TABLE UserPreferences (
    PreferenceID VARCHAR(8) PRIMARY KEY NOT NULL,
    PreferredBudgetRange VARCHAR(50),    -- e.g., 'Low', 'Medium', 'High'
    PreferredTravelSeason VARCHAR(50),   -- e.g., 'Summer', 'Winter'
    LikeCulturalExperiences BOOLEAN DEFAULT FALSE,
    LikeOutdoorAdventures BOOLEAN DEFAULT FALSE,
    LikeRelaxingPlaces BOOLEAN DEFAULT FALSE,
    UserID VARCHAR(8) NOT NULL,
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

CREATE TABLE UserPreferredTravelTypes (
    PreferredTravelTypesID VARCHAR(8) PRIMARY KEY NOT NULL,
    TravelType VARCHAR(50),  -- e.g., 'Beach', 'Nature'
    UserID VARCHAR(8) NOT NULL,
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

CREATE TABLE UserFavoriteActivities (
    UserFavoriteActivitiesID VARCHAR(8) PRIMARY KEY NOT NULL,
    Activity VARCHAR(50),  -- e.g., 'Hiking', 'Food'
    UserID VARCHAR(8) NOT NULL,
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

CREATE TABLE UserFavoriteCities (
    UserFavoriteCitiesID VARCHAR(8) PRIMARY KEY NOT NULL,
    City VARCHAR(100),  -- e.g., 'Penang', 'Langkawi'
    UserID VARCHAR(8) NOT NULL,
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

CREATE TABLE TripPlan (
    TPID VARCHAR(8) PRIMARY KEY NOT NULL,
    City VARCHAR(100) NOT NULL,
    StartDate DATE NOT NULL,
    EndDate DATE NOT NULL,
    Adult INT DEFAULT 0,
    Children INT DEFAULT 0,
    UserID VARCHAR(8) NOT NULL,
    CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

CREATE TABLE TripPlanDetails (
    PDID VARCHAR(8) PRIMARY KEY NOT NULL,
    PlaceID VARCHAR(255) NOT NULL,
    Date date NOT NULL,
    Time time NOT NULL,
    RecommendMeals VARCHAR(255),
    TPID VARCHAR(10) NOT NULL,
    FOREIGN KEY (TPID) REFERENCES TripPlan(TPID)
);

CREATE TABLE Places (
    PlaceID VARCHAR(255) PRIMARY KEY,
    name VARCHAR(255),
    lat DOUBLE,
    lng DOUBLE,
    rating FLOAT
);

-- Routes 表：存储路线信息
CREATE TABLE Routes (
    RouteID VARCHAR(8) PRIMARY KEY NOT NULL,       -- eg: RTE00001
    TotalDistance VARCHAR(50),
    TotalDuration VARCHAR(50),
    Save Boolean,
    UserID VARCHAR(8) NOT NULL,
    CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

-- Locations 表：存储路线中的地点（来自 Google Maps 的 place_id）
CREATE TABLE Locations (
    LocationID VARCHAR(8) PRIMARY KEY NOT NULL,    
    PlaceID VARCHAR(255) NOT NULL,                 
    Sequence INT NOT NULL,                          
    RouteID VARCHAR(8) NOT NULL,
    CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (RouteID) REFERENCES Routes(RouteID)
);

CREATE TABLE Histories (
    HistoryID VARCHAR(8) PRIMARY KEY NOT NULL,   
    Title VARCHAR(255) NOT NULL,                                         
    TopicID VARCHAR(8) NOT NULL,
    UserID VARCHAR(8) NOT NULL,
    CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

CREATE TABLE RecPlaces (
    PlaceID VARCHAR(8) PRIMARY KEY,
    Name VARCHAR(255),
    Image LONGBLOB
);

CREATE TABLE PopularPlaces (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255),
    comments INT,
    rating FLOAT,
    rating_group VARCHAR(10),
    place_id VARCHAR(100)
);

-- Step 1: Create a temporary table to hold new PlaceIDs
CREATE TEMPORARY TABLE TempPlaceIDs (
    NewPlaceID VARCHAR(255)
);

CREATE TABLE UserClicks (
    ClickID VARCHAR(8) PRIMARY KEY NOT NULL,    
    PlaceID VARCHAR(255) NOT NULL,                                   
    UserID VARCHAR(8) NOT NULL,
    CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

CREATE TABLE UserSave (
    SaveID VARCHAR(8) PRIMARY KEY NOT NULL,    
    PlaceID VARCHAR(255) NOT NULL,                                   
    UserID VARCHAR(8) NOT NULL,
    CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

-- Step 2: Insert all provided PlaceIDs
INSERT INTO TempPlaceIDs (NewPlaceID) VALUES
('ChIJo826tmxIzDERoClaspOvR94'),
('ChIJBahJiQxHzDER-Z5vs7Lrv_I'),
('ChIJM5cxndM3zDER7WuP_cN-omg'),
('ChIJEWkeL7ZJzDER38lq7GVsWyk'),
('ChIJJX8hZM9JzDER-yYg0nIT468'),
('ChIJ4R-DCrY5zDERL3vbAscAyPI'),
('ChIJu8zWwchJzDERhcsx4AhQ1oo'),
('ChIJI2g2x35SzDERQrxACfDVnNU'),
('ChIJtVRanyRIzDERy5XhmJomDtw'),
('ChIJ45QwVSY2zDERclDylVRcVsQ'),
('ChIJyfiFd7O1zTER97yuR6os4aQ'),
('ChIJ380v_Rs4zDERg-ayesQ7RaY'),
('ChIJC8XlJTdLzDER1lrOb5bezH4'),
('ChIJ_Y2Rm81JzDERKAawVfuGOd8'),
('ChIJYS9kPNNJzDERipN-3r0cjME'),
('ChIJ95t1pi1MzDERSkMoLupf4L8'),
('ChIJbYzBirRJzDER6sOW8QgA454'),
('ChIJ82c8mRlIzDERzI11F-hu-ck'),
('ChIJd3wHjQZSzDERlE6gjtEiKQU'),
('ChIJMzEi4RO2zTERndqHFncbrOI');

-- Step 3: Perform the update using a random PlaceID from the list
UPDATE Locations
JOIN (
    SELECT LocationID,
           (SELECT NewPlaceID FROM TempPlaceIDs ORDER BY RAND() LIMIT 1) AS RandomPlaceID
    FROM Locations
    WHERE PlaceID = 'ChIJn7ct6mxIzDERAfOvaaTX5DM'
) AS Randomized ON Locations.LocationID = Randomized.LocationID
SET Locations.PlaceID = Randomized.RandomPlaceID;

INSERT INTO UserClicks (ClickID, PlaceID, UserID, CreatedAt) VALUES
('CLC00001', 'ChIJo826tmxIzDERoClaspOvR94', 'MEM00012', '2024-01-12 10:32:15'),
('CLC00002', 'ChIJMzEi4RO2zTERndqHFncbrOI', 'MEM00008', '2024-02-05 14:21:45'),
('CLC00003', 'ChIJI2g2x35SzDERQrxACfDVnNU', 'MEM00016', '2024-02-27 09:12:07'),
('CLC00004', 'ChIJ95t1pi1MzDERSkMoLupf4L8', 'MEM00006', '2024-03-03 12:42:19'),
('CLC00005', 'ChIJbYzBirRJzDER6sOW8QgA454', 'MEM00002', '2024-03-11 18:31:50'),
('CLC00006', 'ChIJ82c8mRlIzDERzI11F-hu-ck', 'MEM00018', '2024-03-15 08:56:23'),
('CLC00007', 'ChIJtVRanyRIzDERy5XhmJomDtw', 'MEM00009', '2024-03-28 19:12:08'),
('CLC00008', 'ChIJ380v_Rs4zDERg-ayesQ7RaY', 'MEM00019', '2024-04-02 16:25:47'),
('CLC00009', 'ChIJC8XlJTdLzDER1lrOb5bezH4', 'MEM00014', '2024-04-07 11:54:22'),
('CLC00010', 'ChIJd3wHjQZSzDERlE6gjtEiKQU', 'MEM00001', '2024-04-19 17:48:01'),
('CLC00011', 'ChIJJX8hZM9JzDER-yYg0nIT468', 'MEM00003', '2024-04-21 08:15:39'),
('CLC00012', 'ChIJ95t1pi1MzDERSkMoLupf4L8', 'MEM00005', '2024-04-29 12:05:18'),
('CLC00013', 'ChIJ45QwVSY2zDERclDylVRcVsQ', 'MEM00020', '2024-05-04 14:42:33'),
('CLC00014', 'ChIJM5cxndM3zDER7WuP_cN-omg', 'MEM00007', '2024-05-11 09:17:04'),
('CLC00015', 'ChIJo826tmxIzDERoClaspOvR94', 'MEM00013', '2024-05-20 10:44:58'),
('CLC00016', 'ChIJ_Y2Rm81JzDERKAawVfuGOd8', 'MEM00004', '2024-05-25 16:12:39'),
('CLC00017', 'ChIJyfiFd7O1zTER97yuR6os4aQ', 'MEM00010', '2024-06-02 11:21:09'),
('CLC00018', 'ChIJ4R-DCrY5zDERL3vbAscAyPI', 'MEM00011', '2024-06-15 18:45:27'),
('CLC00019', 'ChIJu8zWwchJzDERhcsx4AhQ1oo', 'MEM00017', '2024-06-20 07:35:14'),
('CLC00020', 'ChIJMzEi4RO2zTERndqHFncbrOI', 'MEM00012', '2024-06-25 15:28:48'),
('CLC00021', 'ChIJC8XlJTdLzDER1lrOb5bezH4', 'MEM00015', '2024-07-01 09:14:20'),
('CLC00022', 'ChIJBahJiQxHzDER-Z5vs7Lrv_I', 'MEM00008', '2024-07-04 13:02:55'),
('CLC00023', 'ChIJJX8hZM9JzDER-yYg0nIT468', 'MEM00018', '2024-07-09 19:55:34'),
('CLC00024', 'ChIJYS9kPNNJzDERipN-3r0cjME', 'MEM00014', '2024-07-14 11:48:11'),
('CLC00025', 'ChIJ82c8mRlIzDERzI11F-hu-ck', 'MEM00002', '2024-07-19 14:40:22'),
('CLC00026', 'ChIJd3wHjQZSzDERlE6gjtEiKQU', 'MEM00006', '2024-07-24 17:53:59'),
('CLC00027', 'ChIJ95t1pi1MzDERSkMoLupf4L8', 'MEM00010', '2024-08-01 08:05:42'),
('CLC00028', 'ChIJo826tmxIzDERoClaspOvR94', 'MEM00004', '2024-08-05 12:48:33'),
('CLC00029', 'ChIJM5cxndM3zDER7WuP_cN-omg', 'MEM00001', '2024-08-08 16:59:01'),
('CLC00030', 'ChIJ45QwVSY2zDERclDylVRcVsQ', 'MEM00007', '2024-08-12 19:40:14'),
('CLC00031', 'ChIJtVRanyRIzDERy5XhmJomDtw', 'MEM00019', '2024-08-15 08:52:39'),
('CLC00032', 'ChIJu8zWwchJzDERhcsx4AhQ1oo', 'MEM00009', '2024-08-18 13:17:42'),
('CLC00033', 'ChIJ4R-DCrY5zDERL3vbAscAyPI', 'MEM00013', '2024-08-21 10:04:11'),
('CLC00034', 'ChIJMzEi4RO2zTERndqHFncbrOI', 'MEM00015', '2024-08-25 17:42:56'),
('CLC00035', 'ChIJd3wHjQZSzDERlE6gjtEiKQU', 'MEM00020', '2024-08-28 08:31:22'),
('CLC00036', 'ChIJC8XlJTdLzDER1lrOb5bezH4', 'MEM00016', '2024-09-02 18:59:33'),
('CLC00037', 'ChIJ_Y2Rm81JzDERKAawVfuGOd8', 'MEM00005', '2024-09-07 12:40:09'),
('CLC00038', 'ChIJbYzBirRJzDER6sOW8QgA454', 'MEM00017', '2024-09-10 09:52:55'),
('CLC00039', 'ChIJyfiFd7O1zTER97yuR6os4aQ', 'MEM00008', '2024-09-14 15:14:42'),
('CLC00040', 'ChIJ380v_Rs4zDERg-ayesQ7RaY', 'MEM00003', '2024-09-18 07:41:11'),
('CLC00041', 'ChIJJX8hZM9JzDER-yYg0nIT468', 'MEM00014', '2024-09-20 16:22:18'),
('CLC00042', 'ChIJBahJiQxHzDER-Z5vs7Lrv_I', 'MEM00011', '2024-09-24 11:53:45'),
('CLC00043', 'ChIJo826tmxIzDERoClaspOvR94', 'MEM00018', '2024-09-28 19:04:12'),
('CLC00044', 'ChIJ95t1pi1MzDERSkMoLupf4L8', 'MEM00007', '2024-10-02 08:33:21'),
('CLC00045', 'ChIJ82c8mRlIzDERzI11F-hu-ck', 'MEM00004', '2024-10-06 14:21:50'),
('CLC00046', 'ChIJ45QwVSY2zDERclDylVRcVsQ', 'MEM00006', '2024-10-11 17:55:19'),
('CLC00047', 'ChIJtVRanyRIzDERy5XhmJomDtw', 'MEM00010', '2024-10-15 09:33:44'),
('CLC00048', 'ChIJMzEi4RO2zTERndqHFncbrOI', 'MEM00002', '2024-10-18 13:28:17'),
('CLC00049', 'ChIJd3wHjQZSzDERlE6gjtEiKQU', 'MEM00019', '2024-10-22 16:15:51'),
('CLC00050', 'ChIJC8XlJTdLzDER1lrOb5bezH4', 'MEM00012', '2024-10-26 11:05:33');

INSERT INTO UserSave (SaveID, PlaceID, UserID, CreatedAt) VALUES
('SAV00001', 'ChIJo826tmxIzDERoClaspOvR94', 'MEM00005', '2024-01-03 09:12:45'),
('SAV00002', 'ChIJBahJiQxHzDER-Z5vs7Lrv_I', 'MEM00012', '2024-01-04 11:27:18'),
('SAV00003', 'ChIJM5cxndM3zDER7WuP_cN-omg', 'MEM00008', '2024-01-05 15:41:23'),
('SAV00004', 'ChIJEWkeL7ZJzDER38lq7GVsWyk', 'MEM00001', '2024-01-07 13:05:59'),
('SAV00005', 'ChIJJX8hZM9JzDER-yYg0nIT468', 'MEM00014', '2024-01-08 10:18:07'),
('SAV00006', 'ChIJ4R-DCrY5zDERL3vbAscAyPI', 'MEM00009', '2024-01-09 18:27:35'),
('SAV00007', 'ChIJu8zWwchJzDERhcsx4AhQ1oo', 'MEM00017', '2024-01-10 14:56:20'),
('SAV00008', 'ChIJI2g2x35SzDERQrxACfDVnNU', 'MEM00002', '2024-01-12 08:43:55'),
('SAV00009', 'ChIJtVRanyRIzDERy5XhmJomDtw', 'MEM00010', '2024-01-12 19:11:38'),
('SAV00010', 'ChIJ45QwVSY2zDERclDylVRcVsQ', 'MEM00004', '2024-01-13 17:23:04'),
('SAV00011', 'ChIJyfiFd7O1zTER97yuR6os4aQ', 'MEM00007', '2024-01-15 09:10:50'),
('SAV00012', 'ChIJ380v_Rs4zDERg-ayesQ7RaY', 'MEM00020', '2024-01-16 20:30:16'),
('SAV00013', 'ChIJC8XlJTdLzDER1lrOb5bezH4', 'MEM00011', '2024-01-17 11:47:25'),
('SAV00014', 'ChIJ_Y2Rm81JzDERKAawVfuGOd8', 'MEM00015', '2024-01-18 16:09:44'),
('SAV00015', 'ChIJYS9kPNNJzDERipN-3r0cjME', 'MEM00003', '2024-01-19 12:31:02'),
('SAV00016', 'ChIJ95t1pi1MzDERSkMoLupf4L8', 'MEM00006', '2024-01-20 08:55:31'),
('SAV00017', 'ChIJbYzBirRJzDER6sOW8QgA454', 'MEM00019', '2024-01-21 15:14:17'),
('SAV00018', 'ChIJ82c8mRlIzDERzI11F-hu-ck', 'MEM00008', '2024-01-22 19:20:45'),
('SAV00019', 'ChIJd3wHjQZSzDERlE6gjtEiKQU', 'MEM00013', '2024-01-23 14:42:59'),
('SAV00020', 'ChIJMzEi4RO2zTERndqHFncbrOI', 'MEM00016', '2024-01-24 10:50:37'),
('SAV00021', 'ChIJo826tmxIzDERoClaspOvR94', 'MEM00018', '2024-01-25 18:06:23'),
('SAV00022', 'ChIJBahJiQxHzDER-Z5vs7Lrv_I', 'MEM00001', '2024-01-26 09:59:51'),
('SAV00023', 'ChIJM5cxndM3zDER7WuP_cN-omg', 'MEM00004', '2024-01-27 21:17:08'),
('SAV00024', 'ChIJEWkeL7ZJzDER38lq7GVsWyk', 'MEM00010', '2024-01-28 13:40:11'),
('SAV00025', 'ChIJJX8hZM9JzDER-yYg0nIT468', 'MEM00006', '2024-01-29 08:05:43'),
('SAV00026', 'ChIJ4R-DCrY5zDERL3vbAscAyPI', 'MEM00012', '2024-01-30 16:29:28'),
('SAV00027', 'ChIJu8zWwchJzDERhcsx4AhQ1oo', 'MEM00009', '2024-01-31 11:13:07'),
('SAV00028', 'ChIJI2g2x35SzDERQrxACfDVnNU', 'MEM00015', '2024-02-01 07:22:59'),
('SAV00029', 'ChIJtVRanyRIzDERy5XhmJomDtw', 'MEM00002', '2024-02-02 12:36:45'),
('SAV00030', 'ChIJ45QwVSY2zDERclDylVRcVsQ', 'MEM00005', '2024-02-03 09:15:36'),
('SAV00031', 'ChIJyfiFd7O1zTER97yuR6os4aQ', 'MEM00014', '2024-02-04 14:51:28'),
('SAV00032', 'ChIJ380v_Rs4zDERg-ayesQ7RaY', 'MEM00019', '2024-02-05 10:19:49'),
('SAV00033', 'ChIJC8XlJTdLzDER1lrOb5bezH4', 'MEM00007', '2024-02-06 17:25:40'),
('SAV00034', 'ChIJ_Y2Rm81JzDERKAawVfuGOd8', 'MEM00016', '2024-02-07 08:37:59'),
('SAV00035', 'ChIJYS9kPNNJzDERipN-3r0cjME', 'MEM00003', '2024-02-08 20:41:16'),
('SAV00036', 'ChIJ95t1pi1MzDERSkMoLupf4L8', 'MEM00017', '2024-02-09 13:07:55'),
('SAV00037', 'ChIJbYzBirRJzDER6sOW8QgA454', 'MEM00020', '2024-02-10 15:26:39'),
('SAV00038', 'ChIJ82c8mRlIzDERzI11F-hu-ck', 'MEM00011', '2024-02-11 09:54:21'),
('SAV00039', 'ChIJd3wHjQZSzDERlE6gjtEiKQU', 'MEM00008', '2024-02-12 19:38:42'),
('SAV00040', 'ChIJMzEi4RO2zTERndqHFncbrOI', 'MEM00018', '2024-02-13 07:29:57'),
('SAV00041', 'ChIJo826tmxIzDERoClaspOvR94', 'MEM00001', '2024-02-14 21:14:33'),
('SAV00042', 'ChIJBahJiQxHzDER-Z5vs7Lrv_I', 'MEM00006', '2024-02-15 08:02:44'),
('SAV00043', 'ChIJM5cxndM3zDER7WuP_cN-omg', 'MEM00009', '2024-02-16 16:11:38'),
('SAV00044', 'ChIJEWkeL7ZJzDER38lq7GVsWyk', 'MEM00014', '2024-02-17 12:46:22'),
('SAV00045', 'ChIJJX8hZM9JzDER-yYg0nIT468', 'MEM00019', '2024-02-18 14:09:19'),
('SAV00046', 'ChIJ4R-DCrY5zDERL3vbAscAyPI', 'MEM00004', '2024-02-19 11:18:05'),
('SAV00047', 'ChIJu8zWwchJzDERhcsx4AhQ1oo', 'MEM00013', '2024-02-20 18:43:55'),
('SAV00048', 'ChIJI2g2x35SzDERQrxACfDVnNU', 'MEM00002', '2024-02-21 13:24:40'),
('SAV00049', 'ChIJtVRanyRIzDERy5XhmJomDtw', 'MEM00010', '2024-02-22 09:37:28'),
('SAV00050', 'ChIJ45QwVSY2zDERclDylVRcVsQ', 'MEM00005', '2024-02-23 20:14:59');


INSERT INTO Histories VALUES
('HIS00001', 'Trip Plan to Kuala Lumpur City Centre', 'TP00001', 'MEM00001', '2025-08-01 10:00:00'),
('HIS00002', 'Visit Petronas Twin Towers', 'TP00002', 'MEM00001', '2025-08-01 10:10:00'),
('HIS00003', 'Food Hunt in Bukit Bintang', 'TP00003', 'MEM00001', '2025-08-01 10:20:00'),
('HIS00004', 'Cultural Tour to Batu Caves', 'TP00004', 'MEM00001', '2025-08-01 10:30:00'),
('HIS00005', 'Shopping at Pavilion KL', 'TP00005', 'MEM00001', '2025-08-01 10:40:00'),

('HIS00006', 'Trip Plan to Kuala Lumpur City Centre', 'TP00001', 'MEM00002', '2025-08-01 11:00:00'),
('HIS00007', 'Visit Petronas Twin Towers', 'TP00002', 'MEM00002', '2025-08-01 11:10:00'),
('HIS00008', 'Food Hunt in Bukit Bintang', 'TP00003', 'MEM00002', '2025-08-01 11:20:00'),
('HIS00009', 'Cultural Tour to Batu Caves', 'TP00004', 'MEM00002', '2025-08-01 11:30:00'),
('HIS00010', 'Shopping at Pavilion KL', 'TP00005', 'MEM00002', '2025-08-01 11:40:00'),

-- Extra similar topics
('HIS00011', 'KLCC Night View Plan', 'TP00006', 'MEM00001', '2025-08-01 12:00:00'),
('HIS00012', 'KLCC Night View Plan', 'TP00006', 'MEM00002', '2025-08-01 12:10:00'),
('HIS00013', 'Discover Chinatown KL', 'TP00007', 'MEM00001', '2025-08-01 12:20:00'),
('HIS00014', 'Discover Chinatown KL', 'TP00007', 'MEM00002', '2025-08-01 12:30:00'),
('HIS00015', 'Street Food in Jalan Alor', 'TP00008', 'MEM00001', '2025-08-01 12:40:00'),
('HIS00016', 'Street Food in Jalan Alor', 'TP00008', 'MEM00002', '2025-08-01 12:50:00'),
('HIS00017', 'Merdeka Square History Tour', 'TP00009', 'MEM00001', '2025-08-01 13:00:00'),
('HIS00018', 'Merdeka Square History Tour', 'TP00009', 'MEM00002', '2025-08-01 13:10:00'),
('HIS00019', 'Visit Thean Hou Temple', 'TP00010', 'MEM00001', '2025-08-01 13:20:00'),
('HIS00020', 'Visit Thean Hou Temple', 'TP00010', 'MEM00002', '2025-08-01 13:30:00'),

-- User MEM00003: different topics (TP00011–TP00020)
('HIS00021', 'Trip to Penang Street Art', 'TP00011', 'MEM00003', '2025-08-01 14:00:00'),
('HIS00022', 'Explore George Town Heritage', 'TP00012', 'MEM00003', '2025-08-01 14:10:00'),
('HIS00023', 'Visit Kek Lok Si Temple', 'TP00013', 'MEM00003', '2025-08-01 14:20:00'),
('HIS00024', 'Penang Hill Sunrise Tour', 'TP00014', 'MEM00003', '2025-08-01 14:30:00'),
('HIS00025', 'Trip Plan to Kuala Lumpur', 'TP00015', 'MEM00003', '2025-08-01 22:26:07'),

-- Add more to make 50 records
('HIS00026', 'Penang Night Market Walk', 'TP00016', 'MEM00003', '2025-08-01 15:00:00'),
('HIS00027', 'Cheong Fatt Tze Mansion Visit', 'TP00017', 'MEM00003', '2025-08-01 15:10:00'),
('HIS00028', 'Butterworth Street Art', 'TP00018', 'MEM00003', '2025-08-01 15:20:00'),
('HIS00029', 'Penang Street Food Hunt', 'TP00019', 'MEM00003', '2025-08-01 15:30:00'),
('HIS00030', 'Penang Botanic Gardens', 'TP00020', 'MEM00003', '2025-08-01 15:40:00'),

-- More records for MEM00001 and MEM00002 with same topics
('HIS00031', 'KL Tower Night City View', 'TP00021', 'MEM00001', '2025-08-01 16:00:00'),
('HIS00032', 'KL Tower Night City View', 'TP00021', 'MEM00002', '2025-08-01 16:10:00'),
('HIS00033', 'Art Gallery Visit', 'TP00022', 'MEM00001', '2025-08-01 16:20:00'),
('HIS00034', 'Art Gallery Visit', 'TP00022', 'MEM00002', '2025-08-01 16:30:00'),
('HIS00035', 'KL Lake Gardens Plan', 'TP00023', 'MEM00001', '2025-08-01 16:40:00'),
('HIS00036', 'KL Lake Gardens Plan', 'TP00023', 'MEM00002', '2025-08-01 16:50:00'),

('HIS00037', 'Visit National Museum', 'TP00024', 'MEM00001', '2025-08-01 17:00:00'),
('HIS00038', 'Visit National Museum', 'TP00024', 'MEM00002', '2025-08-01 17:10:00'),
('HIS00039', 'Shopping in Mid Valley', 'TP00025', 'MEM00001', '2025-08-01 17:20:00'),
('HIS00040', 'Shopping in Mid Valley', 'TP00025', 'MEM00002', '2025-08-01 17:30:00'),

('HIS00041', 'National Mosque Visit', 'TP00026', 'MEM00001', '2025-08-01 17:40:00'),
('HIS00042', 'National Mosque Visit', 'TP00026', 'MEM00002', '2025-08-01 17:50:00'),
('HIS00043', 'Explore Putrajaya', 'TP00027', 'MEM00001', '2025-08-01 18:00:00'),
('HIS00044', 'Explore Putrajaya', 'TP00027', 'MEM00002', '2025-08-01 18:10:00'),
('HIS00045', 'Islamic Arts Museum Tour', 'TP00028', 'MEM00001', '2025-08-01 18:20:00'),
('HIS00046', 'Islamic Arts Museum Tour', 'TP00028', 'MEM00002', '2025-08-01 18:30:00'),

('HIS00047', 'Eco Park Adventure', 'TP00029', 'MEM00001', '2025-08-01 18:40:00'),
('HIS00048', 'Eco Park Adventure', 'TP00029', 'MEM00002', '2025-08-01 18:50:00'),
('HIS00049', 'Discover KL Bird Park', 'TP00030', 'MEM00001', '2025-08-01 19:00:00'),
('HIS00050', 'Discover KL Bird Park', 'TP00030', 'MEM00002', '2025-08-01 19:10:00');


INSERT INTO Places (PlaceID, name, lat, lng, rating) VALUES
('ChIJd8BlQ2BZwokRAFUEcm_qrcA', 'Central Park', 40.785091, -73.968285, 4.7),
('ChIJPTacEpBQwokRKwIlDXelxkA', 'Statue of Liberty', 40.689247, -74.044502, 4.8),
('ChIJW6AIkVX2j4ARcP8AG8sW5nI', 'Golden Gate Bridge', 37.819929, -122.478255, 4.6),
('ChIJLfyY2E4afDQRfxtZ9QGe7ms', 'Petronas Twin Towers', 3.15785, 101.7118, 4.5),
('ChIJcU1XhN9awokR8r5KJBMz5V0', 'Times Square', 40.758896, -73.985130, 4.4);



INSERT INTO Users (UserID, Role, Name, ContactNumber, Gender, Email, Password, Image, Status)
VALUES 
    ('MEM00001', 'Member', 'John Doe', '0123456789', 'Male', 'john@example.com', '123', NULL, 'Active'),
    ('MEM00002', 'Member', 'Jane Smith', '01123456789', 'Female', 'jane@example.com', '123', NULL, 'Active'),
    ('MEM00003', 'Member', 'Alice Johnson', '0198765432', 'Female', 'alice@example.com', '123', NULL, 'Active'),
    ('MEM00004', 'Member', 'Bob Brown', '0134567890', 'Male', 'bob@example.com', '123', NULL, 'Active'),
    ('MEM00005', 'Member', 'Sarah Johnson', '0178901234', 'Female', 'sarah@example.com', '123', NULL, 'Active'),
    ('MEM00006', 'Member', 'Michael Brown', '0167890123', 'Male', 'michael@example.com', '123', NULL, 'Active'),
    ('MEM00007', 'Member', 'Emily Rodriguez', '0154321098', 'Female', 'emily@example.com', '123', NULL, 'Active'),
    ('MEM00008', 'Member', 'Emma Lee', '0143210987', 'Female', 'emma@example.com', '123', NULL, 'Active'),
    ('MEM00009', 'Member', 'Daniel Smith', '0187654321', 'Male', 'daniel@example.com', '123', NULL, 'Active'),
    ('MEM00010', 'Member', 'Olivia Martinez', '0132567890', 'Female', 'olivia@example.com', '123', NULL, 'Active'),
    ('MEM00011', 'Member', 'William Taylor', '0198456723', 'Male', 'william@example.com', '123', NULL, 'Active'),
    ('MEM00012', 'Member', 'Sophia Thomas', '0189753421', 'Female', 'sophia@example.com', '123', NULL, 'Active'),
    ('MEM00013', 'Member', 'James Anderson', '0176543210', 'Male', 'james@example.com', '123', NULL, 'Active'),
    ('MEM00014', 'Member', 'Ava Moore', '0198765432', 'Female', 'ava@example.com', '123', NULL, 'Active'),
    ('MEM00015', 'Member', 'Alexander White', '0156781234', 'Male', 'alexander@example.com', '123', NULL, 'Active'),
    ('MEM00016', 'Member', 'Isabella Harris', '0176540987', 'Female', 'isabella@example.com', '123', NULL, 'Active'),
    ('MEM00017', 'Member', 'Benjamin Martin', '0123456789', 'Male', 'benjamin@example.com', '123', NULL, 'Active'),
    ('MEM00018', 'Member', 'Mia Thompson', '0167890123', 'Female', 'mia@example.com', '123', NULL, 'Active'),
    ('MEM00019', 'Member', 'Henry Garcia', '0145678901', 'Male', 'henry@example.com', '123', NULL, 'Active'),
    ('MEM00020', 'Member', 'Amelia Martinez', '0154321098', 'Female', 'amelia@example.com', '123', NULL, 'Inactive');

INSERT INTO Recommendation (RecommendationID, Name, Type, Image, Description, City, Country, UserID)
VALUES
('RE00001', 'Petronas Twin Towers', 'Landmark', NULL, 'Iconic twin skyscrapers in Kuala Lumpur.', 'Kuala Lumpur', 'Malaysia', 'MEM00001'),
('RE00002', 'Langkawi Sky Bridge', 'Attraction', NULL, 'Curved pedestrian bridge with stunning views.', 'Langkawi', 'Malaysia', 'MEM00002'),
('RE00003', 'Mount Kinabalu', 'Nature', NULL, 'Malaysia’s highest peak and a UNESCO site.', 'Kota Kinabalu', 'Malaysia', 'MEM00003'),
('RE00004', 'Penang Street Art', 'Cultural', NULL, 'Famous interactive murals in George Town.', 'George Town', 'Malaysia', 'MEM00002'),
('RE00005', 'Cameron Highlands Tea Plantation', 'Nature', NULL, 'Scenic tea valleys and cool climate.', 'Cameron Highlands', 'Malaysia', 'MEM00001'),
('RE00006', 'Sunway Lagoon', 'Theme Park', NULL, 'Large amusement and water park.', 'Petaling Jaya', 'Malaysia', 'MEM00003'),
('RE00007', 'Jonker Street', 'Market', NULL, 'Vibrant night market famous for local food.', 'Malacca', 'Malaysia', 'MEM00001'),
('RE00008', 'Perhentian Islands', 'Beach', NULL, 'Tropical islands with crystal-clear water.', 'Kuala Besut', 'Malaysia', 'MEM00002'),
('RE00009', 'Batu Caves', 'Temple', NULL, 'Hindu temple inside limestone caves.', 'Gombak', 'Malaysia', 'MEM00003'),
('RE00010', 'Thean Hou Temple', 'Cultural', NULL, 'One of the oldest and largest temples in Southeast Asia.', 'Kuala Lumpur', 'Malaysia', 'MEM00002');

INSERT INTO Popular_Destination (DesID, Name, Type, Image, Description, City, Country)
VALUES
('POP00001', 'Petronas Twin Towers', 'Landmark', NULL, 'Iconic twin skyscrapers in Kuala Lumpur.', 'Kuala Lumpur', 'Malaysia'),
('POP00002', 'Langkawi Sky Bridge', 'Attraction', NULL, 'Curved pedestrian bridge with stunning views.', 'Langkawi', 'Malaysia'),
('POP00003', 'Mount Kinabalu', 'Nature', NULL, 'Malaysia’s highest peak and a UNESCO site.', 'Kota Kinabalu', 'Malaysia'),
('POP00004', 'Penang Street Art', 'Cultural', NULL, 'Famous interactive murals in George Town.', 'George Town', 'Malaysia'),
('POP00005', 'Cameron Highlands Tea Plantation', 'Nature', NULL, 'Scenic tea valleys and cool climate.', 'Cameron Highlands', 'Malaysia'),
('POP00006', 'Sunway Lagoon', 'Theme Park', NULL, 'Large amusement and water park.', 'Petaling Jaya', 'Malaysia'),
('POP00007', 'Jonker Street', 'Market', NULL, 'Vibrant night market famous for local food.', 'Malacca', 'Malaysia'),
('POP00008', 'Perhentian Islands', 'Beach', NULL, 'Tropical islands with crystal-clear water.', 'Kuala Besut', 'Malaysia'),
('POP00009', 'Batu Caves', 'Temple', NULL, 'Hindu temple inside limestone caves.', 'Gombak', 'Malaysia'),
('POP00010', 'Thean Hou Temple', 'Cultural', NULL, 'One of the oldest and largest temples in Southeast Asia.', 'Kuala Lumpur', 'Malaysia');

INSERT INTO UserPreferences 
(PreferenceID, PreferredBudgetRange, PreferredTravelSeason, LikeCulturalExperiences, LikeOutdoorAdventures, LikeRelaxingPlaces, UserID)
VALUES
('UP00001', 'Medium', 'Summer', TRUE, TRUE, FALSE, 'MEM00001'),
('UP00002', 'High', 'Winter', FALSE, TRUE, TRUE, 'MEM00002'),
('UP00003', 'Low', 'Spring', TRUE, FALSE, TRUE, 'MEM00003');


-- UserPreferredTravelTypes table
INSERT INTO UserPreferredTravelTypes (PreferredTravelTypesID, TravelType, UserID)
VALUES
('PT00001', 'Nature', 'MEM00001'),
('PT00002', 'Beach', 'MEM00001'),
('PT00003', 'Historical', 'MEM00001'),
('PT00004', 'Cultural', 'MEM00001'),
('PT00005', 'Adventure', 'MEM00001'),
('PT00006', 'City', 'MEM00001'),
('PT00007', 'Food', 'MEM00001'),
('PT00008', 'Adventure', 'MEM00002'),
('PT00009', 'Beach', 'MEM00002'),
('PT00010', 'Cultural', 'MEM00003'),
('PT00011', 'City', 'MEM00003');

-- UserFavoriteActivities table
INSERT INTO UserFavoriteActivities (UserFavoriteActivitiesID, Activity, UserID)
VALUES
('FA00001', 'Hiking', 'MEM00001'),
('FA00002', 'Food Hunting', 'MEM00001'),
('FA00003', 'Photography', 'MEM00001'),
('FA00004', 'Cycling', 'MEM00001'),
('FA00005', 'Camping', 'MEM00001'),
('FA00006', 'Museum Visits', 'MEM00001'),
('FA00007', 'Shopping', 'MEM00002'),
('FA00008', 'Swimming', 'MEM00002'),
('FA00009', 'Museum Visits', 'MEM00003'),
('FA00010', 'Photography', 'MEM00003');

-- UserFavoriteCities table
INSERT INTO UserFavoriteCities (UserFavoriteCitiesID, City, UserID)
VALUES
('FC00001', 'Penang', 'MEM00001'),
('FC00002', 'Langkawi', 'MEM00001'),
('FC00003', 'Ipoh', 'MEM00001'),
('FC00004', 'Kuala Lumpur', 'MEM00001'),
('FC00005', 'Malacca', 'MEM00001'),
('FC00006', 'Kota Kinabalu', 'MEM00001'),
('FC00007', 'Kuala Lumpur', 'MEM00002'),
('FC00008', 'Malacca', 'MEM00002'),
('FC00009', 'George Town', 'MEM00003'),
('FC00010', 'Ipoh', 'MEM00003');

INSERT INTO TripPlan (TPID, City, StartDate, EndDate, Adult, Children, UserID) VALUES
('TP00001', 'Penang', '2025-08-10', '2025-08-12', 2, 1, 'MEM00001'),
('TP00002', 'Langkawi', '2025-09-01', '2025-09-05', 2, 0, 'MEM00002'),
('TP00003', 'Kuala Lumpur', '2025-10-03', '2025-10-06', 1, 0, 'MEM00003'),
('TP00004', 'Malacca', '2025-11-10', '2025-11-11', 4, 2, 'MEM00004'),
('TP00005', 'Ipoh', '2025-08-20', '2025-08-21', 2, 0, 'MEM00005'),
('TP00006', 'Kuching', '2025-08-15', '2025-08-18', 3, 1, 'MEM00001'),
('TP00007', 'Kota Kinabalu', '2025-12-01', '2025-12-04', 2, 0, 'MEM00002'),
('TP00008', 'Cameron Highlands', '2025-08-25', '2025-08-27', 1, 0, 'MEM00003'),
('TP00009', 'Johor Bahru', '2025-09-15', '2025-09-16', 2, 1, 'MEM00004'),
('TP00010', 'Taiping', '2025-10-10', '2025-10-12', 3, 0, 'MEM00005');

INSERT INTO TripPlanDetails (PDID, Date, Time, Place, RecommendMeals, TPID) VALUES
('PD00001', '2025-08-10', '09:00:00', 'Penang Hill', 'Nasi Lemak', 'PLAN0001'),
('PD00002', '2025-08-10', '13:00:00', 'Kek Lok Si Temple', 'Char Kway Teow', 'PLAN0001'),
('PD00003', '2025-08-10', '19:00:00', 'Gurney Drive Food Street', 'Seafood', 'PLAN0001'),
('PD00004', '2025-09-01', '10:00:00', 'Langkawi Sky Bridge', 'Laksa', 'PLAN0002'),
('PD00005', '2025-09-01', '15:00:00', 'Underwater World', 'Ikan Bakar', 'PLAN0002'),
('PD00006', '2025-10-03', '11:00:00', 'Petronas Twin Towers', 'Nasi Kandar', 'PLAN0003'),
('PD00007', '2025-10-03', '17:00:00', 'Bukit Bintang', 'Satay', 'PLAN0003'),
('PD00008', '2025-11-10', '09:30:00', 'A Famosa', 'Chicken Rice Ball', 'PLAN0004'),
('PD00009', '2025-11-10', '14:00:00', 'Jonker Street', 'Cendol', 'PLAN0004'),
('PD00010', '2025-08-20', '10:00:00', 'Concubine Lane', 'Bean Sprout Chicken', 'PLAN0005');








-- Create table
CREATE TABLE Organisations (
    OrganisationID varchar(8) PRIMARY KEY NOT NULL,
    Type varchar(255) NOT NULL,
    Name varchar(255) NOT NULL,
    BRNCode varchar(15) NOT NULL,
    ContactNumber varchar(15) NOT NULL,
    Verification varchar(20) NOT NULL,
    Status varchar(20) NOT NULL,
    Image longblob DEFAULT NULL,
    Statement longblob DEFAULT NULL,
    Bank varchar(30) NOT NULL,
    BankAccount varchar(30) NOT NULL,
    BAName varchar(55) NOT NULL,
    Description varchar(255) NOT NULL
);

CREATE TABLE Organisations_Members (
    OMID varchar(8) PRIMARY KEY NOT NULL,
    OrganisationRole varchar(20) NOT NULL,
    UserID varchar(8) NOT NULL,
    OrganisationID varchar(8) NOT NULL,
    FOREIGN KEY (OrganisationID) REFERENCES Organisations(OrganisationID),
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

CREATE TABLE Animals (
    AnimalID varchar(8) PRIMARY KEY NOT NULL,
    Name varchar(50),
    Type varchar(30) NOT NULL,
    Status varchar(30) NOT NULL,
    Image longblob DEFAULT NULL,
    Description varchar(255),
    FunderID varchar(8),
    OrganisationID varchar(8) NOT NULL,
    FOREIGN KEY (OrganisationID) REFERENCES Organisations(OrganisationID),
    FOREIGN KEY (FunderID) REFERENCES Users(UserID)
);

CREATE TABLE Questions (
    QuestionID varchar(8) PRIMARY KEY NOT NULL,
    Question varchar(255) NOT NULL,
    Date date NOT NULL,
    Time time NOT NULL,
    Status varchar(30) NOT NULL,
    QueryUnder varchar(8) NOT NULL,
    InquirerID varchar(8) NOT NULL,
    FOREIGN KEY (InquirerID) REFERENCES Users(UserID)
);

CREATE TABLE Replies (
    ReplyID varchar(8) PRIMARY KEY NOT NULL,
    Reply varchar(255) NOT NULL,
    Date date NOT NULL,
    Time time NOT NULL,
    IsOrganisation boolean,
    Status varchar(30) NOT NULL,
    QuestionID varchar(8) NOT NULL,
    ReplierID varchar(8) NOT NULL,
    FOREIGN KEY (ReplierID) REFERENCES Users(UserID),
    FOREIGN KEY (QuestionID) REFERENCES Questions(QuestionID)
);

CREATE TABLE Sponsor_History (
    TransactionID varchar(8) PRIMARY KEY NOT NULL,
    Type varchar(30) NOT NULL,
    Amount float NOT NULL,
    Date date NOT NULL,
    Time time NOT NULL,
    Status varchar(30) NOT NULL,
    BeneficiaryID varchar(8) NOT NULL,
    FunderID varchar(8) NOT NULL,
    FOREIGN KEY (FunderID) REFERENCES Users(UserID)
);

CREATE TABLE Transaction_History (
    TransactionID varchar(8) PRIMARY KEY NOT NULL,
    Type varchar(30) NOT NULL,
    CRorDR varchar(2) NOT NULL,
    Amount float NOT NULL,
    Date date NOT NULL,
    Time time NOT NULL,
    Status varchar(30) NOT NULL,
    Image longblob,
    UserID varchar(8) NOT NULL, (request by or from)
    OrganisationID varchar(8) NOT NULL,
    FOREIGN KEY (UserID) REFERENCES Users(UserID),
    FOREIGN KEY (OrganisationID) REFERENCES Organisations(OrganisationID)
);

CREATE TABLE Adoption_Application (
    AAID varchar(8) PRIMARY KEY NOT NULL,
    Date date NOT NULL,
    Status varchar(30) NOT NULL,
    ApplicantID varchar(8) NOT NULL,
    AnimalID varchar(8) NOT NULL,
    FOREIGN KEY (ApplicantID) REFERENCES Users(UserID),
    FOREIGN KEY (AnimalID) REFERENCES Animals(AnimalID)
);

CREATE TABLE Volunteer_Application (
    VAID varchar(8) PRIMARY KEY NOT NULL,
    ICName varchar(30) NOT NULL,
    Date date NOT NULL,
    Status varchar(30) NOT NULL,
    StartDate date NOT NULL,
    EndDate date NOT NULL,
    Description varchar(255) NOT NULL,
    ApplicantID varchar(8) NOT NULL,
    OrganisationID varchar(8) NOT NULL,
    FOREIGN KEY (ApplicantID) REFERENCES Users(UserID),
    FOREIGN KEY (OrganisationID) REFERENCES Organisations(OrganisationID)
);

CREATE TABLE Notifications (
    NotificationID varchar(8) PRIMARY KEY NOT NULL,
    Title varchar(30) NOT NULL,
    Message varchar(255) NOT NULL,
    Date date NOT NULL,
    Time time NOT NULL,
    IsRead boolean,
    AttachedID varchar(8),
    ReceiverID varchar(8) NOT NULL,
    FOREIGN KEY (ReceiverID) REFERENCES Users(UserID)
);

CREATE TABLE Statements (
    StatementID varchar(8) PRIMARY KEY NOT NULL,
    Statement longblob,
    Title varchar(30) NOT NULL,
    Date date NOT NULL,
    Status varchar(30) NOT NULL,
    Month varchar(30),
    Year varchar(30),
    OrganisationID varchar(8) NOT NULL,
    UploadBy varchar(8) NOT NULL,
    FOREIGN KEY (OrganisationID) REFERENCES Organisations(OrganisationID),
    FOREIGN KEY (UploadBy) REFERENCES Users(UserID)
);

CREATE TABLE Images (
    ImageID varchar(8) PRIMARY KEY NOT NULL,
    Caption VARCHAR(50),
    Status varchar(30) NOT NULL,
    Image longblob,
    Under varchar(8) NOT NULL
);

CREATE TABLE Issue_Report (
    IRID varchar(7) PRIMARY KEY NOT NULL,
    Title VARCHAR(30) NOT NULL,
    Message VARCHAR(100) NOT NULL,
    Date date NOT NULL,
    Time time NOT NULL,
    Image longblob,
    UserID varchar(8) NOT NULL,
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

CREATE TABLE IR_History (
    IRHistoryID varchar(8) PRIMARY KEY NOT NULL,
    Status varchar(30) NOT NULL,
    SolutionDescription VARCHAR(100),
    Attachment longblob,
    Date date NOT NULL,
    Time time NOT NULL,
    IRID varchar(7) NOT NULL,
    AdminID varchar(8),
    FOREIGN KEY (IRID) REFERENCES Issue_Report(IRID),
    FOREIGN KEY (AdminID) REFERENCES Users(UserID)
);

-- Insert data for admins
INSERT INTO Users (UserID, Role, Name, ContactNumber, Gender, Email, Password, Image, Status)
VALUES 
    ('ADM001', 'Admin', 'Admin1', '1234567890', 'Male', 'admin1@example.com', '456', NULL, 'Active'),
    ('ADM002', 'Admin', 'ViNie Goh', '9876543210', 'Female', 'admin2@example.com', '456', NULL, 'Active');


INSERT INTO Questions (QuestionID, Question, Date, Time, Status, QueryUnder, InquirerID)
VALUES
('QUE00001', 'Test Ask 1??', '2024-05-02', '18:40:00', 'Active', 'ANM00001', 'MEM00008'),
('QUE00002', 'Test Ask 2??', '2024-05-02', '18:40:00', 'Active', 'ORG00001', 'MEM00008'),
('QUE00003', 'Test Ask 3??', '2024-05-02', '18:40:00', 'Active', 'ORG00001', 'MEM00009'),
('QUE00004', 'Test Ask 4??', '2024-05-02', '18:40:00', 'Active', 'ORG00001', 'MEM00008'),
('QUE00005', 'Test Ask 5??', '2024-05-02', '18:40:00', 'Active', 'ANM00001', 'MEM00009');

INSERT INTO Replies (ReplyID, Reply, Date, Time, IsOrganisation, Status, QuestionID, ReplierID)
VALUES
('REP00001', 'Test Reply 1.', '2024-05-02', '18:40:00', TRUE, 'Active', 'QUE00002', 'MEM00002'),
('REP00002', 'Test Reply 2.', '2024-05-02', '18:40:00', FALSE, 'Active', 'QUE00002', 'MEM00008'),
('REP00003', 'Test Reply 3.', '2024-05-02', '18:40:00', TRUE, 'Active', 'QUE00002', 'MEM00002'),
('REP00004', 'Test Reply 4.', '2024-05-02', '18:40:00', TRUE, 'Active', 'QUE00001', 'MEM00002'),
('REP00005', 'Test Reply 5.', '2024-05-02', '18:40:00', FALSE, 'Active', 'QUE00001', 'MEM00009'),
('REP00006', 'Test Reply 6.', '2024-05-02', '18:40:00', TRUE, 'Active', 'QUE00001', 'MEM00002');

INSERT INTO Adoption_Application (AAID, Date, Status, ApplicantID, AnimalID)
VALUES
('A_A00001', '2024-05-01', 'Contacted', 'MEM00008', 'ANM00001'),
('A_A00002', '2024-05-02', 'Pending', 'MEM00008', 'ANM00004'),
('A_A00003', '2024-05-03', 'Rejected', 'MEM00008', 'ANM00005');

INSERT INTO Volunteer_Application (VAID, ICName, Date, Status, StartDate, EndDate, Description, ApplicantID, OrganisationID)
VALUES
('V_A00001', 'Emma', '2024-05-01', 'Contacted', '2024-05-01', '2024-05-01', '...', 'MEM00008', 'ORG00001'),
('V_A00002', 'Emma', '2024-05-02', 'Pending', '2024-05-02', '2024-05-03', '...', 'MEM00008', 'ORG00001'),
('V_A00003', 'Emma', '2024-05-03', 'Rejected', '2024-05-03', '2024-05-03', '...', 'MEM00008', 'ORG00002');

INSERT INTO Notifications (NotificationID, Title, Message, Date, Time, IsRead, AttachedID, ReceiverID)
VALUES
('NOT00001', '123', '123', '2024-05-03', '18:40:00', '1', 'ANM00001', 'MEM00001'),
('NOT00002', '123', '123', '2024-05-03', '18:40:00', '0', 'ANM00001', 'MEM00001'),
('NOT00003', '123', '123', '2024-05-03', '18:40:00', '1', 'ANM00001', 'MEM00001'),
('NOT00004', '123', '123', '2024-05-03', '18:40:00', '0', 'ANM00001', 'MEM00008'),
('NOT00005', '123', '123', '2024-05-03', '18:40:00', '0', 'ANM00001', 'MEM00008'),
('NOT00006', '123', '123', '2024-05-03', '18:40:00', '1', 'ANM00001', 'MEM00008'),
('NOT00007', '123', '123', '2024-05-03', '18:40:00', '1', 'ANM00001', 'MEM00008'),
('NOT00008', '123', '123', '2024-05-03', '18:40:00', '1', 'ANM00001', 'MEM00008');

INSERT INTO Statements (StatementID, Statement, Title, Date, Status, Month, Year, OrganisationID, UploadBy)
VALUES
('STA00001', NULL, 'Combined Documents', '2024-05-03', 'Approved', NULL, NULL, 'ORG00001', 'MEM00001'),
('STA00002', NULL, 'Combined Documents', '2024-05-03', 'Rejected', NULL, NULL, 'ORG00001', 'MEM00002'),
('STA00003', NULL, 'Combined Documents', '2024-05-03', 'Pending', NULL, NULL, 'ORG00001', 'MEM00001'),
('STA00004', NULL, 'Combined Documents', '2024-05-03', 'Approved', NULL, NULL, 'ORG00001', 'MEM00001'),
('STA00005', NULL, 'Combined Documents', '2024-05-03', 'Approved', NULL, NULL, 'ORG00002', 'MEM00001'),
('STA00006', NULL, 'Combined Documents', '2024-05-03', 'Pending', NULL, NULL, 'ORG00002', 'MEM00001'),
('STA00007', NULL, 'Financial Statements', '2024-05-03', 'Approved', '3', 2024, 'ORG00001', 'MEM00001'),
('STA00008', NULL, 'Financial Statements', '2024-05-03', 'Approved', '4', 2024, 'ORG00001', 'MEM00001'),
('STA00009', NULL, 'Financial Statements', '2024-05-03', 'Pending', '3', 2024, 'ORG00001', 'MEM00001'),
('STA00010', NULL, 'Financial Statements', '2024-05-03', 'Pending', '4', 2024, 'ORG00001', 'MEM00001');

INSERT INTO Images (ImageID, Caption, Type, Image, Under) 
VALUES 
('IMG00001', 'an image', 'Image', NULL, 'ANM00005'),
('IMG00002', 'an image', 'Image', NULL, 'ANM00005'),
('IMG00003', 'an image', 'Image', NULL, 'ANM00005'),
('IMG00004', 'an image', 'Image', NULL, 'ANM00005'),
('IMG00005', 'an image', 'Image', NULL, 'ANM00005'),
('IMG00006', 'an image', 'Image', NULL, 'ANM00005'),
('IMG00007', 'an image', 'Image', NULL, 'ANM00005'),
('IMG00008', 'an image', 'Image', NULL, 'ANM00005'),
('IMG00009', 'an image', 'Image', NULL, 'ANM00005');

INSERT INTO Issue_Report (IRID, Title, Message, Date, Time, Image, UserID)
VALUES
('IR00001', 'Issue Title 1', 'A message regarding issue 1.', '2024-05-03', '18:40:00', NULL, 'MEM00008'),
('IR00002', 'Issue Title 2', 'A message regarding issue 2.', '2024-05-03', '18:40:00', NULL, 'MEM00009'),
('IR00003', 'Issue Title 3', 'A message regarding issue 3.', '2024-05-03', '18:40:00', NULL, 'MEM00009'),
('IR00004', 'Issue Title 4', 'A message regarding issue 4.', '2024-05-03', '18:40:00', NULL, 'MEM00008'),
('IR00005', 'Issue Title 5', 'A message regarding issue 5.', '2024-05-03', '18:40:00', NULL, 'MEM00008'),
('IR00006', 'Issue Title 6', 'A message regarding issue 6.', '2024-05-03', '18:40:00', NULL, 'MEM00008'),
('IR00007', 'Issue Title 7', 'A message regarding issue 7.', '2024-05-03', '18:40:00', NULL, 'MEM00008'),
('IR00008', 'Issue Title 8', 'A message regarding issue 8.', '2024-05-03', '18:40:00', NULL, 'MEM00008');

INSERT INTO IR_History (IRHistoryID, Status, SolutionDescription, Attachment, Date, Time, IRID, AdminID)
VALUES
('IRH00001', 'Pending', NULL, NULL, '2024-05-03', '18:40:00', 'IR00001', NULL),
('IRH00002', 'Assigned', NULL, NULL, '2024-05-03', '18:40:00', 'IR00001', 'MEM00001'),
('IRH00003', 'In Progress', NULL, NULL, '2024-05-03', '18:40:00', 'IR00001', 'MEM00001'),
('IRH00004', 'Solved', 'This is solution 1', NULL, '2024-05-03', '18:40:00', 'IR00001', 'MEM00001'),
('IRH00005', 'Deleted', NULL, NULL, '2024-05-03', '18:40:00', 'IR00001', 'MEM00001'),
('IRH00006', 'Pending', NULL, NULL, '2024-05-03', '18:40:00', 'IR00002', NULL),
('IRH00007', 'Pending', NULL, NULL, '2024-05-03', '18:40:00', 'IR00003', NULL),
('IRH00008', 'Pending', NULL, NULL, '2024-05-03', '18:40:00', 'IR00004', NULL),
('IRH00009', 'Pending', NULL, NULL, '2024-05-03', '18:40:00', 'IR00005', NULL),
('IRH00010', 'Pending', NULL, NULL, '2024-05-03', '18:40:00', 'IR00006', NULL),
('IRH00011', 'Pending', NULL, NULL, '2024-05-03', '18:40:00', 'IR00007', NULL),
('IRH00012', 'Pending', NULL, NULL, '2024-05-03', '18:40:00', 'IR00008', NULL);

INSERT INTO Transaction_History (TransactionID, Type, CRorDR, Amount, Date, Time, Status, OrganisationID)
VALUES
('TRN00001', 'One-Time', 'DR', '50', '2024-05-03', '18:40:00', 'Success', 'ANM00001', 'MEM00001'),
('TRN00002', 'One-Time', 'DR', '50', '2024-05-03', '19:40:00', 'Success', 'ANM00001', 'MEM00002'),
('TRN00003', 'One-Time', 'DR', '50', '2024-05-05', '18:40:00', 'Success', 'ANM00001', 'MEM00003'),
('TRN00004', 'One-Time', 'DR', '50', '2024-05-06', '18:40:00', 'Success', 'ANM00001', 'MEM00004'),
('TRN00005', 'One-Time', 'DR', '50', '2024-05-07', '18:40:00', 'Success', 'ANM00001', 'MEM00005'),
('TRN00001', 'One-Time', 'DR', '50', '2024-05-07', '18:45:00', 'Failed', 'ANM00001', 'MEM00001'),
('TRN00001', 'Cash Out', 'CR', '20', '2024-05-08', '18:40:00', 'Success', 'ANM00001', 'MEM00001');