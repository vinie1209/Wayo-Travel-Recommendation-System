<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include __DIR__ . '/../Code/db_connection.php';

// Ensure $mysqli is available
if (!isset($mysqli)) {
    $mysqli = new mysqli("localhost", "root", "", "Wayo"); // change name if needed
    if ($mysqli->connect_error) {
        die("Connection failed: " . $mysqli->connect_error);
    }
}

$relevantItems = [];
$locationQuery = "SELECT PlaceID FROM UserSave";
$result = mysqli_query($conn, $locationQuery);
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $relevantItems[] = $row['PlaceID'];
    }
} else {
    die("Error fetching Locations: " . mysqli_error($conn));
}

// --- Step 3: Get all place_id from PopularPlaces
$recommendedItems = [];
$popularQuery = "SELECT place_id FROM PopularPlaces";
$result = mysqli_query($conn, $popularQuery);
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $recommendedItems[] = $row['place_id'];
    }
} else {
    die("Error fetching PopularPlaces: " . mysqli_error($conn));
}

// --- Step 4: Evaluate ALL recommendations (no Top-N)
$matchedItems = array_intersect($recommendedItems, $relevantItems);

$precision = count($recommendedItems) > 0 ? count($matchedItems) / count($recommendedItems) : 0;
$recall = count($relevantItems) > 0 ? count($matchedItems) / count(array_unique($relevantItems)) : 0;
$f1 = ($precision + $recall) > 0 ? 2 * ($precision * $recall) / ($precision + $recall) : 0;

// --- Step 5: Display Results
echo "<h3>📊 Evaluation of Recommendation Relevance Based on User Save Data</h3>";
echo "<b>Relevant Items (Locations):</b> " . implode(', ', $relevantItems) . "<br>";
echo "<b>Recommended Items (All from PopularPlaces):</b> " . implode(', ', $recommendedItems) . "<br>";
echo "<b>Matched Items:</b> " . implode(', ', $matchedItems) . "<br><br>";
echo "<b>Precision:</b> " . round($precision, 2) . "<br>";
echo "<b>Recall:</b> " . round($recall, 2) . "<br>";
echo "<b>F1 Score:</b> " . round($f1, 2) . "<br>";

// --- Close connection
mysqli_close($conn);
?>