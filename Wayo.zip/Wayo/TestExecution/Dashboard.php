<?php
echo "<h3>▶ Test Execution: Dashboard.php Automated Test</h3>";

function runTest($description, $callback) {
    echo "<strong>$description:</strong> ";
    try {
        $result = $callback();
        echo $result ? "<span style='color:green;'>PASSED</span><br>" : "<span style='color:red;'>FAILED</span><br>";
    } catch (Exception $e) {
        echo "<span style='color:red;'>ERROR - {$e->getMessage()}</span><br>";
    }
}

// Setup cookie for session simulation
$cookieFile = __DIR__ . "/test_cookie.txt";
@unlink($cookieFile);

// 🔹 Test 1: Access without login (should redirect)
runTest("Access without login", function () use ($cookieFile) {
    $ch = curl_init("http://localhost/Wayo/Code/Dashboard.php");
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => false, // we want to see redirect
        CURLOPT_COOKIEFILE => $cookieFile,
        CURLOPT_COOKIEJAR => $cookieFile,
    ]);
    curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $location = curl_getinfo($ch, CURLINFO_REDIRECT_URL);
    curl_close($ch);
    return $http_code === 302 || $location === "http://localhost/Wayo/Code/Login.php";
});

// 🔹 Test 2: Simulate login and access dashboard
runTest("Login and access Dashboard", function () use ($cookieFile) {
    $ch = curl_init("http://localhost/Wayo/Code/Login.php");
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query([
            'email' => 'john@example.com',
            'password' => '123' // ensure this user exists
        ]),
        CURLOPT_COOKIEJAR => $cookieFile,
    ]);
    curl_exec($ch);
    curl_close($ch);

    // Access Dashboard after login
    $ch2 = curl_init("http://localhost/Wayo/Code/Dashboard.php");
    curl_setopt_array($ch2, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_COOKIEFILE => $cookieFile,
    ]);
    $html = curl_exec($ch2);
    curl_close($ch2);

    return strpos($html, 'Popular Destinations') !== false;
});

// 🔹 Test 3: Submit plan with valid data
runTest("Generate plan with valid input", function () {
    $url = "http://localhost/Wayo/GeneratePlan.php?city=Kuala+Lumpur&start=2025-08-08&end=2025-08-10&adults=2&children=1";
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => false
    ]);
    curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return $http_code === 200;
});

// Clean up
@unlink($cookieFile);

echo "<br>✅ Test Execution Completed.";
?>
