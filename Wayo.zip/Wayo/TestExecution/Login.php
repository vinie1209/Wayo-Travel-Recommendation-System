<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h3>▶ Login Authentication Tests</h3>";

function test($desc, $callback) {
    echo "<strong>$desc:</strong> ";
    try {
        $pass = $callback();
        echo $pass ? "<span style='color:green;'>PASSED</span><br>" : "<span style='color:red;'>FAILED</span><br>";
    } catch (Exception $e) {
        echo "<span style='color:red;'>ERROR: {$e->getMessage()}</span><br>";
    }
}

$endpoint = "http://localhost/Wayo/Code/Login.php";

// Corrected function: send form-encoded POST data
function sendLogin($email, $password, $role) {
    global $endpoint;
    $ch = curl_init($endpoint);
    $postFields = http_build_query([
        'email' => $email,
        'password' => $password,
        'role' => $role
    ]);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POSTFIELDS => $postFields,
        CURLOPT_HEADER => false,
    ]);
    $response = curl_exec($ch);
    $info = curl_getinfo($ch);
    curl_close($ch);
    return [$response, $info];
}

// TC01: Valid member login
test("TC01 - Valid login (active member)", function () {
    [$response, $info] = sendLogin("john@example.com", "123", "member");
    return strpos($response, "Login successful") !== false || strpos($response, "Dashboard.php") !== false;
});

// TC02: Inactive member
test("TC02 - Valid login (inactive)", function () {
    [$response, $info] = sendLogin("inactive@example.com", "password", "member");
    return strpos($response, "InactiveAccount.php") !== false;
});

// TC03: Valid admin login
test("TC03 - Valid admin login", function () {
    [$response, $info] = sendLogin("admin@example.com", "adminpass", "admin");
    return strpos($response, "AdminDashboard.php") !== false;
});

// TC04: Member login with PasswordReset flag
test("TC04 - Member login with PasswordReset flag", function () {
    [$response, $info] = sendLogin("reset@example.com", "password", "member");
    return strpos($response, "ResetPassword.php") !== false;
});

// TC05: Invalid email
test("TC05 - Login with invalid email", function () {
    [$response, $info] = sendLogin("noone@example.com", "password", "member");
    return strpos($response, "Invalid email") !== false || strpos($response, "Invalid credentials") !== false;
});

// TC06: Wrong password
test("TC06 - Wrong password", function () {
    [$response, $info] = sendLogin("john@example.com", "wrongpass", "member");
    return strpos($response, "Invalid") !== false;
});

// TC07: Wrong role
test("TC07 - Wrong role", function () {
    [$response, $info] = sendLogin("john@example.com", "123", "admin");
    return strpos($response, "Invalid") !== false;
});

// TC08: Empty email/password
test("TC08 - Empty email/password", function () {
    [$response, $info] = sendLogin("", "", "");
    return strpos($response, "Invalid") !== false;
});

// TC09: CORS OPTIONS request
test("TC09 - OPTIONS preflight returns 204", function () {
    global $endpoint;
    $ch = curl_init($endpoint);
    curl_setopt_array($ch, [
        CURLOPT_CUSTOMREQUEST => "OPTIONS",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HEADER => true,
    ]);
    curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return $code === 204;
});

// TC10: CORS headers present
test("TC10 - CORS headers present", function () {
    global $endpoint;
    $ch = curl_init($endpoint);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HEADER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query([
            'email' => 'john@example.com',
            'password' => '123',
            'role' => 'member'
        ]),
    ]);
    $response = curl_exec($ch);
    $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    $headers = substr($response, 0, $headerSize);
    curl_close($ch);
    return strpos($headers, "Access-Control-Allow-Origin: *") !== false;
});

echo "<br>✅ Login Test Execution Finished.";
?>
