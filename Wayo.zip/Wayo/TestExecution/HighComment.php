<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h3>▶ Test Execution: Login → Chart Mode → List Mode</h3>";

// Setup session cookie file
$cookieFile = __DIR__ . "/cookie.txt";
@unlink($cookieFile); // Remove previous session if exists

// Step 1: Start session by visiting Login.php
$ch = curl_init('http://localhost/Wayo/Code/Login.php');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile);
curl_exec($ch);
curl_close($ch);

// Step 2: Submit login to LoginAuthentication.php
$loginData = [
    'email' => 'john@example.com',
    'password' => '123',
    'role' => 'member',
    'submit' => 'Login'
];

$ch = curl_init('http://localhost/Wayo/Code/LoginAuthentication.php');
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($loginData));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile);
$loginResponse = curl_exec($ch);
$loginStatus = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "<b>Login HTTP Status:</b> $loginStatus<br>";

// Define sample coordinates (Kuala Lumpur)
$lat = '3.1390';
$lng = '101.6869';

// Step 3: Access HighComment.php in chart mode
$chartData = [
    'lat' => $lat,
    'lng' => $lng,
    'mode' => 'chart'
];

$ch = curl_init('http://localhost/Wayo/Code/HighComment.php');
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($chartData));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
$chartResponse = curl_exec($ch);
$chartStatus = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "<b>Chart Mode HTTP Status:</b> $chartStatus<br>";

if ($chartStatus === 200) {
    if (strpos($chartResponse, 'high_comment_plot.png') !== false) {
        echo "✅ Chart image detected.<br>";
    } else {
        echo "❌ Chart image not found.<br>";
    }

    if (strpos($chartResponse, 'Best Popular Places Nearby') !== false) {
        echo "✅ Chart page title is present.<br>";
    }
}

// Step 4: Switch to list mode
$listData = [
    'lat' => $lat,
    'lng' => $lng,
    'mode' => 'list'
];

$ch = curl_init('http://localhost/Wayo/Code/HighComment.php');
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($listData));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
$listResponse = curl_exec($ch);
$listStatus = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "<b>List Mode HTTP Status:</b> $listStatus<br>";

if ($listStatus === 200) {
    if (strpos($listResponse, 'list-item') !== false) {
        echo "✅ List items displayed.<br>";
    } else {
        echo "❌ List items not found.<br>";
    }

    if (strpos($listResponse, 'Best Popular Places Nearby') !== false) {
        echo "✅ List page title is present.<br>";
    }
}
?>
