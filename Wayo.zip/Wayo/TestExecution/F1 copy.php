<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include __DIR__ . '/../Code/db_connection.php';

// Ensure $mysqli is available
if (!isset($mysqli)) {
    $mysqli = new mysqli("localhost", "root", "", "Wayo"); // change name
    if ($mysqli->connect_error) {
        die("Connection failed: " . $mysqli->connect_error);
    }
}
$relevantItems = [];
$locationQuery = "SELECT PlaceID FROM Locations";
$result = mysqli_query($conn, $locationQuery);
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $relevantItems[] = $row['PlaceID'];
    }
} else {
    die("Error fetching Locations: " . mysqli_error($conn));
}

// --- Step 3: Get all place_id from PopularPlaces
$recommendedItems = [];
$popularQuery = "SELECT place_id FROM PopularPlaces";
$result = mysqli_query($conn, $popularQuery);
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $recommendedItems[] = $row['place_id'];
    }
} else {
    die("Error fetching PopularPlaces: " . mysqli_error($conn));
}

// --- Step 4: Select Top-N Recommendations
$topN = 5; // Change N as needed
$topRecommended = array_slice($recommendedItems, 0, $topN);

// --- Step 5: Evaluation
$matchedItems = array_intersect($topRecommended, $relevantItems);

$precision = count($topRecommended) > 0 ? count($matchedItems) / count($topRecommended) : 0;
$recall = count($relevantItems) > 0 ? count($matchedItems) / count(array_unique($relevantItems)) : 0;
$f1 = ($precision + $recall) > 0 ? 2 * ($precision * $recall) / ($precision + $recall) : 0;

// --- Step 6: Display Results
echo "<h3>📊 Evaluation Result (Top-$topN)</h3>";
echo "<b>Relevant Items (Locations):</b> " . implode(', ', $relevantItems) . "<br>";
echo "<b>Recommended Items (Top-$topN from PopularPlaces):</b> " . implode(', ', $topRecommended) . "<br>";
echo "<b>Matched Items:</b> " . implode(', ', $matchedItems) . "<br><br>";
echo "<b>Precision@$topN:</b> " . round($precision, 2) . "<br>";
echo "<b>Recall@$topN:</b> " . round($recall, 2) . "<br>";
echo "<b>F1 Score:</b> " . round($f1, 2) . "<br>";

// --- Close connection
mysqli_close($conn);
?>