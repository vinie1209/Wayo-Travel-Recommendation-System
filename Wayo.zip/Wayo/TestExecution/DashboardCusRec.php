<?php
session_start();
header('Content-Type: text/html');

// Simulate a logged-in user (if needed for GetRecommendations.php)
if (!isset($_SESSION['user_id'])) {
    $_SESSION['user_id'] = 1;  // Use a valid user_id that exists in DB
    $_SESSION['email'] = 'test@example.com';  // Simulate login
}

// Test target
$recommendation_url = '../Code/GetRecommendations.php';

echo "<h2>🔍 Testing 'Recommended for You' Feature</h2>";

// Fetch recommendation JSON
$response = @file_get_contents($recommendation_url);

if ($response === FALSE) {
    echo "<p style='color:red;'>❌ Failed to fetch recommendations. File not found or PHP error.</p>";
    exit;
}

$data = json_decode($response, true);

if (json_last_error() !== JSON_ERROR_NONE) {
    echo "<p style='color:red;'>❌ Invalid JSON returned from GetRecommendations.php</p>";
    echo "<pre>" . htmlspecialchars($response) . "</pre>";
    exit;
}

if (!is_array($data)) {
    echo "<p style='color:red;'>❌ Expected JSON array, got: " . gettype($data) . "</p>";
    exit;
}

if (count($data) === 0) {
    echo "<p style='color:orange;'>⚠️ No recommendations returned (empty array). Consider checking clustering or data.</p>";
} else {
    echo "<p style='color:green;'>✅ Recommendation data returned successfully (" . count($data) . " items)</p>";
    echo "<ul>";
    foreach ($data as $i => $place) {
        $name = isset($place['name']) ? htmlspecialchars($place['name']) : '❌ Missing';
        $photo = isset($place['photo_reference']) ? htmlspecialchars($place['photo_reference']) : '<i>None</i>';

        echo "<li>[$i] <strong>Name:</strong> $name | <strong>Photo Ref:</strong> $photo</li>";

        // Optional deeper field check
        if (!isset($place['name'])) {
            echo "<p style='color:red;'>❌ Missing 'name' field in item #$i</p>";
        }
    }
    echo "</ul>";
}

echo "<hr><p>🧪 Test complete. Loaded from <code>$recommendation_url</code></p>";
?>
