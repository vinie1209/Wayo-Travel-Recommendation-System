let map, service, directionsService, directionsRenderer, userMarker, userPosition;
let waypointCount = 1;

function initMap() {
    map = new google.maps.Map(document.getElementById("map"), {
        center: { lat: 3.139, lng: 101.6869 },
        zoom: 13,
    });

    directionsService = new google.maps.DirectionsService();
    directionsRenderer = new google.maps.DirectionsRenderer({ map: map });

    // 初始化第一个输入框 autocomplete
    initAutocomplete(document.querySelector('.waypoint'));
}

function initAutocomplete(input) {
    const autocomplete = new google.maps.places.Autocomplete(input);
}

function addWaypoint() {
    if (waypointCount >= 5) {
        alert("最多只能添加5个地点");
        return;
    }

    const input = document.createElement("input");
    input.type = "text";
    input.className = "waypoint";
    input.placeholder = `地点 ${waypointCount + 1}`;
    document.getElementById("waypoints").appendChild(input);
    initAutocomplete(input);
    waypointCount++;
}

// 📍 定位
function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(pos => {
            userPosition = {
                lat: pos.coords.latitude,
                lng: pos.coords.longitude,
            };
            map.setCenter(userPosition);

            if (userMarker) userMarker.setMap(null);

            userMarker = new google.maps.Marker({
                position: userPosition,
                map: map,
                title: "当前位置",
            });
        }, () => alert("无法获取定位"));
    } else {
        alert("不支持定位");
    }
}

// 🏞 / 🍜 附近 POI
function findNearby(type) {
    if (!userPosition) return alert("请先定位");

    const request = {
        location: userPosition,
        radius: 2000,
        type: [type],
    };

    service = new google.maps.places.PlacesService(map);
    service.nearbySearch(request, (results, status) => {
        if (status === google.maps.places.PlacesServiceStatus.OK) {
            map.setZoom(15);
            results.forEach(place => {
                const marker = new google.maps.Marker({
                    position: place.geometry.location,
                    map: map,
                    icon: place.rating >= 4 ? {
                        url: "https://maps.google.com/mapfiles/ms/icons/yellow-dot.png"
                    } : undefined
                });

                const infoWindow = new google.maps.InfoWindow({
                    content: `
                    <div>
                        <strong>${place.name}</strong><br>
                        评分: ${place.rating || '暂无'}<br>
                        <img src="${place.photos?.[0]?.getUrl() || ''}" width="100">
                    </div>
                    `
                });

                marker.addListener("click", () => {
                    infoWindow.open(map, marker);
                });
            });
        }
    });
}

// 🚗 最优路线
function calculateOptimizedRoute() {
    const inputs = document.querySelectorAll('.waypoint');
    if (inputs.length < 2) return alert("请至少输入起点和终点");

    const origin = inputs[0].value;
    const destination = inputs[inputs.length - 1].value;
    const waypoints = [];

    for (let i = 1; i < inputs.length - 1; i++) {
        const location = inputs[i].value;
        if (location.trim() !== '') {
            waypoints.push({ location, stopover: true });
        }
    }

    directionsService.route({
        origin,
        destination,
        waypoints,
        optimizeWaypoints: true,
        travelMode: 'DRIVING',
    }, (response, status) => {
        if (status === 'OK') {
            directionsRenderer.setDirections(response);

            const route = response.routes[0];
            const summaryPanel = document.getElementById("route-info");
            summaryPanel.innerHTML = "<h3>路线详情：</h3>";

            route.legs.forEach((leg, i) => {
                summaryPanel.innerHTML += `
                    <p><strong>${leg.start_address}</strong> → <strong>${leg.end_address}</strong><br>
                    距离：${leg.distance.text}，耗时：${leg.duration.text}</p><hr>`;
            });
        } else {
            alert('路线规划失败：' + status);
        }
    });
}

window.onload = initMap;
