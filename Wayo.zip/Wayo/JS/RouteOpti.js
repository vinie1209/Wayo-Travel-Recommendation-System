
let map, directionsService, directionsRenderer;
let nearbyMarkers = []; // 保存“附近”地点的 marker


function initMap() {
    map = new google.maps.Map(document.getElementById("map"), { center: { lat: 3.139, lng: 101.686 }, zoom: 13 });
    directionsService = new google.maps.DirectionsService();
    directionsRenderer = new google.maps.DirectionsRenderer();
    directionsRenderer.setMap(map);
}

function initAutocompleteForInputs() {
    let inputs = document.querySelectorAll('.waypoint');
    window.placeIds = [];  // 初始化

    inputs.forEach((input, idx) => {
        let autocomplete = new google.maps.places.Autocomplete(input);
        autocomplete.addListener('place_changed', function () {
            let place = autocomplete.getPlace();
            if (place && place.place_id) {
                window.placeIds[idx] = place.place_id;
                console.log(`placeIds[${idx}] = `, place.place_id);
            } else {
                alert("请选择提示列表中的地点，而不是手动输入！");
            }
        });
    });
}

function detectCurrentLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            pos => {
                let latlng = pos.coords.latitude + "," + pos.coords.longitude;
                // 用 Geocoder 转换为地址
                let geocoder = new google.maps.Geocoder();
                geocoder.geocode({ location: { lat: pos.coords.latitude, lng: pos.coords.longitude } }, (results, status) => {
                    if (status === "OK" && results[0]) {
                        document.getElementById('start-point').value = results[0].formatted_address;
                    } else {
                        alert("获取地址失败: " + status);
                    }
                });
            },
            () => alert("无法获取当前位置")
        );
    } else {
        alert("浏览器不支持定位");
    }
}

function addWaypoint(btn) {
    // 限制总共最多6个地点（起点+5个）
    if (document.querySelectorAll('.waypoint').length < 6) {
        let div = document.createElement('div');
        div.className = 'waypoint-row';

        let input = document.createElement('input');
        input.type = 'text';
        input.className = 'waypoint';
        input.placeholder = 'Destination/Way Point';

        let removeBtn = document.createElement('button');
        removeBtn.type = 'button';
        removeBtn.className = 'add-btn';
        removeBtn.textContent = '-';
        removeBtn.onclick = () => {
            div.remove();
            // 可选：同步更新 window.placeIds
            initAutocompleteForInputs();
        };

        div.appendChild(input);
        div.appendChild(removeBtn);
        document.getElementById('waypoints').appendChild(div);

        // 初始化自动补全
        initAutocompleteForInputs();
    } else {
        alert("最多添加5个！");
    }
}

// 全局变量：保存起点和终点 marker
// 全局变量：保存 endMarker
let endMarker = null;

function calculateOptimizedRoute() {
    console.log("准备计算路线，当前 placeIds:", window.placeIds);

    if (window.placeIds.includes(undefined) || window.placeIds.includes(null)) {
        alert("请确保每个地点都从下拉提示中选择，而不是自己打字！");
        return;
    }
    let inputs = document.querySelectorAll('.waypoint');
    if (inputs.length < 2) {
        alert("请输入起点和至少一个目的地");
        return;
    }

    let origin = inputs[0].value;
    let destinations = Array.from(inputs).slice(1).map(input => ({ location: input.value, stopover: true }));

    directionsService.route({
        origin: origin,
        destination: origin,
        waypoints: destinations,
        optimizeWaypoints: true,
        travelMode: 'DRIVING'
    }, (result, status) => {
        if (status === 'OK') {
            directionsRenderer.setDirections(result);

            let route = result.routes[0];
            let legs = route.legs;
            let totalDistance = 0, totalDuration = 0;
            legs.forEach(leg => {
                totalDistance += leg.distance.value;
                totalDuration += leg.duration.value;
            });
            totalDistance = (totalDistance / 1000).toFixed(1) + " km";
            totalDuration = Math.round(totalDuration / 60) + " mins";

            let newDestination = legs[legs.length - 1].end_address;

            // 添加🏁 marker
            let lastLegEndLocation = legs[legs.length - 1].end_location;
            if (endMarker) endMarker.setMap(null);
            endMarker = new google.maps.Marker({
                position: lastLegEndLocation,
                map: map,
                label: { text: "🏁", color: "black", fontSize: "16px" },
                title: "终点"
            });

            let routeInfoHtml = `<strong><b>Best Route</b></strong><br><b>总距离:</b> ${totalDistance} <br> <b>总时长:</b> ${totalDuration} <br><br>`;

            legs.forEach((leg, idx) => {
                let startName = leg.start_address.split(',')[0].trim();
                let endName = leg.end_address.split(',')[0].trim();
                let distance = leg.distance.text;
                let duration = leg.duration.text;

                let navigationLink = `https://www.google.com/maps/dir/?api=1&origin=${encodeURIComponent(leg.start_address)}&destination=${encodeURIComponent(leg.end_address)}&travelmode=driving`;

                routeInfoHtml += `
                    <div class="leg-info">
                        <strong>${startName}</strong>  ---〉<strong>${endName}</strong><br>
                        Distance: ${distance}<br>
                        Estimation Time: ${duration}<br>
                        <a href="${navigationLink}" target="_blank">Navigate on Google</a>
                    </div><br>
                `;
            });

            document.getElementById('route-info').innerHTML = routeInfoHtml;


            // 根据优化后的顺序重排 placeIds
            let optimizedOrder = route.waypoint_order;
            let reorderedPlaceIds = [];
            reorderedPlaceIds.push(window.placeIds[0]); // 起点
            optimizedOrder.forEach(i => {
                reorderedPlaceIds.push(window.placeIds[i + 1]); // +1 因为 placeIds[0] 是起点
            });
            reorderedPlaceIds.push(window.placeIds[0]); // 回到起点作为终点

            window.routeData = {
                totalDistance,
                totalDuration,
                placeIds: reorderedPlaceIds
            };

            // routeId 可以用系统刚生成的，也可以用固定值，如果还没生成，就先用临时占位
            let title = "Best Route " + new Date().toLocaleString();
            let formData = new FormData();
            formData.append('bestRoute', 1);
            formData.append('totalDistance', totalDistance);
            formData.append('totalDuration', totalDuration);
            formData.append('locations', JSON.stringify(reorderedPlaceIds));
            formData.append('title', title);

            fetch(location.pathname, { method: 'POST', body: formData })
                .then(res => res.text())
                .then(routeId => {
                    console.log("已保存最佳路线，RouteID:", routeId);
                    window.savedRouteId = routeId; // 存起来
                })
                .catch(err => console.error("保存最佳路线失败:", err));


            // 清除之前的 marker
            if (window.markers) {
                window.markers.forEach(m => m.setMap(null));
            }
            window.markers = [];
            let infoWindow = new google.maps.InfoWindow();
            let service = new google.maps.places.PlacesService(map);

            reorderedPlaceIds.forEach((placeId, idx) => {
                service.getDetails({ placeId: placeId, fields: ['name', 'rating', 'photos', 'formatted_address'] }, (place, status) => {
                    if (status === google.maps.places.PlacesServiceStatus.OK) {
                        let loc = null;
                        if (idx === 0) {
                            loc = legs[0].start_location;
                        } else if (idx === reorderedPlaceIds.length - 1) {
                            loc = legs[legs.length - 1].end_location;
                        } else {
                            loc = legs[idx - 1].end_location;
                        }

                        let marker = new google.maps.Marker({
                            position: loc,
                            map: map,
                            label: { text: String(idx + 1), color: "white", fontSize: "12px" }, // label 改成数字
                            title: place.name
                        });

                        marker.addListener('click', () => {
                            let photoUrl = place.photos && place.photos.length > 0 ? place.photos[0].getUrl({ maxWidth: 300 }) : '';
                            let content = `<div style="max-width:250px;">
                                    <strong>${place.name}</strong><br>
                                    ${place.rating ? `⭐ ${place.rating}<br>` : ''}
                                    ${photoUrl ? `<img src="${photoUrl}" style="width:100%;border-radius:8px;margin-top:5px;">` : ''}
                                    <small>${place.formatted_address}</small>
                                </div>`;
                            infoWindow.setContent(content);
                            infoWindow.open(map, marker);
                        });

                        window.markers.push(marker);
                    } else {
                        console.error("getDetails failed:", status);
                    }
                });
            });

        } else {
            alert("路线规划失败: " + status);
        }
    });
}

function saveRoute() {
    if (!window.savedRouteId) {
        alert("请先生成路线");
        return;
    }
    let formData = new FormData();
    formData.append('markSave', 1);
    formData.append('routeId', window.savedRouteId);
    fetch(location.pathname, { method: 'POST', body: formData })
        .then(res => res.text())
        .then(msg => alert(msg))
        .catch(err => alert("保存失败: " + err));
}

window.onload = () => {
    initMap();
    initAutocompleteForInputs();
}

function findNearby(type) {
    // 获取用户输入
    let minRating = parseInt(document.getElementById('minRating').value) || 1;
    let maxRating = parseInt(document.getElementById('maxRating').value) || 5;
    let radiusKm = parseInt(document.getElementById('radiusKm').value) || 30;
    let radiusMeters = radiusKm * 1000;

    // 获取当前地图中心坐标
    let center = map.getCenter();
    let lat = center.lat();
    let lng = center.lng();

    fetch(`RouteOpti.php?action=places&lat=${lat}&lng=${lng}&type=${type}&radius=${radiusMeters}`)
        .then(res => res.json())
        .then(data => {
            if (data.status !== 'OK' || !data.results) {
                alert('未找到结果');
                return;
            }

            // 根据评分过滤
            let filtered = data.results.filter(place =>
                place.rating >= minRating && place.rating <= maxRating
            );

            // 清除旧 marker
            if (window.nearbyMarkers) {
                window.nearbyMarkers.forEach(m => m.setMap(null));
            }
            window.nearbyMarkers = [];

            filtered.forEach(place => {
                let loc = place.geometry.location;
                let marker = new google.maps.Marker({
                    position: loc,
                    map: map,
                    title: place.name
                });

                let infoWindow = new google.maps.InfoWindow({
                    content: `<div style="max-width:200px">
                            <strong>${place.name}</strong><br>
                            ⭐ ${place.rating || '无评分'}<br>
                            <small>${place.vicinity || ''}</small>
                        </div>`
                });
                marker.addListener('click', () => infoWindow.open(map, marker));

                window.nearbyMarkers.push(marker);
            });

            if (filtered.length === 0) {
                alert('符合条件的地点未找到');
            }
        })
        .catch(err => {
            console.error(err);
            alert('请求出错');
        });
}

function updateRatingLabel() {
    let minRating = parseInt(document.getElementById('minRating').value);
    let maxRating = parseInt(document.getElementById('maxRating').value);

    // 保证 min <= max
    if (minRating > maxRating) {
        // 如果拉过头，让另一个滑块跟随
        if (event.target.id === 'minRating') {
            document.getElementById('maxRating').value = minRating;
            maxRating = minRating;
        } else {
            document.getElementById('minRating').value = maxRating;
            minRating = maxRating;
        }
    }

    document.getElementById('ratingLabel').innerText = `${minRating} - ${maxRating}`;
}

window.addEventListener('DOMContentLoaded', () => {
    document.getElementById('detect-btn').addEventListener('click', detectCurrentLocation);
    document.getElementById('add-btn').addEventListener('click', () => addWaypoint());

    document.getElementById('best-route-btn').addEventListener('click', calculateOptimizedRoute);
    document.getElementById('save-btn').addEventListener('click', saveRoute);
    document.getElementById('share-btn').addEventListener('click', saveRoute); // 如果 share 和 save 是同样逻辑

    document.querySelectorAll('.nearby-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            let type = btn.dataset.type;
            findNearby(type);
        });
    });
});
